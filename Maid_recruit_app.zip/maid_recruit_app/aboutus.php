<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  
        <style>
            body{
                background-image: url('web_images/background.png');  
                background-size: cover;
                background-position-x: -5px;
                background-position-y: -5px;
                background-attachment: fixed;
            }
            .righted_menu a{
                background-color: #050b36;
                padding: 10px;
                border-radius: 6px;
            }
            .righted_menu{
                padding: 15px;
                border-bottom: 5px solid #69e7c6;
                padding-bottom: 24px;
            }
            .two_f_box{
                float: right;
                width: 70%;
            }
            .fifty_percent{
                width: 48%;
            }
            #pic1{
                background-image: url('web_images/cleaner.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic2{
                background-image: url('web_images/cook2.png');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic3{
                background-image: url('web_images/happy.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic4{
                background-image: url('web_images/babysit.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            .bg_font{
                font-size: 20px;
                margin-top: 50px ;
                margin-bottom: 50px ;

            }
            .lim_h{/*Limited height*/
                max-height: 200px;
                overflow-y: scroll;
            }

            /* width */
            ::-webkit-scrollbar {
                width: 10px;
            }

            /* Track */
            ::-webkit-scrollbar-track {
                background: #3a88a9; 
            }

            /* Handle */
            ::-webkit-scrollbar-thumb {
                background: #cb8b10; 
            }

            /* Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
                background: #555; 
            }
            .bg_pic{
                float: right;  

            }
            .top_l_bg{
                position: fixed;
                top: -7px;
                left: -10px;
                height:380px;
                width: 380px;
                background-size: 100%;
                background-repeat: no-repeat;
                background-image: url('web_images/main2.png');
            }
        </style>
    </head>
    <body>
        <?php include 'header_menu.php'; ?>
        <div class="parts top_l_bg no_shade_noBorder">

        </div>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

    </div>
    <div class="parts eighty_centered     no_paddin_shade_no_Border  "
         style="margin-top: 13%; font-size: 14px;font-weight: normal;line-height: 2.2em; text-align: justify ; 
         background-color: #fff; color: #000;padding: 20px; border: 2px solid #130c2f;">
        <p>
            This project is wholly developed by a student of Information System at University of Kigali for the senior course. The project mainly aims to demonstrate the
            knowledge gained through the different courses taken and the independent learning ability as well as the experience of students. 
            This is where there is a replacement of manual system of housekeepers hiring company. There, staff need to record and keep record of hired housekeepers on the papers. 
            With that method, it gives staff hard time to manage housekeepers’ applications versus the hired ones. Even more, the company could reach out as many </p>
        <p>

            potential housekeeper as it wished because there was no outreach means.   Apart from housekeepers’ management, the families or individuals could not get information of
            available housekeepers before they come to the company headquarters. Therefore the company struggled on one side of their internal management while their client struggled 
            on the other side. For the main goal of the company (financial interest), the company also wished to easily manage their financial accountability and easily compare
            their periodic financial reports. </p>
    </div>

    <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
</body>
</html>
<?php

function list_maid_by_cat($category) {
    require_once 'web_db/connection.php';
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select profile.name, maid.experience, maid.religion from maid"
            . "  join village on village.village_id=maid.village "
            . " join profile on profile.profile_id=maid.profile"
            . " where maid.prefered_job=:job";
    $stmt = $db->prepare($sql);
    $stmt->execute(array(":job" => $category));
    ?>

    <style>
        .dataList_table{
            border-collapse: collapse;
            width: 100%;
        }
        .dataList_table td{
            padding: 5px;
        }
        .dataList_table thead{
            text-transform: capitalize;
            background-color: #0c4561;
            color: #fff;

        }
    </style>
    <table class="dataList_table">
        <thead><tr>
                <td> name </td>
                <td> Experience </td>
                <td> Religion </td>
            </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?>
            <tr> 
                <td class="sex_id_cols maid " title="maid" >
                    <?php echo $row['name']; ?>
                </td>
                <td>
                    <?php echo $row['experience']; ?>
                </td>
                <td>
                    <?php echo $row['religion']; ?>
                </td>

            </tr>
        <?php } ?></table>
    <?php
}

function list_maid_categories() {
    require_once 'web_db/connection.php';
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select profile.name, maid.education_level, maid.prefered_job  from maid"
            . "  join village on village.village_id=maid.village "
            . " join profile on profile.profile_id=maid.profile"
            . " where maid.available='yes'";
    ?>
    <style>
        .dataList_table{
            border-collapse: collapse;
            margin-top: 10px;
        }
        .dataList_table td{
            padding: 5px;
        }
        .dataList_table thead{
            text-transform: capitalize;
            background-color: #0c4561;
            color: #fff;

        }
        li{
            line-height: 3em;
            font-size: 12px;
            text-decoration: underline;
            text-transform: uppercase;
            color: #054811;
            font-weight: bolder;
        }
    </style>
    <ul>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
            <li>
                <?php echo $row['education_level']; ?>
            </li>
            <?php list_maid_by_cat($row['prefered_job']); ?> 

        <?php } ?></ul> 
    <?php
}
