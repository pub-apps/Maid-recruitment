<?php

//This send data to android

if (isset($_POST['get_account'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_account_category'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account_category   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_profile'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from profile   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_image'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from image   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_province'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from province   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_district'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from district   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_sector'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from sector   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_cell'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from cell   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_contact_us'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from contact_us   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_village'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from village   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_org'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from org   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_recruiter'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from recruiter   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_recruitment'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from recruitment   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_return'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from return   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_maid'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from maid   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
