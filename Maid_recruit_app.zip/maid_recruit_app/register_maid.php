<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
if (isset($_POST['send_maid'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $maid_id = $_SESSION['id_upd'];

            $sex = $_POST['txt_sex'];
            $village = $_POST['txt_village_id'];

            $id_number = $_POST['txt_id_number'];
            $experience = $_POST['txt_experience'];
            $religion = $_POST['txt_religion'];
            $prefered_job = $_POST['txt_prefered_job'];
            $available = 'yes';
            $upd_obj->update_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $maid_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $sex = $_POST['txt_sex'];
        $village = trim($_POST['txt_village_id']);
        $id_number = $_POST['txt_id_number'];
        $edu_level = $_POST['txt_edu_level'];
        $experience = $_POST['txt_experience'];
        $religion = $_POST['txt_religion'];
        $prefered_job = $_POST['txt_prefered_job'];
        $available = 'yes';

        require_once '../web_db/new_values.php';
        $obj = new new_values();
//new profile
        $name = $_POST['txt_name'];
        $obj->new_profile(date('y-m-d'), $name, '', '', '', '', '', 0);
        $m = new multi_values();
        $pers = $m->get_lastprofile();
        if (empty($village)) {
            ?><script>alert('You have to choose the village');</script><?php
        } else {
            $obj->new_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $pers, $edu_level);
        }
    }
}
?>

<html>
    <head>
        <title>
            maid</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>

        </style>
    </head>
    <body>
        <form action="new_maid.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_village_id"   name="txt_village_id"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> 
                </div>  
            </div>
            <div class="parts eighty_centered off saved_dialog">
                Maid saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  Maid Registration</div>
                <table class="new_data_table">
                    <tr>
                        <td>Names</td>
                        <td><input type="text" placeholder="Enter both names" name="txt_name" required="" class="textbox" /></td>
                    </tr>
                    <tr><td>sex :</td><td> 
                            <select  name="txt_sex" required>
                                <option>
                                    Male
                                </option>
                                <option>
                                    Female
                                </option>
                            </select>
                        </td>
                    </tr>
                    <tr><td>village :</td><td> 
                            <?php
                            get_district_combo();
                            get_sector_combo();
                            get_cells_combo();
                            get_village_combo();
                            ?>  </td>
                    </tr>
                    <tr><td>id_number :</td><td> <input type="text"     name="txt_id_number" required class="textbox only_numbers" value="<?php echo trim(chosen_id_number_upd()); ?>"   />  </td></tr>
                    <tr><td>Education Level :</td><td> 

                            <select name="txt_edu_level" required class="textbox only_numbers">
                                <option></option>
                                <option>Not educated</option>
                                <option> Not finished primary school</option>
                                <option> Finished only primary school</option>
                                <option> Finished O level school</option>
                                <option> Finished A level school</option>
                                <option> Graduated Bachelor degree school</option>
                                <option> Graduated Masters degree school</option>
                            </select>

                    <tr><td>experience :</td><td> <input type="text"     name="txt_experience" required class="textbox" value="<?php echo trim(chosen_experience_upd()); ?>"   />  </td></tr>
                    <tr><td>religion :</td><td> <input type="text"     name="txt_religion" required class="textbox" value="<?php echo trim(chosen_religion_upd()); ?>"   />  </td></tr>
                    <tr><td>preferred_job :</td><td> 
                            <select name="txt_prefered_job" required class="textbox">
                                <option></option>
                                <option>Baby sitting</option>
                                <option>Food preparation</option>
                                <option>Cleaning</option>
                                <option>House work assistant</option>
                            </select>
                        </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_maid" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">maid List</div><?php
                $obj = new multi_values();
                $obj->list_maid();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_cells_combo() {
    $obj = new multi_values();
    $obj->get_cell_in_combo();
}

function get_district_combo() {
    $obj = new multi_values();
    $obj->get_district_in_combo();
}

function get_sector_combo() {
    $obj = new multi_values();
    $obj->get_sector_in_combo();
}

function get_village_combo() {
    $obj = new multi_values();
    $obj->get_village_in_combo();
}

function chosen_sex_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $sex = new multi_values();
            return $sex->get_chosen_maid_sex($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_village_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $village = new multi_values();
            return $village->get_chosen_maid_village($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_id_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $id_number = new multi_values();
            return $id_number->get_chosen_maid_id_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_experience_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $experience = new multi_values();
            return $experience->get_chosen_maid_experience($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_religion_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $religion = new multi_values();
            return $religion->get_chosen_maid_religion($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_prefered_job_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $prefered_job = new multi_values();
            return $prefered_job->get_chosen_maid_prefered_job($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_available_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'maid') {
            $id = $_SESSION['id_upd'];
            $available = new multi_values();
            return $available->get_chosen_maid_available($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
