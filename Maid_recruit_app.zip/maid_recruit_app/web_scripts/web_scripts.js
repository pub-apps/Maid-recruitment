$(document).ready(function () {
    try {
        get_new_data_hide_show();
        get_account_category_id_combo();
        get_image_id_combo();
        get_province_id_combo();
        get_district_id_combo();
        get_sector_id_combo();
        get_account_id_combo();
        get_cell_id_combo();
        get_profile_id_combo();
        get_maid_id_combo();
        get_recruiter_id_combo();
        get_maid_id_combo();
        get_village_id_combo();
        center_pane();
        other_funct();
        get_locations_combos();
        recruiter_del_udpate();
        validate_numbers_textfields();
        choose_maid_link();
        maid_del_udpate();
        recruitment_del_udpate();
        return_del_udpate();
        account_category_del_udpate();
        account_del_udpate();
        show_form_toUpdate();
        get_locations_combos();
        get_cbo_client_combo();
    } catch (err) {
        alert(err.message);
    }
});
function show_form_toUpdate() {
    var updname = $('#txt_shall_expand_toUpdate').val();
  
    if (updname !== '' && updname!== undefined) {
        $('.new_data_box').delay(200).slideDown();
    }

}
function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
            $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
            $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
            $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_province_id_combo() {
    try {
        $('.cbo_province').change(function () {
            var cbo_province = $('.cbo_province option:selected').val();
            $('#txt_province_id').val(cbo_province);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').val();
            $('#txt_district_id').val(cbo_district);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
            $('#txt_sector_id').val(cbo_sector);

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
            $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
            $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
            $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
            $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_maid_id_combo() {
    try {
        $('.cbo_maid').change(function () {
            var cbo_maid = $('.cbo_maid option:selected').val();
            $('#txt_maid_id').val(cbo_maid);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_recruiter_id_combo() {
    try {
        $('.cbo_recruiter').change(function () {
            var cbo_recruiter = $('.cbo_recruiter option:selected').val();
            $('#txt_recruiter_id').val(cbo_recruiter);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_maid_id_combo() {
    try {
        $('.cbo_maid').change(function () {
            var cbo_maid = $('.cbo_maid option:selected').val();
            $('#txt_maid_id').val(cbo_maid);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_village_id_combo() {
    try {
        $('.cbo_village').change(function () {
            var cbo_village = $('.cbo_village option:selected').val();
            $('#txt_village_id').val(cbo_village);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_cbo_client_combo() {
    try {
        $('.cbo_client').change(function () {
            var cbo_village = $('.cbo_client option:selected').val();
            $('#txt_cbo_client_id').val(cbo_village);
            alert(cbo_village);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {
        $('.new_data_box').slideToggle(1);
    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
//update from account ...

function account_del_udpate() {
    $('.account_update_link').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();

        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
    $('.account_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from account_category ...

function account_category_del_udpate() {
    $('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
    $('.account_category_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account_category').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from profile ...

function profile_del_udpate() {
    $('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
    $('.profile_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.profile').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from image ...

function image_del_udpate() {
    $('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
    $('.image_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.image').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from province ...

function province_del_udpate() {
    $('.province_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.province').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprovince.. 
    $('.province_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.province').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from district ...

function district_del_udpate() {
    $('.district_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict.. 
    $('.district_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.district').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from sector ...

function sector_del_udpate() {
    $('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
    $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cell ...

function cell_del_udpate() {
    $('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
    $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from contact_us ...

function contact_us_del_udpate() {
    $('.contact_us_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcontact_us.. 
    $('.contact_us_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from village ...

function village_del_udpate() {
    $('.village_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage.. 
    $('.village_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.village').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from org ...

function org_del_udpate() {
    $('.org_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.org').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromorg.. 
    $('.org_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.org').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from recruiter ...

function recruiter_del_udpate() {
    $('.recruiter_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.recruiter').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromrecruiter.. 
    $('.recruiter_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.recruiter').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
            alert(data);
        }).complete(function () {

        });

    });
}//update from recruitment ...

function recruitment_del_udpate() {
    $('.recruitment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.recruitment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromrecruitment.. 
    $('.recruitment_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.recruitment').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
            alert(data);
        }).complete(function () {

        });

    });
}//update from return ...

function return_del_udpate() {
    $('.return_update_link').click(function () {
        var table_to_update = $(this).data('bind');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromreturn.. 
    $('.return_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.return').attr('title');
        var id_delete = $(this).attr('value').trim();
        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
        });

    });
}//update from maid ...

function maid_del_udpate() {
    $('.maid_update_link').unbind('click').click(function () {
        var table_to_update = $(this).data('bind');
        var id_update = $(this).attr('value').trim();
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });

    });//delete frommaid.. 
    $('.maid_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.maid').attr('title');
        var id_delete = $(this).attr('value').trim();
        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
            alert(data);
        }).complete(function () {

        });

    });
}

//addon
function center_pane() {//once there are 3 items
//    var box_width = $('.incenter').parent().width();
//    var item_width = $(this).width();
//    var item_margin = box_width - item_width ;
//    $('.incenter').css('margin-left', item_margin);
}
function other_funct() {
    $('.banner').delay(300).show(2000);
}

//<editor-fold defaultstate="collapsed" desc="----- Locations -----">
function get_locations_combos() {


    $('#sp_combo_cell').change(function () {
        try {
            var village_by_cell = $('#sp_combo_cell option:selected').val().trim();
            $('#sp_combo_village').empty();
            $('#sp_combo_village').append('<option> -- Village -- </option>');
            $('#txt_cell_id').val(village_by_cell);

            $.post('admin/handler.php', {village_by_cell: village_by_cell}, function (data) {
                var final = $.parseJSON(data.trim());
                $.each(final, function (i, option) {
                    $('#sp_combo_village').append($('<option/>').attr("value", option.id).text(option.name));
                });
            });
        } catch (err) {
            alert(err.message);
        }
    });
    $('#sp_combo_village').change(function () {
        var village_by_cell = $('#sp_combo_village option:selected').val().trim();
        $('#txt_village_id').val(village_by_cell);
    });
}
//</editor-fold>

function choose_maid_link() {
    $('.choose_maid_link').click(function () {
        var maid_id = $(this).data('bind');
        $('#txt_chosen_maid').val(maid_id);
        $('.pane_overlay').fadeIn(200);
        //update the maid pending requested
        return false;
    });
    $('.close_pane').click(function () {
        $('.pane_overlay').fadeOut(200);
    });
}
 