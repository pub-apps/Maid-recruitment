<?php
if (isset($_POST['send_recruiter'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $recruiter_id = $_SESSION['id_upd'];
            $family_rep_name = $_POST['txt_family_rep_name'];
            $number_members = $_POST['txt_number_members'];
            $sector = $_POST['txt_sector_id'];
            $profile = $_POST['txt_profile_id'];
            $entry_date = date("y-m-d");
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];
            $upd_obj->update_recruiter($family_rep_name, $number_members, $sector, $profile, $recruiter_id, $entry_date, $username, $password, $recruiter_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $obj = new new_values();
        $name = trim($_POST['txt_name']);
//save the profile
        $obj->new_profile(date('y-m-d'), $name, '', '', '', '', '', 0);
        $m = new multi_values();
        $last_profile = $m->get_lastprofile();
        $username = $_POST['txt_username'];
        $password = $_POST['txt_password'];
        if (!empty($m->get_username_exists($username, $password))) {
            ?><script>alert('The username already exists, please user a different username');</script><?php
        } else {
            $obj->new_account(9, date('y-m-d'), $last_profile, $username, $password, "yes");
            $last_acc = $m->get_last_account();
            $family_rep_name = $_POST['txt_family_rep_name'];
            $number_members = $_POST['txt_number_members'];
            $sector = trim($_POST['txt_sector_id2']);
            $entry_date = date("y-m-d");
            $phone = date("txt_phoone");
            $obj->new_recruiter($family_rep_name, $number_members, $sector, $last_profile, $entry_date, $last_acc, $phone);
            $m = new multi_values();
            $last_recruiter = $m->get_last_recruiter();
            $obj->new_recruitment(date("Y-m-d"), $_POST['txt_chosen_maid'], $last_recruiter, 0, 0);
            $description = $_POST['txt_description'];
            if (!empty($sector)) {
                $obj->new_maid_request(date('y-m-d'), $last_acc, $description);
                if (!empty($_POST['txt_chosen_maid'])) {
                    //update the maid
                    $upd = new updates();
                    $upd->update_maid_statuss('requested', $_POST['txt_chosen_maid']);
                } else {
                    ?><script>alert('Not updating maid');</script><?php
                }
                ?><script>
                    alert('Your account has been saved successfully. You user your username and password next time to see your requests');
                </script><?php
            } else {
                ?><script>alert('You have to select sector'..);</script><?php
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset = "UTF-8">
        <title>Home</title>
        <link href = "web_style/styles.css" rel = "stylesheet" type = "text/css"/>
        <link href = "web_style/StylesAddon.css" rel = "stylesheet" type = "text/css"/>
        <meta name = "viewport" content = "width=device-width, initial scale=1.0"/>
        <style>
            body{
                background-image: url('web_images/background.png');
                background-size: cover;
                background-position-x: -5px;
                background-position-y: -5px;
                background-attachment: fixed;
            }
            .righted_menu a{
                background-color: #050b36;
                padding: 10px;
                border-radius: 6px;
            }
            .righted_menu{
                padding: 15px;
                border-bottom: 5px solid #69e7c6;
                padding-bottom: 24px;
            }
            .two_f_box{
                float: right;
                width: 70%;
            }
            .fifty_percent{
                width: 48%;
            }
            #pic1{
                background-image: url('web_images/cleaner.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic2{
                background-image: url('web_images/cook2.png');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic3{
                background-image: url('web_images/happy.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic4{
                /* background-image: url('web_images/babysit.JPG'); */
                background-size: 100%;
                background-repeat: no-repeat;
            }
            .bg_font{
                font-size: 20px;
                margin-top: 50px;
                margin-bottom: 50px;

            }
            .lim_h{/* Limited height */
                max-height: 200px;
                overflow-y: scroll;
            }

            /* width */
            ::-webkit-scrollbar {
                width: 10px;
            }

            /* Track */
            ::-webkit-scrollbar-track {
                background: #3a88a9; 
            }

            /* Handle */
            ::-webkit-scrollbar-thumb {
                background: #cb8b10; 
            }

            /* Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
                background: #555; 
            }
            .bg_pic{
                float: right;
            }
            .dataList_table{
                min-width: 70%;
            }
            .dataList_table tr td{
                padding: 15px;
            }
            .link_cursor{
                cursor: pointer;
            }
            .btn_add_mine:hover, .btn_choose:hover{
                cursor: pointer;
            }
            textarea{
                min-height: 80px;
                resize: none;
            }
        </style>
    </head>
    <body>
        <?php include 'header_menu.php'; ?>
        <!--Start of overlay-->
        <div class="parts abs_full no_shade_noBorder margin_free pane_overlay off">
            <div class="parts push_right close_pane no_paddin_shade_no_Border link_cursor">

            </div>
            <div class="parts no_paddin_shade_no_Border">
                <form action="new_find_worker.php" method="post">
                    <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
                    <input type="hidden"   id="txt_sector_id2"      name="txt_sector_id2"/>
                    <table class="new_data_table" style="margin-top: 0px;">
                        <tr>
                            <td colspan="2" class="big_title"> 
                                FILL IN YOUR PERSONAL INDENTIFICATION
                                <input  type="hidden"   id="txt_chosen_maid"  name="txt_chosen_maid"/>
                            </td>
                        </tr>
                        <tr><td>Names :</td><td> <input type="text" placeholder="Enter both names"    name="txt_name" required class="textbox "   />  </td></tr>
                        <tr><td>Phone :</td><td> <input required maxlength="10"  type="text" placeholder="phone numbers"    name="txt_phone" required class="textbox only_numbers"   />  </td></tr>
                        <tr><td>family_rep_name :</td><td> <input type="text"     name="txt_family_rep_name" required class="textbox" value="<?php echo trim(chosen_family_rep_name_upd()); ?>"   />  </td></tr>
                        <tr><td>number_members :</td><td> <input type="text"     name="txt_number_members" required class="textbox only_numbers" value="<?php echo trim(chosen_number_members_upd()); ?>"   />  </td></tr>
                        <tr><td>sector :</td><td> <?php get_sector_combo(); ?>  </td></tr>
                        <tr class="off"><td>profile :</td><td> <?php get_profile_combo(); ?>  </td></tr>
                        <tr><td><label for="txt_username">Username </label></td><td> <input type="text"     name="txt_username" required id="txt_username" class="textbox" value="<?php echo trim(chosen_username_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_password">Password </label></td><td> <input type="password"     name="txt_password" required id="txt_password" class="textbox" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>
                        <tr><td colspan="2" class="big_title">ADD HOUSE KEEPER DESCRIPTION </td> </tr>
                        <tr><td><label for="txt_description">Description </label></td><td> <textarea       name="txt_description" required id="txt_description" class="textbox">  <?php echo trim(chosen_password_upd()); ?></textarea>     </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_recruiter" value="Save"/>  </td></tr>
                    </table>
                </form> 
            </div>
        </div>
        <!--End of overlay-->
        <div class="parts top_l_bg no_shade_noBorder"> </div>
        <div id="fb-root"></div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border">
            <div class="parts  link_cursor btn_add_mine no_shade_noBorder">
                <div class="parts no_paddin_shade_no_Border">
                    Add my own  customizations 
                </div>
            </div>
            <div class="parts  link_cursor btn_choose no_shade_noBorder">
                Choose among the existing
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <table>
                    <tr>
                        <td>Find by gender</td>
                        <td><select id="gender_condition" style="width: 400px;">
                                <option> </option>
                                <option>Male</option>
                                <option>Female</option>
                            </select><br/>
                            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border res">
                            </div>
                        </td>
                    </tr>
                </table> 
            </div> 
        </div> 
        <div class="parts eighty_centered  no_shade_noBorder pane1 off">
            <div class="parts no_paddin_shade_no_Border">
                <form action="new_find_worker.php" method="post">
                    <input type="hidden"   id="txt_sector_id2"      name="txt_sector_id2"/>
                    <input type="hidden"   id="txt_profile_id"   name="txt_profile_id"/>
                    <table class="new_data_table">
                        <tr> 
                            <td colspan="2" class="big_title">
                                FILL IN YOUR PERSONAL INDENTIFICATION
                            </td>
                        </tr>
                        <tr><td>Names :</td><td> <input type="text" placeholder="Enter both names"    name="txt_name" required class="textbox"   />  </td></tr>
                        <tr><td>Phone :</td><td> <input required maxlength="10"  type="text" placeholder="phone numbers"    name="txt_phone" required class="textbox only_numbers"   />  </td></tr>
                        <tr><td>family_rep_name :</td><td> <input type="text"     name="txt_family_rep_name" required class="textbox" value="<?php echo trim(chosen_family_rep_name_upd()); ?>"   />  </td></tr>
                        <tr><td>number_members :</td><td> <input type="text"     name="txt_number_members" required class="textbox only_numbers" value="<?php echo trim(chosen_number_members_upd()); ?>"   />  </td></tr>
                        <tr><td>sector  :</td><td> <?php get_sector_combo(); ?>  </td></tr>
                        <tr class="off"><td>profile :</td><td> <?php get_profile_combo(); ?>  </td></tr>
                        <tr><td><label for="txt_username">Username </label></td><td> <input type="text"     name="txt_username" required id="txt_username" class="textbox" value="<?php echo trim(chosen_username_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_password">Password </label></td><td> <input type="password"     name="txt_password" required id="txt_password" class="textbox" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>
                        <tr><td colspan="2" class="big_title">ADD HOUSE KEEPER DESCRIPTION </td> </tr>
                        <tr><td><label for="txt_description">Description </label></td><td> <textarea       name="txt_description" required id="txt_description" class="textbox">  <?php echo trim(chosen_password_upd()); ?></textarea>     </td></tr>

                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_recruiter" value="Save"/>  </td></tr>
                    </table>
                </form> 
            </div>

        </div>
        <div class="parts eighty_centered no_shade_noBorder pane2">
            <div class="parts no_shade_noBorder res2">  
                <?php list_maid_categories(); ?>
            </div>
        </div>

        <div class="parts eighty_centered  heit_free no_paddin_shade_no_Border">
        </div>
        <div class="parts eighty_centered x_height_fifty x_height_two_fifty  no_paddin_shade_no_Border relate_height">

        </div>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js"      type="text/javascript"></script>
        <script>
                    $(document).ready(function () {

                        $('#gender_condition').change(function () {
                            var maid_by_gender = $(this, 'option:selected').val();
                            $('.res').html('Loading ...');

                            var res = '';
                            $.post('admin/handler.php', {maid_by_gender: maid_by_gender}, function (data) {
                                res = data;
                            }).complete(function () {
                                $('.res2').html(res);
                                $('.res').html('');
                            });
                        });

                        try {
                            $('.btn_add_mine').click(function () {
                                $('.pane1').slideDown(20);
                                $('.pane2').slideUp(20);
                            });
                            $('.btn_choose').click(function () {
                                $('.pane1').slideUp(20);
                                $('.pane2').slideDown(20);
                            });
                        } catch (err) {
                            alert(err.message);
                        }
                        try {
                            $('.cbo_sector').change(function () {
                                var cbo_sector = $(this, 'option:selected').val();
                                $('#txt_sector_id2').val(cbo_sector);
                            });
                        } catch (err) {
                            alert(err.message);
                        }
                    });
        </script>
    </body>
</html>
<?php

function list_maid_by_cat($category) {
    require_once 'web_db/connection.php';
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select profile.profile_id, profile.name,maid.maid_id,maid.prefered_job,maid.sex, maid.experience,maid.salary, maid.religion from maid"
            . "    "
            . " join profile on profile.profile_id=maid.profile"
            . " where maid.prefered_job=:job";
    $stmt = $db->prepare($sql);
    $stmt->execute(array(":job" => $category));
    ?>
    <style>
        .dataList_table{
            border-collapse: collapse;
            width: 100%;
        }
        .dataList_table td{
            padding: 5px;
        }
        .dataList_table thead{
            text-transform: capitalize;
            background-color: #0c4561;
            color: #fff;

        }
    </style>
    <table class="dataList_table">
        <thead><tr>
                <td> name </td>
                <td> Gender </td>
                <td> Experience </td>
                <td> Salary </td>
                <td> Religion </td>
                <td> Choose </td>
            </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?>
            <tr> 
                <td class="sex_id_cols maid " title="maid" >
                    <?php echo $row['name']; ?>
                </td>
                <td class="sex_id_cols maid " title="maid" >
                    <?php echo $row['sex']; ?>
                </td>
                <td>
                    <?php echo $row['experience']; ?>
                </td>
                <td>
                    <?php echo $row['salary']; ?>
                </td>
                <td>
                    <?php echo $row['religion']; ?>
                </td>
                <td> <a href="#" class="choose_maid_link" data-bind="<?php echo $row['maid_id']; ?>" style="color: #fff6e0">Choose </a></td>
            </tr>
        <?php } ?></table>
    <?php
}

function list_maid_categories() {
    require_once 'web_db/connection.php';
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select profile.name, maid.education_level, maid.prefered_job  from maid"
            . " join profile on profile.profile_id=maid.profile"
            . " where maid.status='available'";
    ?>
    <style>
        .dataList_table{
            border-collapse: collapse;
            margin-top: 10px;
        }
        .dataList_table td{
            padding: 5px;
        }
        .dataList_table thead{
            text-transform: capitalize;
            background-color: #0c4561;
            color: #fff;

        }
        li{
            line-height: 3em;
            font-size: 12px;
            text-decoration: underline;
            text-transform: uppercase;
            color: #054811;
            font-weight: bolder;
        }
    </style>
    <ul>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
            <li>
                <?php echo $row['education_level']; ?>
            </li>
            <?php list_maid_by_cat($row['prefered_job']); ?> 

        <?php } ?></ul> 
    <?php
}

// <editor-fold defaultstate="collapsed" desc="---------Recruiter registration-------------">
function chosen_username_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $username = new multi_values();
            return $username->get_chosen_recruiter_username($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_password_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $password = new multi_values();
            return $password->get_chosen_recruiter_password($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_sector_combo() {
    $obj = new multi_values();
    $obj->get_sector_in_combo();
}

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function chosen_family_rep_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $family_rep_name = new multi_values();
            return $family_rep_name->get_chosen_recruiter_family_rep_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_number_members_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $number_members = new multi_values();
            return $number_members->get_chosen_recruiter_number_members($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_sector_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $sector = new multi_values();
            return $sector->get_chosen_recruiter_sector($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'recruiter') {
            $id = $_SESSION['id_upd'];
            $profile = new multi_values();
            return $profile->get_chosen_recruiter_profile($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>
class multi_values {

    function get_chosen_recruiter_family_rep_name($id) {

        $db = new dbconnection();
        $sql = "select   recruiter.family_rep_name from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['family_rep_name'];
        echo $field;
    }

    function get_chosen_recruiter_number_members($id) {
        require_once('web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.number_members from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['number_members'];
        echo $field;
    }

    function get_chosen_recruiter_sector($id) {
        require_once('web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.sector from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    }

    function get_chosen_recruiter_profile($id) {
        require_once('web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.profile from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function list_recruitment() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select recruitment.recruitment_id,recruitment.recruit_date,recruitment.salary_agreed "
                . " ,profile.name, profile.name  from recruitment "
                . " join maid on maid.maid_id=recruitment.maid"
                . " join profile on profile.profile_id=maid.profile"
                . " join recruiter on recruitment.recruiter=recruiter.recruiter_id ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> recruitment </td>
                    <td> recruit_date </td><td> maid </td><td> salary_agreed </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['recruitment_id']; ?>
                    </td>
                    <td class="recruit_date_id_cols recruitment " title="recruitment" >
                        <?php echo $row['recruit_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['salary_agreed']; ?>
                    </td>


                    <td>
                        <a href="#" class="recruitment_delete_link" style="color: #000080;" value="
                           <?php echo $row['recruitment_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="recruitment_update_link" style="color: #000080;" value="
                           <?php echo $row['recruitment_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function get_sector_in_combo() {
        require_once('web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="sml_combo cbo_sector" id="sp_combo_sectr"><option></option><option>-- Sector --</option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function get_lastprofile() {
        require_once('web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile.profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }

    function get_last_recruiter() {
        $con = new dbconnection();
        $sql = "select recruiter.recruiter_id from recruiter
                    order by recruiter.recruiter_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruiter_id'];
        return $first_rec;
    }

    function get_username_exists($username, $password) {
        $con = new dbconnection();
        $sql = "select account.username from account
                   where username=:username and password=:password";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":username" => $username, ":password" => $password));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['username'];
        return $first_rec;
    }

}

class new_values {

    function new_maid_request($entry_date, $User, $description) {
        try {
            require_once('web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into maid_request values(:maid_request_id, :entry_date,  :User,  :description)");
            $stm->execute(array(':maid_request_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':description' => $description
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_recruiter($n_members, $sector, $profile, $family_rep_name, $entry_date, $account, $phone) {
        try {
            if (!empty($sector)) {

                require_once('web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into recruiter values(:recruiter_id, :n_members,  :sector,  :profile,  :family_rep_name,  :entry_date,  :account,:phone)");
                $stm->execute(array(':recruiter_id' => 0, ':n_members' => $n_members, ':sector' => $sector, ':profile' => $profile, ':family_rep_name' => $family_rep_name, ':entry_date' => $entry_date, ':account' => $account, ':phone' => $phone));
            } else {
                ?><script>alert('You have to select sector');</script><?php
            }
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_recruitment($recruit_date, $maid, $recruiter, $salary_agreed, $user) {
        try {
            require_once('web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into recruitment values(:recruitment_id, :recruit_date,  :maid,  :recruiter,  :salary_agreed, :user)");
            $stm->execute(array(':recruitment_id' => 0, ':recruit_date' => $recruit_date, ':maid' => $maid, ':recruiter' => $recruiter, ':salary_agreed' => $salary_agreed, ':user' => $user
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
        try {
            require_once('web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
            $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}

class updates {

    function update_maid_statuss($status, $maid_id) {
        require_once './web_db/connection.php';
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE maid set  status=? WHERE maid_id=?");
        $stmt->execute(array($status, $maid_id));
    }

}
