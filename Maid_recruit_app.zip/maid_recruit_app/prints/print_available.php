<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select maid.village,maid.maid_id,  maid.sex,  maid.village,  maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status,  maid.id_number,profile.name as profile,  maid.phone from maid "
                    . " join profile on profile.profile_id = maid.profile  "
                    . " where status<>'requested' and status<> 'pending' and available='yes' ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Cell(120, 7, 'HOUSE WORKERS MIS', 0, 0, 'L');
            $this->Cell(60, 7, 'DISTRICT: KICUKIRO', 0, 0, 'L');
            $this->Ln();
            $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
            $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'AVAILABLE WORKERS REPORT ', 0, 0, 'C');
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 10);
// </editor-fold>

            $this->Cell(30, 7, 'WORKER', 1, 0, 'L');
            $this->Cell(30, 7, 'SEX', 1, 0, 'L');
            $this->Cell(30, 7, 'ID NUMBER', 1, 0, 'L');
            $this->Cell(50, 7, 'ID EDUCATION LEVEL', 1, 0, 'L');
            $this->Cell(30, 7, 'EXPERIENCE', 1, 0, 'L');
            $this->Cell(30, 7, 'RELIGION', 1, 0, 'L');
            $this->Cell(30, 7, 'PREFERED JOB', 1, 0, 'L');
            $this->Cell(30, 7, 'AVAILABLE', 1, 0, 'L');
            $this->Ln();
            foreach ($db->query($sql) as $row) {
                $this->cell(30, 7, $row['maid_id'], 1, 0, 'L');
                $this->cell(30, 7, $row['sex'], 1, 0, 'L');
                $this->cell(30, 7, $row['id_number'], 1, 0, 'L');
                $this->cell(50, 7, $row['education_level'], 1, 0, 'L');
                $this->cell(30, 7, $row['experience'], 1, 0, 'L');
                $this->cell(30, 7, $row['religion'], 1, 0, 'L');
                $this->cell(30, 7, $row['prefered_job'], 1, 0, 'L');
                $this->cell(30, 7, $row['status'], 1, 0, 'L');


                $this->Ln();
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 13);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->Output();
    