<?php

    class new_values {

        function new_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $phone, $username, $password, $salary) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into maid values(:maid_id, :sex,  :village,:id_number,   :experience,  :religion,  :prefered_job,  :available, "
                        . "                                  :profile,  :education_level,  :status, :phone, :username,:password,:salary)");
                $stm->execute(array(':maid_id' => 0, ':sex' => $sex, ':village' => $village, ':id_number' => $id_number, ':experience' => $experience, ':religion' => $religion, 
                                                    ':prefered_job' => $prefered_job, ':available' => $available, ':profile' => $profile, 
                                                    ':education_level' => $education_level, ':status' => $status, ':phone' => $phone,
                                                    ':username' => $username, ':password' => $password, ':salary' => $salary));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection(); 
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_certificates($maid, $file) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into certificates values(:certificates_id, :maid,  :file)");
                $stm->execute(array(':certificates_id' => 0, ':maid' => $maid, ':file' => $file
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }

    class multi_values {

        function get_village_in_combo() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select village.village_id,   village.name from village";
            ?>
            <select class="sml_combo" id="sp_combo_village"><option>-- Villages --</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_sector_in_combo() {

            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select sector.sector_id,   sector.name from sector";
            ?>
            <select class="sml_combo" required id="sp_combo_sectr"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_district_in_combo() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select district.district_id,   district.name from district";
            ?>
            <select class="sml_combo"><option>-- 
                    district ---</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cell_in_combo() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cell.cell_id,   cell.name from cell";
            ?>
            <select class="sml_combo" id="sp_combo_cell"><option>-- Cell --</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_lastprofile() {
            $db = new dbconnection();
            $sql = "select   profile.profile_id from profile order by profile.profile_id desc limit 1";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['profile_id'];
            return $userid;
        }

        function list_certificates($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from certificates";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> certificates </td>
                        <td> Maid </td><td> File </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['certificates_id']; ?>
                        </td>
                        <td class="maid_id_cols certificates " title="certificates" >
                            <?php echo $this->_e($row['maid']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['file']); ?>
                        </td>


                        <td>
                            <a href="#" class="certificates_delete_link" style="color: #000080;" data-id_delete="certificates_id"  data-table="
                               <?php echo $row['certificates_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="certificates_update_link" style="color: #000080;" value="
                               <?php echo $row['certificates_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_certificates_maid($id) {

            $db = new dbconnection();
            $sql = "select   certificates.maid from certificates where certificates_id=:certificates_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':certificates_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['maid'];
            echo $field;
        }

        function get_chosen_certificates_file($id) {

            $db = new dbconnection();
            $sql = "select   certificates.file from certificates where certificates_id=:certificates_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':certificates_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['file'];
            echo $field;
        }

        function All_certificates() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  certificates_id   from certificates";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_certificates() {
            $con = new dbconnection();
            $sql = "select certificates.certificates_id from certificates
                    order by certificates.certificates_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['certificates_id'];
            return $first_rec;
        }

        function get_last_certificates() {
            $con = new dbconnection();
            $sql = "select certificates.certificates_id from certificates
                    order by certificates.certificates_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['certificates_id'];
            return $first_rec;
        }

        function get_lastmaid() {

            $db = new dbconnection();
            $sql = "select   maid.maid_id from maid order by maid.maid_id desc limit 1";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['maid_id'];
            return $userid;
        }

    }

    class dbconnection {

        function openconnection() {
            $db = new PDO('mysql:host=localhost;dbname=maid_recruit;charset=utf8mb4', 'sangwa', 'A.manigu125');
            return $db;
        }

    }
    