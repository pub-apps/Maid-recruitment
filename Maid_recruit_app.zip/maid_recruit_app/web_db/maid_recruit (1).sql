-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2018 at 01:27 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `maid_recruit`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id` int(11) NOT NULL,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_category`, `date_created`, `profile`, `username`, `password`, `is_online`) VALUES
(20, 9, '2018-05-20', 46, 'julias', '3456', 'yes'),
(21, 9, '2018-05-20', 54, 'emma', '123123', 'yes'),
(22, 9, '2018-05-20', 56, 'george', '123123', 'yes'),
(23, 9, '2018-05-20', 57, 'ryan', '123123', 'yes'),
(24, 9, '2018-05-20', 58, 'yves', '12312', 'yes'),
(25, 9, '2018-05-20', 60, 'solange', '123123', 'yes'),
(26, 9, '2018-05-20', 61, 'didier', '123123', 'yes'),
(27, 9, '2018-05-20', 63, 'guru', '123123', 'yes'),
(28, 9, '2018-05-20', 64, 'hurio', '123123', 'yes'),
(29, 8, '2018-05-27', 65, 'janvier', '123', 'yes'),
(40, 8, '2018-05-27', 85, 'janvier', '123', 'yes'),
(41, 9, '2018-05-30', 113, 'byubyu', '123', 'yes'),
(42, 9, '2018-05-30', 115, 'mubo', '123', 'yes'),
(43, 9, '2018-05-30', 117, 'mute', '123', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account_category`
--

INSERT INTO `account_category` (`account_category_id`, `name`) VALUES
(8, 'admin'),
(9, 'recruiter');

-- --------------------------------------------------------

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cell`
--

INSERT INTO `cell` (`cell_id`, `name`, `sector`) VALUES
(1, 'Kora', 13),
(2, 'Kinyange', 13),
(3, 'Akabeza', 13),
(4, 'Akabahizi', 13),
(5, 'Kigarama', 13),
(6, NULL, 13),
(7, 'juru', 4);

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE IF NOT EXISTS `certificates` (
`certificates_id` int(11) NOT NULL,
  `maid` int(11) DEFAULT NULL,
  `file` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`certificates_id`, `maid`, `file`) VALUES
(8, 27, '1'),
(9, 28, '9'),
(10, 29, '10'),
(11, 30, '11'),
(12, 30, '12'),
(13, 30, '13'),
(14, 30, '14'),
(15, 30, '15'),
(16, 30, '16'),
(17, 30, '17'),
(18, 30, '18'),
(19, 30, '19'),
(20, 30, '20'),
(21, 30, '21'),
(22, 30, '22'),
(23, 31, '23'),
(24, 37, '24'),
(25, 38, '25'),
(26, 39, '26'),
(27, 37, '27'),
(28, 38, '28'),
(29, 39, '29'),
(30, 39, '30'),
(31, 39, '31'),
(32, 40, '32'),
(33, 41, '33'),
(34, 42, '34'),
(35, 43, '35'),
(36, 44, '36'),
(37, 42, '37'),
(38, 43, '38'),
(39, 44, '39'),
(40, 45, '40'),
(41, 46, '41');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`contact_us_id` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `date_contact` date DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `province` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`district_id`, `name`, `province`) VALUES
(1, 'Kicukiro', 8),
(2, 'Nyarugenge', 8),
(3, 'Gasabo', 8);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id` int(11) NOT NULL,
  `path` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `maid`
--

CREATE TABLE IF NOT EXISTS `maid` (
`maid_id` int(11) NOT NULL,
  `sex` varchar(60) DEFAULT NULL,
  `village` int(11) DEFAULT NULL,
  `id_number` varchar(60) DEFAULT NULL,
  `experience` varchar(60) DEFAULT NULL,
  `religion` varchar(60) DEFAULT NULL,
  `prefered_job` varchar(60) DEFAULT NULL,
  `available` varchar(60) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `education_level` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `maid`
--

INSERT INTO `maid` (`maid_id`, `sex`, `village`, `id_number`, `experience`, `religion`, `prefered_job`, `available`, `profile`, `education_level`, `status`, `phone`) VALUES
(16, 'Male', 11, '12143', 'Cooking, cleaning', 'Catholique', 'Cooking', 'no', 11, NULL, 'available', NULL),
(17, 'Male', 11, '1234112341324', 'Cooking, cleaning', 'Catholique', 'Food preparation', 'yes', 14, 'Not finished primary school', 'available', NULL),
(18, 'Male', 11, '1123849132047', 'Cleaning', 'Protestant', 'Cleaning', 'yes', 15, 'Finished only primary school', 'available', NULL),
(19, 'Male', 11, '1123412423', 'asdfa', 'Protestant', 'House work assistant', 'yes', 19, 'Graduated Bachelor degree school', 'available', NULL),
(20, 'Female', 11, '1104985585748', 'Baby sitter', 'Catholique', 'Baby sitting', 'yes', 20, 'Finished A level school', 'available', NULL),
(21, 'Male', 11, '2423434', 'Food analysis', 'Protestant', 'Food preparation', 'yes', 22, 'Finished only primary school', 'available', NULL),
(25, 'Male', 11, '1193848', 'Cooking', 'Catholique', 'Cleaning', 'yes', 27, 'Finished A level school', 'requested', NULL),
(26, 'Male', 11, '119349594893', 'Preparing food', 'Catholique', 'Food preparation', 'yes', 76, 'Finished only primary school', '', NULL),
(32, 'Male', 11, '112345325234', 'Cooking', 'Catholique', 'Cleaning', 'yes', 93, 'Finished only primary school', 'available', NULL),
(33, 'Female', 11, '119832857746', 'Cleaning', 'Muslim', 'Cleaning', 'yes', 94, 'Not finished primary school', 'available', NULL),
(34, 'Female', 11, '119832857746', 'Cleaning', 'Muslim', 'Cleaning', 'yes', 95, 'Not finished primary school', 'available', NULL),
(35, 'Female', 11, '119832857746', 'Cleaning', 'Muslim', 'Cleaning', 'yes', 96, 'Not finished primary school', 'available', NULL),
(36, 'Male', 11, '11983458732459', 'Cooking, cleaning', 'Muslim', 'Food preparation', 'yes', 97, 'Not finished primary school', 'available', NULL),
(42, 'Male', 11, '1877874', '5years in cooking', 'musilm', 'Food preparation', 'yes', 111, 'Finished A level school', 'available', '52225662'),
(43, 'Male', 11, '1975555555555555', '1.5 of years', 'AEBR', 'House work assistant', 'yes', 112, 'Finished only primary school', 'available', '2508795462'),
(44, 'Male', 11, '1989744545455122', '3years', 'musilm', 'Cleaning', 'yes', 114, 'Finished only primary school', 'no', '0784566623'),
(45, 'Male', 11, '1787554545556656', '5years in cooking', 'catholique', 'Food preparation', 'yes', 116, 'Not finished primary school', 'available', '7845555556'),
(46, 'Male', 11, '1998456623125545', '10years', 'cathorique', 'Food preparation', 'yes', 118, 'Finished A level school', 'pending', '0487542315');

-- --------------------------------------------------------

--
-- Table structure for table `maid_request`
--

CREATE TABLE IF NOT EXISTS `maid_request` (
`maid_request_id` int(11) NOT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  `description` varchar(560) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `maid_request`
--

INSERT INTO `maid_request` (`maid_request_id`, `entry_date`, `User`, `description`) VALUES
(8, '2018-05-20', '14', '  asdfaskldfja sdflsjd fas fasjk dfsklf ;askjlf '),
(9, '2018-05-20', '15', '  sadfsdf'),
(10, '2018-05-20', '16', '  asdfasdf'),
(11, '2018-05-20', '17', '  asdfasdf'),
(12, '2018-05-20', '18', '  asdfasdfas'),
(13, '2018-05-20', '19', '  sadsaf'),
(14, '2018-05-20', '20', '  sadsaf'),
(15, '2018-05-20', '21', 'asklfjaa  '),
(16, '2018-05-20', '22', '  asdfasf  sadf'),
(17, '2018-05-20', '23', 'askjf asdfkj sadfjk  '),
(18, '2018-05-20', '24', 'aklj asfaksjlf a  '),
(19, '2018-05-20', '25', 'solange good  '),
(20, '2018-05-20', '26', 'didier should advise  '),
(21, '2018-05-20', '27', 'guru guru  '),
(22, '2018-05-20', '28', 'asdkasf fkasfsdf  '),
(23, '2018-05-20', '29', 'ASDFJ SDKJF AS;LFJ  '),
(24, '2018-05-20', '30', 'juma  '),
(25, '2018-05-20', '31', '  james');

-- --------------------------------------------------------

--
-- Table structure for table `org`
--

CREATE TABLE IF NOT EXISTS `org` (
`org_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_id`, `dob`, `name`, `last_name`, `gender`, `telephone_number`, `email`, `residence`, `image`) VALUES
(1, '2018-04-13', 'Patrick', '', '', '', '', '', 0),
(2, '2018-04-13', 'Patrick', '', '', '', '', '', 0),
(3, '2018-04-13', NULL, '', '', '', '', '', 0),
(4, '2018-04-13', 'Jean', '', '', '', '', '', 0),
(5, '2018-04-13', 'christian', '', '', '', '', '', 0),
(6, '2018-04-13', 'Thierry', '', '', '', '', '', 0),
(7, '2018-04-13', 'John', '', '', '', '', '', 0),
(8, '2018-04-13', 'Gisele', '', '', '', '', '', 0),
(9, '2018-04-13', 'FRANCOIS BAHIZI', '', '', '', '', '', 0),
(10, '2018-04-13', 'Patrick MUHIRE', '', '', '', '', '', 0),
(11, '2018-04-13', 'FRANCOIS MUHIRE', '', '', '', '', '', 0),
(12, '2018-04-13', 'Baptiste UWAMBAJE', '', '', '', '', '', 0),
(13, '2018-04-13', 'Baptiste UWAMBAJE', '', '', '', '', '', 0),
(14, '2018-04-13', 'Baptiste UWAMBAJE', '', '', '', '', '', 0),
(15, '2018-04-13', 'Olivier', '', '', '', '', '', 0),
(16, '2018-04-13', 'Jack HABIMANA', '', '', '', '', '', 0),
(17, '2018-04-13', 'Jack HABIMANA', '', '', '', '', '', 0),
(18, '2018-04-13', 'Jack HABIMANA', '', '', '', '', '', 0),
(19, '2018-04-13', 'Jack HABIMANA', '', '', '', '', '', 0),
(20, '2018-04-15', 'Florence UWAMBAJE', '', '', '', '', '', 0),
(21, '2018-04-15', 'Philippe', '', '', '', '', '', 0),
(22, '2018-04-17', 'Eric NSANZIMFURA', '', '', '', '', '', 0),
(23, '2018-04-17', 'Asman MUHAMED', '', '', '', '', '', 0),
(24, '2018-04-19', 'asdf', '', '', '', '', '', 0),
(25, '2018-04-19', 'asdf', '', '', '', '', '', 0),
(26, '2018-04-19', 'asdf', '', '', '', '', '', 0),
(27, '2018-04-19', 'Jean de la Croix', '', '', '', '', '', 0),
(28, '2018-05-19', 'test name', '', '', '', '', '', 0),
(29, '2018-05-20', 'adfk', '', '', '', '', '', 0),
(30, '2018-05-20', 'adfk', '', '', '', '', '', 0),
(31, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(32, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(33, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(34, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(35, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(36, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(37, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(38, '2018-05-20', 'sdfasdf asdasdf', '', '', '', '', '', 0),
(39, '2018-05-20', 'asdfkjl', '', '', '', '', '', 0),
(40, '2018-05-20', 'asdfkjl', '', '', '', '', '', 0),
(41, '2018-05-20', 'asdkljf', '', '', '', '', '', 0),
(42, '2018-05-20', 'asdf', '', '', '', '', '', 0),
(43, '2018-05-20', 'asdf', '', '', '', '', '', 0),
(44, '2018-05-20', 'zdasf', '', '', '', '', '', 0),
(45, '2018-05-20', 'julia', '', '', '', '', '', 0),
(46, '2018-05-20', 'julia', '', '', '', '', '', 0),
(47, '2018-05-20', 'julia', '', '', '', '', '', 0),
(48, '2018-05-20', 'julia', '', '', '', '', '', 0),
(49, '2018-05-20', 'asdfjakls', '', '', '', '', '', 0),
(50, '2018-05-20', 'asdfjakls', '', '', '', '', '', 0),
(51, '2018-05-20', 'asdfjakls', '', '', '', '', '', 0),
(52, '2018-05-20', 'asdfkjl', '', '', '', '', '', 0),
(53, '2018-05-20', 'asdf', '', '', '', '', '', 0),
(54, '2018-05-20', 'askfj', '', '', '', '', '', 0),
(55, '2018-05-20', 'askfj', '', '', '', '', '', 0),
(56, '2018-05-20', 'asdfkj', '', '', '', '', '', 0),
(57, '2018-05-20', 'asdf', '', '', '', '', '', 0),
(58, '2018-05-20', 'sfaskljf', '', '', '', '', '', 0),
(59, '2018-05-20', 'sfaskljf', '', '', '', '', '', 0),
(60, '2018-05-20', 'akdfjl', '', '', '', '', '', 0),
(61, '2018-05-20', 'alpha', '', '', '', '', '', 0),
(62, '2018-05-20', 'askjlf', '', '', '', '', '', 0),
(63, '2018-05-20', 'asfj', '', '', '', '', '', 0),
(64, '2018-05-20', 'asdklf', '', '', '', '', '', 0),
(65, '2018-05-20', 'asdklf', '', '', '', '', '', 0),
(66, '2018-05-20', 'asjd', '', '', '', '', '', 0),
(67, '2018-05-20', 'jumma', '', '', '', '', '', 0),
(68, '2018-05-20', 'James', '', '', '', '', '', 0),
(69, '2018-05-20', 'Jeannette', '', '', '', '', '', 0),
(70, '2018-05-20', 'Tino', '', '', '', '', '', 0),
(71, '2018-05-20', 'Vumilia', '', '', '', '', '', 0),
(72, '2018-05-20', 'Juliette', '', '', '', '', '', 0),
(73, '2018-05-20', 'Eric', '', '', '', '', '', 0),
(74, '2018-05-20', 'Eric', '', '', '', '', '', 0),
(75, '2018-05-20', 'Fiacle', '', '', '', '', '', 0),
(76, '2018-05-20', 'Gallo', '', '', '', '', '', 0),
(77, '2018-05-21', 'asdkfj', '', '', '', '', '', 0),
(78, '2018-05-21', 'asdkfj', '', '', '', '', '', 0),
(79, '2018-05-21', 'asdkfj', '', '', '', '', '', 0),
(80, '2018-05-21', 'askdfh', '', '', '', '', '', 0),
(81, '2018-05-21', 'aksdfjl', '', '', '', '', '', 0),
(82, '2018-05-21', 'aksdfjl', '', '', '', '', '', 0),
(83, '2018-05-21', 'adsklf', '', '', '', '', '', 0),
(84, '2018-05-21', 'jumma', '', '', '', '', '', 0),
(85, '2018-05-21', 'jumma', '', '', '', '', '', 0),
(86, '2018-05-21', 'jumma', '', '', '', '', '', 0),
(87, '2018-05-21', 'aklsfd', '', '', '', '', '', 0),
(88, '2018-05-21', 'as', '', '', '', '', '', 0),
(89, '2018-05-21', 'as', '', '', '', '', '', 0),
(90, '2018-05-21', 'as', '', '', '', '', '', 0),
(91, '2018-05-21', 'bool', '', '', '', '', '', 0),
(92, '2018-05-23', 'Bella', '', '', '', '', '', 0),
(93, '2018-05-23', 'mabool', '', '', '', '', '', 0),
(94, '2018-05-23', 'Esther', '', '', '', '', '', 0),
(95, '2018-05-23', 'Esther', '', '', '', '', '', 0),
(96, '2018-05-23', 'Esther', '', '', '', '', '', 0),
(97, '2018-05-23', 'Vumi', '', '', '', '', '', 0),
(98, '2018-05-23', 'Vumi', '', '', '', '', '', 0),
(99, '2018-05-23', 'Vumi', '', '', '', '', '', 0),
(100, '2018-05-23', 'Oreste', '', '', '', '', '', 0),
(101, '2018-05-26', 'FRANCOIS', '', '', '', '', '', 0),
(102, '2018-05-26', 'jules', '', '', '', '', '', 0),
(103, '2018-05-26', 'FRANCOIS MUVUNNYI', '', '', '', '', '', 0),
(104, '2018-05-26', 'Marie', '', '', '', '', '', 0),
(105, '2018-05-26', 'Marie', '', '', '', '', '', 0),
(106, '2018-05-26', 'Yves', '', '', '', '', '', 0),
(107, '2018-05-26', 'Yves', '', '', '', '', '', 0),
(108, '2018-05-26', 'Yves', '', '', '', '', '', 0),
(109, '2018-05-26', 'Jean Luc', '', '', '', '', '', 0),
(110, '2018-05-26', 'Jean Luc', '', '', '', '', '', 0),
(111, '2018-05-30', 'musemakweri chris depaye', '', '', '', '', '', 0),
(112, '2018-05-30', 'museminari arstide', '', '', '', '', '', 0),
(113, '2018-05-30', 'byuukusenge', '', '', '', '', '', 0),
(114, '2018-05-30', 'muhire fidele', '', '', '', '', '', 0),
(115, '2018-05-30', 'muganga boris', '', '', '', '', '', 0),
(116, '2018-05-30', 'mujyanama kaka', '', '', '', '', '', 0),
(117, '2018-05-30', 'mutegaraba anitha', '', '', '', '', '', 0),
(118, '2018-05-30', 'bahire elysa', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`province_id`, `name`) VALUES
(8, 'Kigali'),
(9, 'North'),
(10, 'South'),
(11, 'East'),
(12, 'West');

-- --------------------------------------------------------

--
-- Table structure for table `recruiter`
--

CREATE TABLE IF NOT EXISTS `recruiter` (
`recruiter_id` int(11) NOT NULL,
  `family_rep_name` varchar(60) DEFAULT NULL,
  `number_members` int(11) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `recruiter`
--

INSERT INTO `recruiter` (`recruiter_id`, `family_rep_name`, `number_members`, `sector`, `profile`, `entry_date`, `account`) VALUES
(15, 'kasjf', 3, 9, 61, '2018-05-20', 26),
(16, 'sdfkjl', 7, 6, 63, '2018-05-20', 27),
(18, 'bobo', 7, 3, 115, '2018-05-30', 42),
(19, 'mutegaraba', 2147483647, 4, 117, '2018-05-30', 43);

-- --------------------------------------------------------

--
-- Table structure for table `recruitment`
--

CREATE TABLE IF NOT EXISTS `recruitment` (
`recruitment_id` int(11) NOT NULL,
  `recruit_date` date DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `recruiter` int(11) DEFAULT NULL,
  `salary_agreed` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `returned_maid`
--

CREATE TABLE IF NOT EXISTS `returned_maid` (
`return_id` int(11) NOT NULL,
  `return_date` date DEFAULT NULL,
  `reason` varchar(60) DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `comment` varchar(400) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `returned_maid`
--

INSERT INTO `returned_maid` (`return_id`, `return_date`, `reason`, `maid`, `comment`) VALUES
(5, '2018-04-13', 'He is done with job', 16, 'the boss has terminated the contract because he was shifting to another location'),
(6, '2018-04-13', 'He has looked down on boss', 16, 'He cant well behave'),
(8, '2018-04-17', 'job is finished', 21, 'he finished is jib according to period due'),
(9, '2018-04-27', 'he finished required job', 17, 'the job went very well');

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `district` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`sector_id`, `name`, `district`) VALUES
(1, 'Nyamirambo', 2),
(2, 'Muhima', 2),
(3, 'Nyamirambo', 2),
(4, 'Gatenga', 1),
(5, 'Kucukiro', 1),
(6, 'Kagarama', 1),
(7, 'Niboye', 1),
(8, 'Gatsata', 3),
(9, 'Karuruma', 3),
(10, 'Remera', 3),
(11, 'Kabuga', 3),
(12, 'Ndera', 3),
(13, 'Gitega', 2);

-- --------------------------------------------------------

--
-- Table structure for table `village`
--

CREATE TABLE IF NOT EXISTS `village` (
`village_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `village`
--

INSERT INTO `village` (`village_id`, `name`, `cell`) VALUES
(11, 'ituze', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`account_id`), ADD KEY `cat_acc_idx` (`account_category`);

--
-- Indexes for table `account_category`
--
ALTER TABLE `account_category`
 ADD PRIMARY KEY (`account_category_id`);

--
-- Indexes for table `cell`
--
ALTER TABLE `cell`
 ADD PRIMARY KEY (`cell_id`), ADD KEY `cell_sectore_idx` (`sector`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
 ADD PRIMARY KEY (`certificates_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
 ADD PRIMARY KEY (`contact_us_id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
 ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
 ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `maid`
--
ALTER TABLE `maid`
 ADD PRIMARY KEY (`maid_id`), ADD KEY `maid_profile_idx` (`profile`), ADD KEY `maid_village_idx` (`village`);

--
-- Indexes for table `maid_request`
--
ALTER TABLE `maid_request`
 ADD PRIMARY KEY (`maid_request_id`);

--
-- Indexes for table `org`
--
ALTER TABLE `org`
 ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
 ADD PRIMARY KEY (`profile_id`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
 ADD PRIMARY KEY (`province_id`);

--
-- Indexes for table `recruiter`
--
ALTER TABLE `recruiter`
 ADD PRIMARY KEY (`recruiter_id`), ADD KEY `recruiter_acc_idx` (`account`);

--
-- Indexes for table `recruitment`
--
ALTER TABLE `recruitment`
 ADD PRIMARY KEY (`recruitment_id`), ADD KEY `recrtment_recrt_idx` (`recruiter`), ADD KEY `recrtmnt_maid_idx` (`maid`);

--
-- Indexes for table `returned_maid`
--
ALTER TABLE `returned_maid`
 ADD PRIMARY KEY (`return_id`), ADD KEY `return_maid_idx` (`maid`);

--
-- Indexes for table `sector`
--
ALTER TABLE `sector`
 ADD PRIMARY KEY (`sector_id`), ADD KEY `sector_district_idx` (`district`);

--
-- Indexes for table `village`
--
ALTER TABLE `village`
 ADD PRIMARY KEY (`village_id`), ADD KEY `village_cell_idx` (`cell`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `account_category`
--
ALTER TABLE `account_category`
MODIFY `account_category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `cell`
--
ALTER TABLE `cell`
MODIFY `cell_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
MODIFY `certificates_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
MODIFY `contact_us_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `maid`
--
ALTER TABLE `maid`
MODIFY `maid_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `maid_request`
--
ALTER TABLE `maid_request`
MODIFY `maid_request_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `org`
--
ALTER TABLE `org`
MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=119;
--
-- AUTO_INCREMENT for table `province`
--
ALTER TABLE `province`
MODIFY `province_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `recruiter`
--
ALTER TABLE `recruiter`
MODIFY `recruiter_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `recruitment`
--
ALTER TABLE `recruitment`
MODIFY `recruitment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `returned_maid`
--
ALTER TABLE `returned_maid`
MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `sector`
--
ALTER TABLE `sector`
MODIFY `sector_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `village`
--
ALTER TABLE `village`
MODIFY `village_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
ADD CONSTRAINT `cat_acc` FOREIGN KEY (`account_category`) REFERENCES `account_category` (`account_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cell`
--
ALTER TABLE `cell`
ADD CONSTRAINT `cell_sectore` FOREIGN KEY (`sector`) REFERENCES `sector` (`sector_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `maid`
--
ALTER TABLE `maid`
ADD CONSTRAINT `maid_profile` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
ADD CONSTRAINT `maid_village` FOREIGN KEY (`village`) REFERENCES `village` (`village_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `recruiter`
--
ALTER TABLE `recruiter`
ADD CONSTRAINT `recruiter_acc` FOREIGN KEY (`account`) REFERENCES `account` (`account_id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `recruitment`
--
ALTER TABLE `recruitment`
ADD CONSTRAINT `recrtment_recrt` FOREIGN KEY (`recruiter`) REFERENCES `recruiter` (`recruiter_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
ADD CONSTRAINT `recrtmnt_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `returned_maid`
--
ALTER TABLE `returned_maid`
ADD CONSTRAINT `return_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `sector`
--
ALTER TABLE `sector`
ADD CONSTRAINT `sector_district` FOREIGN KEY (`district`) REFERENCES `district` (`district_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `village`
--
ALTER TABLE `village`
ADD CONSTRAINT `village_cell` FOREIGN KEY (`cell`) REFERENCES `cell` (`cell_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
