<?php

    class new_values {

        function new_certificates($maid, $file) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into certificates values(:certificates_id, :maid,  :file)");
                $stm->execute(array(':certificates_id' => 0, ':maid' => $maid, ':file' => $file
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account_category($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
                $stm->execute(array(':account_category_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_image($path) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into image values(:image_id, :path)");
                $stm->execute(array(':image_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_province($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into province values(:province_id, :name)");
                $stm->execute(array(':province_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_district($name, $province) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into district values(:district_id, :name,  :province)");
                $stm->execute(array(':district_id' => 0, ':name' => $name, ':province' => $province
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sector($name, $district) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sector values(:sector_id, :name,  :district)");
                $stm->execute(array(':sector_id' => 0, ':name' => $name, ':district' => $district
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cell($name, $sector) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cell values(:cell_id, :name,  :sector)");
                $stm->execute(array(':cell_id' => 0, ':name' => $name, ':sector' => $sector
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_contact_us($account, $date_contact, $message) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into contact_us values(:contact_us_id, :account,  :date_contact,  :message)");
                $stm->execute(array(':contact_us_id' => 0, ':account' => $account, ':date_contact' => $date_contact, ':message' => $message
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_village($name, $cell) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into village values(:village_id, :name,  :cell)");
                $stm->execute(array(':village_id' => 0, ':name' => $name, ':cell' => $cell
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_org($name, $phone, $address) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into org values(:org_id, :name,  :phone,  :address)");
                $stm->execute(array(':org_id' => 0, ':name' => $name, ':phone' => $phone, ':address' => $address
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_recruiter($n_members, $sector, $profile, $family_rep_name, $entry_date, $account, $phone) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into recruiter values(:recruiter_id, :n_members,  :sector,  :profile,  :family_rep_name,  :entry_date,  :account, :phone)");
                $stm->execute(array(':recruiter_id' => 0, ':n_members' => $n_members, ':sector' => $sector, ':profile' => $profile, ':family_rep_name' => $family_rep_name, ':entry_date' => $entry_date, ':account' => $account, ':phone' => $phone));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_recruitment($recruit_date, $maid, $recruiter, $salary_agreed, $user) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into recruitment values(:recruitment_id, :recruit_date,  :maid,  :recruiter,  :salary_agreed, :user)");
                $stm->execute(array(':recruitment_id' => 0, ':recruit_date' => $recruit_date, ':maid' => $maid, ':recruiter' => $recruiter, ':salary_agreed' => $salary_agreed, ':user' => $user
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_return($return_date, $reason, $maid, $comment) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into returned_maid values(:return_id, :return_date,  :reason,  :maid,  :comment)");
                $stm->execute(array(':return_id' => 0, ':return_date' => $return_date, ':reason' => $reason, ':maid' => $maid, ':comment' => $comment
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_maid($sex, $village, $id_number, $edu_level, $experience, $religion, $prefered_job, $available, $profile, $status, $phone, $username, $password, $salary) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into maid values(:maid_id, :sex,  :village,  :id_number,:education_level, :experience,  :religion,  :prefered_job,  :available, :profile, :status,  :phone,:username,:password,:salary)");
                $stm->execute(array(':maid_id' => 0, ':sex' => $sex, ':village' => $village, ':id_number' => $id_number, ':education_level' => $edu_level, ':experience' => $experience, ':religion' => $religion, ':prefered_job' => $prefered_job, ':available' => $available, ':profile' => $profile, ':status' => $status, ':phone' => $phone, ':username' => $username, ':password' => $password, ':salary' => $salary));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_maid_request($entry_date, $User, $description) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into maid_request values(:maid_request_id, :entry_date,  :User,  :description)");
                $stm->execute(array(':maid_request_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':description' => $description
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }
    