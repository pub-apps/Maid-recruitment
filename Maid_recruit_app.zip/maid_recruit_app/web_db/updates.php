<?php

    require_once 'connection.php';

    class updates {

        function update_account($profile, $username, $password, $is_online, $account_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account set   profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
            $stmt->execute(array($profile, $username, $password, $is_online, $account_id));
        }

        function update_account_category($name, $account_category_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account_category set name= ? WHERE account_category_id=?");
            $stmt->execute(array($name, $account_category_id));
        }

        function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE profile set dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
            $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
        }

        function update_profname_by_maid($name, $profile) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE profile set  name= ? WHERE profile_id =?");
                $stmt->execute(array($name, $profile));
            } catch (PDOException $exc) {
                echo $exc->getMessage();
            }
        }

        function update_image($path, $image_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE image set path= ? WHERE image_id=?");
            $stmt->execute(array($path, $image_id));
        }

        function update_province($name, $province_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE province set name= ? WHERE province_id=?");
            $stmt->execute(array($name, $province_id));
        }

        function update_district($name, $province, $district_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE district set 
name= ?, province= ? WHERE district_id=?");
            $stmt->execute(array($name, $province, $district_id));
        }

        function update_sector($name, $district, $sector_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE sector set 
name= ?, district= ? WHERE sector_id=?");
            $stmt->execute(array($name, $district, $sector_id));
        }

        function update_cell($name, $sector, $cell_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
            $stmt->execute(array($name, $sector, $cell_id));
        }

        function update_contact_us($account, $date_contact, $message, $contact_us_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE contact_us set 
account= ?, date_contact= ?, message= ? WHERE contact_us_id=?");
            $stmt->execute(array($account, $date_contact, $message, $contact_us_id));
        }

        function update_village($name, $cell, $village_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE village set 
name= ?, cell= ? WHERE village_id=?");
            $stmt->execute(array($name, $cell, $village_id));
        }

        function update_org($name, $phone, $address, $org_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE org set 
name= ?, phone= ?, address= ? WHERE org_id=?");
            $stmt->execute(array($name, $phone, $address, $org_id));
        }

        function update_recruiter($family_rep_name, $number_members, $sector, $profile, $recruiter_id) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE recruiter set family_rep_name= ?, number_members= ?, sector= ?, profile= ? WHERE recruiter_id=?");
                $stmt->execute(array($family_rep_name, $number_members, $sector, $profile, $recruiter_id));
            } catch (PDOException $exc) {
                echo $exc->getMessage();
            }
        }

        function update_recruitment($salary_agreed, $recruitment_id) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE recruitment set  salary_agreed= ? WHERE recruitment_id=?");
                $stmt->execute(array($salary_agreed, $recruitment_id));
            } catch (PDOException $exc) {
                echo $exc->getMessage();
            }
        }

        function update_return($reason, $comment, $return_id) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE returned_maid set  reason= ?, comment= ? WHERE return_id=?");
                $stmt->execute(array($reason, $comment, $return_id));
            } catch (PDOException $exc) {
                echo $exc->getMessage();
            }
        }

        function update_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $maid_id) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE maid set sex= ?, village= ?, id_number= ?, experience= ?, religion= ?, prefered_job= ?, available= ? WHERE maid_id=?");
                $stmt->execute(array($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $maid_id));
            } catch (PDOException $exc) {
                echo $exc->getMessage();
            }
        }

        function update_maid_available($status, $maid) {

            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE maid set available= ? WHERE maid_id=?");
                $stmt->execute(array($status, $maid));
            } catch (Exception $exc) {
                echo $exc->getMessage();
            }
        }

        function update_maid_status($status, $maid_id) {
            try {
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE maid set status= ? WHERE maid_id=?");
                $stmt->execute(array($status, $maid_id));
            } catch (Exception $exc) {
                echo $exc->getMessage();
            }
        }

        function update_maid_statuss($status, $maid_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE maid set status= ? WHERE maid_id=?");
            $stmt->execute(array($status, $maid_id));
        }

    }
    