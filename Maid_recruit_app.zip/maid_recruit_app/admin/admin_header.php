<?php

    function admin_menu() {
        ?>
        <div class="parts menu eighty_centered no_paddin_shade_no_Border reverse_border">
<!--            <div class="parts allow_drop">
                Users
                <div class="hovable_item">
                    <a href="new_account.php">account</a>
                    <a href="new_account_category.php">account_category</a>
                    <a href="new_profile.php">profile</a>
                    <a href="new_image.php">image</a>
                </div>
            </div>-->
<!--            <div class="parts allow_drop offf">
                Locations
                <div class="parts hovable_item">
                    <a href="new_province.php">province</a>
                    <a href="new_district.php">district</a>
                    <a href="new_sector.php">sector</a>
                    <a href="new_cell.php">cell</a>
                    <a href="new_village.php">village</a>
                </div>
            </div>-->
            <div class="parts allow_drop">
                <a href="new_maid.php">Maid</a>
            </div>
            <div class="parts allow_drop">
                <a href="new_recruiter.php">Family</a></div>
            <div class="parts allow_drop">
                <a href="new_recruitment.php">Recruitment</a></div>
            <div class="parts allow_drop">
                <a href="new_return.php">returned Maids</a>
            </div>
            <div class="parts allow_drop">
                <a href="Report.php">Reports</a>
            </div>
<div class="parts  heit_free no_paddin_shade_no_Border" style="margin-top: 14px">
                <a href="../logout.php">Logout</a>
            </div>
        </div>
        <?php
    }

    function recruiter() {
        ?>
        <div class="parts menu eighty_centered no_paddin_shade_no_Border reverse_border">
            <div class="parts allow_drop">
                <a href="new_recruitment.php">My maids</a>
            </div>
            <div class="parts allow_drop">
                <a href="new_recruiter.php">My Profile</a></div>
            <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="../logout.php">Logout</a>
            </div>
        </div> 
        <?php
    }

    function maid() {
        ?>
        <div class="parts menu eighty_centered no_paddin_shade_no_Border reverse_border">
            <div class="parts allow_drop">
                <a href="new_recruitment.php">My Recruitments</a>
            </div>
            <div class="parts allow_drop">
                <a href="new_recruiter.php">My Profile</a></div>
            <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="../logout.php">Logout</a>
            </div>
        </div> 
        <?php
    }
?>
<div class="parts  eighty_centered adm_header no_shade_noBorder">    
    <div class="parts  no_paddin_shade_no_Border no_shade_noBorder xxx_titles ">
        <marquee>MAID RECRUITMENT MANAGEMENT SYSTEM</marquee>
    </div>
</div>     

<?php
    if ($_SESSION['cat'] == 'admin') {
        admin_menu();
    } else if ($_SESSION['cat'] == 'recruiter') {
        recruiter();
    } else {
        maid();
    }


