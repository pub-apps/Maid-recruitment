<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_recruitment'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'recruitment') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $recruitment_id = $_SESSION['id_upd'];
                $recruit_date = date('y-m-d');
                $maid = $_POST['txt_maid_id'];
                $recruiter = $_POST['txt_recruiter_id'];
                $salary_agreed = $_POST['txt_salary_agreed'];
                $upd_obj->update_recruitment($salary_agreed, $recruitment_id);
                unset($_SESSION['table_to_update']);
                ?><script>alert('Update done successfully!');</script><?php
            }
        } else {
            $recruit_date = date('y-m-d');
            $maid = trim($_POST['txt_maid_id']);
            $recruiter = trim($_POST['txt_recruiter_id']);
            $salary_agreed = $_POST['txt_salary_agreed'];
            require_once '../web_db/new_values.php';
            $user = $_SESSION['userid'];
            $obj = new new_values();
            require_once '../web_db/updates.php';
            $upds = new updates();
            if ($_SESSION['cat'] == 'recruiter') {//if the logged in user is recruiter
                $m = new multi_values();
                $upds->update_maid_status('requested', $maid);
                $rec_id = $m->get_recruiter_prifileid($_SESSION['userid']);
                $obj->new_recruitment($recruit_date, $maid, $rec_id, $salary_agreed, $user);
            } else {
                $upds->update_maid_status('recruited', $maid);
                $obj->new_recruitment($recruit_date, $maid, $recruiter, $salary_agreed, $user);
            }
        }
    }
?>

<html>
    <head>
        <title>
            Hiring
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>  
    <body>
        <form action="new_recruitment.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_maid_id"   name="txt_maid_id"/>
            <input type="hidden" id="txt_recruiter_id"   name="txt_recruiter_id"/>
            <input type="hidden" id="txt_shall_expand_toUpdate"   name="txt_shall_expand_toUpdate" value="<?php echo $res = (isset($_SESSION['table_to_update'])) ? $_SESSION['table_to_update'] : '' ?>"/>
            <?php
                include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  
                </div> 
            </div>
            <div class="parts eighty_centered off saved_dialog">
                Hiring saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title"> new Recruitment</div>
                <table class="new_data_table">
                    <?php
                        if (!isset($_SESSION['table_to_update'])) {
                            if ($_SESSION['cat'] == 'recruiter') {
                                ?><tr><td>worker :</td><td> <?php get_maid_for_rec_combo(); ?>  </td></tr><?php
                            } else {
                                ?><tr><td>worker :</td><td> <?php get_maid_combo(); ?>  </td></tr><?php
                            }
                        }
                        if ($_SESSION['cat'] != 'recruiter') {
                            if (!isset($_SESSION['table_to_update'])) {
                                ?>  
                                <tr><td>family_rep_name :</td><td> <?php get_recruiter_combo(); ?>  </td></tr>
                                <?php
                            }
                        }
                    ?>
                    <tr><td>salary_agreed :</td><td> <input type="text"     name="txt_salary_agreed" required class="textbox only_numbers" value="<?php echo trim(chosen_salary_agreed_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_recruitment" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">All recruited house maids List</div><?php
                    if (isset($_SESSION['cat'])) {
                        if ($_SESSION['cat'] == 'admin') {
                            $obj = new multi_values();
                            $obj->list_recruitment();
                        } else {
                            $obj = new multi_values();
                            $obj->my_recruitments($_SESSION['userid']);
                        }
                    }
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_maid_for_rec_combo() {
        $obj = new multi_values();
        $obj->get_maid_for_recruiter_in_combo();
    }

    function get_maid_combo() {
        $obj = new multi_values();
        $obj->get_maid_in_combo();
    }

    function get_recruiter_combo() {
        $obj = new multi_values();
        $obj->get_recruiter_in_combo();
    }

    function chosen_recruit_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'recruitment') {
                $id = $_SESSION['id_upd'];
                $recruit_date = new multi_values();
                return $recruit_date->get_chosen_recruitment_recruit_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_maid_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'recruitment') {
                $id = $_SESSION['id_upd'];
                $maid = new multi_values();
                return $maid->get_chosen_recruitment_maid($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_recruiter_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'recruitment') {
                $id = $_SESSION['id_upd'];
                $recruiter = new multi_values();
                return $recruiter->get_chosen_recruitment_recruiter($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_salary_agreed_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'recruitment') {
                $id = $_SESSION['id_upd'];
                $salary_agreed = new multi_values();
                return $salary_agreed->get_chosen_recruitment_salary_agreed($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    