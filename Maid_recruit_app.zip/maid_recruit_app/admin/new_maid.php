<?php
    session_start();

    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        //header('location:../index.php');
    }
    if (isset($_POST['send_maid'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $maid_id = $_SESSION['id_upd'];
                $sex = $_POST['txt_sex'];
                $village = $_POST['txt_village_id'];
                $id_number = $_POST['txt_id_number'];
                $experience = $_POST['txt_experience'];
                $religion = $_POST['txt_religion'];
                $prefered_job = $_POST['txt_prefered_job'];
                $available = 'yes';
                $upd_obj->update_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $maid_id);
                $name = filter_has_var(INPUT_POST, 'txt_name');
                $m = new multi_values();
                $profileid = $m->get_profileid_by_maid($_SESSION['id_upd']);
                $upd_obj->update_profname_by_maid($name, $profileid);
                ?><script>alert('Update done successfully!');</script><?php
                unset($_SESSION['table_to_update']);
            }
        } else {
            $sex = $_POST['txt_sex'];
            $village = trim($_POST['txt_village_id']);
            $id_number = $_POST['txt_id_number'];
            $edu_level = $_POST['txt_edu_level'];
            $experience = $_POST['txt_experience'];
            $religion = $_POST['txt_religion'];
            $prefered_job = $_POST['txt_prefered_job'];
            $available = 'yes';
            $phone = $_POST['txt_phone'];
            require_once '../web_db/new_values.php';
            $obj = new new_values();
//new profile
            $name = $_POST['txt_name'];
            $obj->new_profile(date('y-m-d'), $name, '', '', '', '', '', 0);
            $m = new multi_values();
            $pers = $m->get_lastprofile();
            if (empty($village)) {
                ?><script>alert('You have to choose the village');</script><?php
            } else {
//                $obj->new_account($account_category, $date_created, $profile, $username, $password, $is_online);
//                $m = new multi_values();
//                $last_acc = $m->get_last_account();
                $status = 'available';
                $username = '';
                $password = '';
                $salary = filter_input(INPUT_POST, 'txt_salary');
                $obj->new_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $pers, $edu_level, $status, $phone, $username, $password, $salary);
                $last_maid = $m->get_lastmaid();
                $next_certif = $m->get_last_certificates();
                $obj->new_certificates($last_maid, $next_certif);
                savefile_certificate();
            }
        }
    }
?>

<html>
    <head>
        <title>  House Workers Registration form</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>

        </style>
    </head>
    <body>
        <form action="new_maid.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate"   name="txt_shall_expand_toUpdate" value="<?php echo shall_update_page(); ?>"/>
            <input type="hidden" id="txt_village_id"   name="txt_village_id"/>
            <?php
                include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border ">  
                <?php
                    if (isset($_SESSION['cat'])) {
//                        if ($_SESSION['cat'] == 'admin') {
                        ?>     <div class="parts  no_paddin_shade_no_Border new_data_hider"> 
                        </div>  <?php
//                        }
                    }
                ?>
            </div>
            <div class="parts eighty_centered off saved_dialog">
                Maid saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">House Maids Registration form</div>
                <div class="parts bg_font no_shade_noBorder "id="age_display">

                </div> 
                <table class="new_data_table">
                    <tr>
                        <td>Names</td>
                        <td><input type="text" placeholder="Enter both names" name="txt_name" required="" class="textbox"  value="<?php echo trim(chosen_name_upd()); ?>"   /></td>
                    </tr>
                    <tr><td>sex :</td><td> 
                            <select  name="txt_sex" required>
                                <option>
                                    Male
                                </option>
                                <option>
                                    Female
                                </option>
                            </select>
                        </td>
                    </tr>
                    <tr><td>District :</td><td> 
                            <?php
                            ?>  
                            <input type="text" class="textbox" name="txt_village_id"  />

                        </td>
                    </tr>
                    <tr><td>id_number :</td><td> <input type="text"   id="txt_id_number"  name="txt_id_number" maxlength="16" required class="textbox only_numbers" value="<?php echo trim(chosen_id_number_upd()); ?>"   />  </td></tr>
                    <tr><td>Education Level :</td><td> 
                            <select name="txt_edu_level" required class="textbox txt_edu_level  only_numbers education_cbo">
                                <option></option>
                                <option>Not educated</option>
                                <option>Not finished primary school</option>
                                <option>Finished only primary school</option>
                                <option>Finished O level school</option>
                                <option>Finished A level school</option>
                                <option>Graduated Bachelor degree school</option>
                                <option>Graduated Masters degree school</option>
                            </select>
                    <tr><td>experience :</td><td> <input type="text"     name="txt_experience" required class="textbox" value="<?php echo trim(chosen_experience_upd()); ?>"   />  </td></tr>
                    <tr>
                        <td>Salary</td>
                        <td><input type="text" class="textbox" id="txt_salary" placeholder="Salary" name="txt_salary"  /></td>
                    </tr>
                    <tr>
                        <td>phone</td>
                        <td><input type="text" placeholder="(250)phone" name="txt_phone" maxlength="10" class="textbox" value="<?php echo chosen_telephone_number_upd(); ?>" />   </td>
                    </tr>
                    <tr><td>religion :</td><td> <input type="text"     name="txt_religion" required class="textbox" value="<?php echo trim(chosen_religion_upd()); ?>"   />  </td></tr>
                    <tr><td>preferred_job :</td><td> 
                            <select name="txt_prefered_job" required class="textbox prefered_job_cbo">
                                <option></option>
                                <option>Baby sitting</option>
                                <option>Food preparation</option>
                                <option>Cleaning</option>
                                <option>House work assistant</option>
                            </select>
                        </td></tr>
                    <tr>
                        <td>Upload certificate</td>
                        <td> <input type="file" name="my_cert"  /></td>
                    </tr>
                    <tr><td colspan="2"> 
                            <input type="submit" class="confirm_buttons" name="send_maid" value="Save"/>  </td></tr>

                </table>

            </div>  
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">House Maids List</div>
                <?php
                    if (isset($_SESSION['cat'])) {
                        if ($_SESSION['cat'] == 'admin') {
                            $obj = new multi_values();
                            $obj->list_maid();
                        } else {
                            $obj = new multi_values();
                            $obj->list_maid_by_user($_SESSION['userid']); //this is recruitment
                        }
                    }
                ?>
            </div>

        </form>
        <script src = "../web_scripts/jquery-2.1.3.min.js" type = "text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        
        <script>

                    //<editor-fold defaultstate="collapsed" desc="----calculate age">
                    $('#txt_id_number').keyup(function () {
                        try {
                            var age_from_nid = $('#txt_id_number').val();
                            if (age_from_nid.charAt(4) != '') {
                                var dob = age_from_nid.charAt(1) + age_from_nid.charAt(2) + age_from_nid.charAt(3) + age_from_nid.charAt(4);
                                var current_year = new Date().getFullYear();
                                var age = current_year - dob;
                                $('#age_display').html(age);
                                if (age < 18) {
                                    $('.confirm_buttons').hide();
                                    $('#age_display').css('background-color', "red").append('   Not allowed');
                                } else {
                                    $('#age_display').css('background', "none");
                                    $('.confirm_buttons').show();
                                }
                            }
                        } catch (err) {
                            alert(err.message);
                        }
                    });
                    //</editor-fold>
                    $('.txt_edu_level').change(function () {
                        try {
                            var level = $(this, 'option:selected').val();
                            var salary = '';
                            if (level == 'Not educated') {
                                salary = '10,000';
                            } else if (level == 'Not finished primary school') {
                                salary = '20,000';
                            } else if (level == 'Finished only primary school') {
                                salary = '30,000';
                            } else if (level == 'Finished O level school') {
                                salary = '40,000';
                            } else if (level == 'Finished A level school') {
                                salary = '170,000';
                            } else if (level == 'Graduated Bachelor degree school') {
                                salary = '230,000';
                            } else if (level == 'Graduated Masters degree school') {
                                salary = '600,000';
                            }
                            $('#txt_salary').val(salary);
                        } catch (err) {
                            alert(err.message);
                        }
                    });

                    var village = '<?php echo chosen_village_upd(); ?>';
                    var education = '<?php echo chosen_education_upd(); ?>';
                    var experience = '<?php echo chosen_experience_upd(); ?>';
                    var prefer_job = '<?php echo chosen_prefered_job_upd(); ?>';

                    $('.education_cbo option:selected').text(education);
//                    $('.prefered_job_cbo').text(prefer_job);
                    $('#sp_combo_village').val(village);
                    $('#txt_village_id').val(village);
                    $('#txt_experience').val(experience);
                    $('.prefered_job_cbo option:selected').text(prefer_job);
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function savefile_certificate() {
        //save the data
        //get the last post
        //save image with the last post image name
        if (!file_exists($_FILES['my_cert']['tmp_name']) || !is_uploaded_file($_FILES['my_cert']['tmp_name'])) {

            $mul_obj = new multi_values();
            $target_dir = "../web_images/certificates/";
            $target_file = $target_dir . basename($_FILES["my_cert"]["name"]);
            $uploadOk = 1;
            $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
            $ExtensionWithDot = '.' . $imageFileType;

            $file_with_noExtension = basename($target_file, $ExtensionWithDot);
            //save the image in folder (upload)
            $img = $mul_obj->get_last_certificates() + 1;
            $desiredname = $img;
            $newname = $desiredname . '.' . $imageFileType;
            $new_target_file = $target_dir . $newname;
            $target_file_for_db = $new_target_file;

            //save the image in the db (save path)
            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES["my_cert"]["tmp_name"]);
            ?><script>alert('the size of the file is: <?php echo $check; ?>');</script><?php
            if ($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not a pdf file.";
                $uploadOk = 0;
            }

            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }
            // Check file size
            if ($_FILES["my_cert"]["size"] > 3000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if ($imageFileType != "pdf") {
                $uploadOk = 0;
                echo '<br/>You can only upload pdf file <br/>';
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
                // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["my_cert"]["tmp_name"], $new_target_file)) {
                    // echo "The file " . basename($_FILES["ben_file"]["name"]) . " has been uploaded.";
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }
        }
    }

    function get_cells_combo() {
        $obj = new multi_values();
        $obj->get_cell_in_combo();
    }

    function get_district_combo() {
        $obj = new multi_values();
        $obj->get_district_in_combo();
    }

    function get_sector_combo() {
        $obj = new multi_values();
        $obj->get_sector_in_combo();
    }

    function get_village_combo() {
        $obj = new multi_values();
        $obj->get_village_in_combo();
    }

    function chosen_sex_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $sex = new multi_values();
                return $sex->get_chosen_maid_sex($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_village_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $village = new multi_values();
                return $village->get_chosen_maid_village($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_id_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $id_number = new multi_values();
                return $id_number->get_chosen_maid_id_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_experience_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $experience = new multi_values();
                return $experience->get_chosen_maid_experience($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_religion_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $religion = new multi_values();
                return $religion->get_chosen_maid_religion($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_prefered_job_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $prefered_job = new multi_values();
                return $prefered_job->get_chosen_maid_prefered_job($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_available_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $available = new multi_values();
                return $available->get_chosen_maid_available($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function shall_update_page() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                return $table = trim($_SESSION['table_to_update']);
            } else {
                return '';
            }
            ?><script>alert('The update time');</script><?php
        } else {
            return '';
        }
    }

    function chosen_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $name = new multi_values();
                return $name->get_chosen_profile_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_telephone_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $telephone_number = new multi_values();
                return $telephone_number->get_chosen_profile_telephone_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_education_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $telephone_number = new multi_values();
                return $telephone_number->get_chosen_profile_educ($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    