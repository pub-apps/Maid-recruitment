<?php
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            #other_bf{
                font-size: 40px;
            }
            #now_smlf{
                margin-left: 30px;
                display: none;
            }
        </style>
    </head>
    <body>
<?php
    include_once './admin_header.php';
?>
        <div class="parts eighty_centered no_shade_noBorder">


            <div class="parts full_center_two_h heit_free top_off_x no_shade_noBorder" id="other_bf"> 
                Welcome to administration dashboard
            </div>   
            <div class="parts full_center_two_h no_paddin_shade_no_Border" id="now_smlf">
                Choose the menu from above to get stated
            </div>
        </div>   <script src = "../web_scripts/jquery-2.1.3.min.js" type = "text/javascript" ></script>

        <script>

            $(document).ready(function () {
                $('#now_smlf').show(2000);
            });

        </script>
    </body>
</html>



