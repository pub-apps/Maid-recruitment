<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_return'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'return') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $return_id = $_SESSION['id_upd'];
                $return_date = date('y-m-d');
                $reason = $_POST['txt_reason'];
                $maid = $_POST['txt_maid_id'];
                $comment = $_POST['txt_comment'];
                require_once '../web_db/updates.php';
                $upd_obj->update_return($reason, $comment, $return_id);
                unset($_SESSION['table_to_update']);
                ?><script>alert('Update done successfully!');</script><?php
            }
        } else {
            $return_date = date('y-m-d');
            $reason = $_POST['txt_reason'];
            $maid = trim($_POST['txt_maid_id']);
            $comment = $_POST['txt_comment'];

            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_return($return_date, $reason, $maid, $comment);
            require_once '../web_db/updates.php';
            $upds = new updates();
            $upds->update_maid_status('available', $maid);
            ?><script>alert('Record saved successfully');</script><?php
        }
    }
?>

<html>
    <head>
        <title>
            returned house maids</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_return.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_maid_id"   name="txt_maid_id"/>
            <input type="hidden" id="txt_shall_expand_toUpdate"   name="txt_shall_expand_toUpdate" value="<?php echo $res = (isset($_SESSION['table_to_update'])) ? $_SESSION['table_to_update'] : '' ?>"/>
            <?php
                include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border"> 
                <div class="parts  no_paddin_shade_no_Border new_data_hider">   </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                returned house workers saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title"> Returned House maids  </div>
                <table class="new_data_table">
                    <tr><td>reason :</td><td> <input type="text"     name="txt_reason" required class="textbox" value="<?php echo trim(chosen_reason_upd()); ?>"   />  </td></tr>
                    <?php if (!isset($_SESSION['table_to_update'])) { ?>  <tr><td>maids :</td><td> <?php get_maid_combo(); ?>  </td></tr> <?php } ?>
                    <tr><td>comment :</td><td> <textarea   name="txt_comment" required class="textbox" ><?php echo trim(chosen_comment_upd()); ?></textarea> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_return" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Returned House maids  List</div><?php
                    $obj = new multi_values();
                    $obj->list_return();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_maid_combo() {
        $obj = new multi_values();
        $obj->get_maid_toreturn_in_combo();
    }

    function chosen_return_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'return') {
                $id = $_SESSION['id_upd'];
                $return_date = new multi_values();
                return $return_date->get_chosen_return_return_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_reason_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'return') {
                $id = $_SESSION['id_upd'];
                $reason = new multi_values();
                return $reason->get_chosen_return_reason($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_maid_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'return') {
                $id = $_SESSION['id_upd'];
                $maid = new multi_values();
                return $maid->get_chosen_return_maid($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_comment_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'return') {
                $id = $_SESSION['id_upd'];
                $comment = new multi_values();
                return $comment->get_chosen_return_comment($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    