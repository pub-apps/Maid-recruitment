<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>
            maid
        </title>
        <link href = "web_style/styles.css" rel = "stylesheet" type = "text/css"/>
        <link href = "web_style/StylesAddon.css" rel = "stylesheet" type = "text/css"/>
        <meta name = "viewport" content = "width=device-width, initial scale=1.0"/>
        <style>
            .dataList_table{
                width:  100%;
            }
            table{
                width: 100%;
            }
            #data_res{
                min-height: 300px;
            }

        </style>
    </head>
    <body>
        <?php
            require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered no_shade_noBorder">
            <div class="parts no_shade_noBorder ">
                <table border="4" class="parts  no_paddin_shade_no_Border full_center_two_h heit_free">
                    <tr>   <td>    Enter Worker's names   </td>
                        <td>    <input type="text" id="txt_names" class="textbox" name="txt_name"  />  </td>
                        <td>   <button class="parts margin_free left_off_xx btn_search_report">Search</button>  </td>
                    </tr>
                    <tr>
                        <td colspan="3" >
                            <span class="parts no_paddin_shade_no_Border off" id="loader" >

                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <span class="parts no_paddin_shade_no_Border off" id="data_res">

                            </span>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="parts  full_center_two_h heit_free no_shade_noBorder ">
                <div class="parts  big_title heit_free no_shade_noBorder link_cursor  margin_free" id="btn1">
                    Pending Applications
                </div>
                <div class="parts  big_title heit_free no_shade_noBorder link_cursor  margin_free" id="btn2">
                    Requested Maids
                </div>
                <div class="parts  big_title heit_free no_shade_noBorder link_cursor  margin_free" id="btn3">
                    Available Maids
                </div>
                <div class="parts  big_title heit_free no_shade_noBorder link_cursor  margin_free" id="btn4">
                    Recruited Maids
                </div>

                <span id="pending_cont">
                    <?php
                        $list = new multi_values();
                        $list->list_Pending_maid();
                    ?>
                    <div class="parts no_shade_noBorder full_center_two_h heit_free">
                        <button class="Print" id="btn_pending"> Print  </button></div>
                </span>
                <span id="requested_cont" class="full_center_two_h heit_free off">
                    <?php
                        $list->list_requested_maid();
                    ?> <div class="parts no_shade_noBorder full_center_two_h heit_free">
                        <button class="Print" id="btn_requested">  Print  </button></div>
                </span>
                <span id="available_cont" class="off">
                    <?php $list->list_available_maid() ?>   <div class="parts no_shade_noBorder full_center_two_h heit_free">
                        <button class="Print" id="btn_available"> Print  </button></div>
                </span>
                <span id="recruited_cont" class="off">
                    <?php $list->list_maid_recruited() ?>
                    <div class="parts no_shade_noBorder full_center_two_h heit_free">
                        <button class="Print" id="btn_recruited"> Print  </button></div>
                </span>

            </div>
            <div class="parts eighty_centered no_shade_noBorder">
            </div>

    </body>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script   type="text/javascript">
        $(document).ready(function () {
            //<editor-fold defaultstate="collapsed" desc="--Report navigation--">
            $('#btn1').addClass('hilite');
            $('#btn1').click(function () {
                $(this).addClass('hilite');
                $('#btn2').removeClass('hilite');
                $('#btn3').removeClass('hilite');
                $('#btn4').removeClass('hilite');
                $('#requested_cont').hide(20);
                $('#available_cont').hide(20);
                $('#recruited_cont').hide(20);
                $('#pending_cont').show(20);
            });
            $('#btn2').click(function () {
                $(this).addClass('hilite');
                $('#btn1').removeClass('hilite');
                $('#btn3').removeClass('hilite');
                $('#btn4').removeClass('hilite');
                $('#requested_cont').show(20);
                $('#available_cont').hide(20);
                $('#pending_cont').hide(20);
                $('#recruited_cont').hide(20);
            });
            $('#btn3').click(function () {
                $(this).addClass('hilite');
                $('#btn2').removeClass('hilite');
                $('#btn1').removeClass('hilite');

                $('#btn4').removeClass('hilite');
                $('#requested_cont').hide(20);
                $('#available_cont').show(20);
                $('#pending_cont').hide(20);
                $('#recruited_cont').hide(20);
            });
            $('#btn4').click(function () {
                $(this).addClass('hilite');
                $('#btn2').removeClass('hilite');
                $('#btn1').removeClass('hilite');
                $('#btn3').removeClass('hilite');
                $('#requested_cont').hide(20);
                $('#pending_cont').hide(20);
                $('#available_cont').hide(20);
                $('#recruited_cont').show(20);


            });
            //</editor-fold>
            $('.confirm_pending').click(function () {
                var confirm_pending = $(this).data('bind');
                $.post('handler.php', {confirm_pending: confirm_pending}, function (data) {
//                    alert(data);
                }).complete(function () {
                    window.location.reload();
                });

            });
            try {
                $('.approve_req').click(function () {
                    var maid = $(this).data('bind');
                    var approve_req = maid;
                    $.post('../admin/handler.php', {approve_req: approve_req}, function (data) {

                    }).complete(function () {
                        window.location.reload();
                        $(this).addClass('hilite');
                        $('#btn1').removeClass('hilite');
                        $('#btn3').removeClass('hilite');
                        $('#requested_cont').show(20);
                        $('#available_cont').hide(20);
                        $('#pending_cont').hide(20);
                        $('#recruited_cont').hide(20);
                    });
                });
            } catch (err) {
                alert(err.message);
            }
            //<editor-fold defaultstate="collapsed" desc="--print and search--">
            $('#btn_pending').click(function () {
                window.location.replace('../prints/print_pending.php');
            });
            $('#btn_available').click(function () {
                window.location.replace('../prints/print_available.php');
            });
            $('#btn_recruited').click(function () {
                window.location.replace('../prints/print_recruited.php');
            });
            $('#btn_requested').click(function () {
                window.location.replace('../prints/print_requested.php');
            });
            $('.btn_search_report').click(function () {
                //show the loader
                $('#loader').slideDown(30);
                //get data
                var search_report = $('#txt_names').val();
                var data_res = '';

                $.post('handler.php', {search_report: search_report}, function (data) {
                    data_res = data;
                }).complete(function () {
                    $('#loader').slideUp(30, function () {
                        $('#data_res').show(1).html(data_res);
                    });
                });
            });
            //</editor-fold>

        });
    </script>
</html>
