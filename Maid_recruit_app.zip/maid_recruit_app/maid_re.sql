-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: maid_recruit
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `cat_acc_idx` (`account_category`),
  CONSTRAINT `cat_acc` FOREIGN KEY (`account_category`) REFERENCES `account_category` (`account_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (8,8,'2018-01-01',1,'admin','123456','no'),(9,9,'2018-05-20',35,'fifi','123','yes'),(10,9,'2018-05-20',36,'fifi','123','yes'),(11,9,'2018-05-20',37,'fifi','123','yes'),(12,9,'2018-05-20',38,'fifi','123','yes'),(13,9,'2018-05-20',39,'meg','1234','yes'),(14,9,'2018-05-20',40,'meg','1234','yes'),(15,9,'2018-05-20',41,'dfdf','erer','yes'),(20,9,'2018-05-20',46,'julias','3456','yes'),(21,9,'2018-05-20',54,'emma','123123','yes'),(22,9,'2018-05-20',56,'george','123123','yes'),(23,9,'2018-05-20',57,'ryan','123123','yes'),(24,9,'2018-05-20',58,'yves','12312','yes'),(25,9,'2018-05-20',60,'solange','123123','yes'),(26,9,'2018-05-20',61,'didier','123123','yes'),(27,9,'2018-05-20',63,'guru','123123','yes'),(28,9,'2018-05-20',64,'hurio','123123','yes'),(29,9,'2018-05-20',66,'ADRIANE','123123','yes'),(30,9,'2018-05-20',67,'jumma','123123','yes'),(31,9,'2018-05-20',68,'james','123123','yes');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (8,'admin'),(9,'recruiter');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cell`
--

DROP TABLE IF EXISTS `cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cell` (
  `cell_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  PRIMARY KEY (`cell_id`),
  KEY `cell_sectore_idx` (`sector`),
  CONSTRAINT `cell_sectore` FOREIGN KEY (`sector`) REFERENCES `sector` (`sector_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cell`
--

LOCK TABLES `cell` WRITE;
/*!40000 ALTER TABLE `cell` DISABLE KEYS */;
INSERT INTO `cell` VALUES (1,'Kora',13),(2,'Kinyange',13),(3,'Akabeza',13),(4,'Akabahizi',13),(5,'Kigarama',13),(6,NULL,13),(7,'juru',4);
/*!40000 ALTER TABLE `cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_us` (
  `contact_us_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) DEFAULT NULL,
  `date_contact` date DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`contact_us_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `province` int(11) DEFAULT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (1,'Kicukiro',8),(2,'Nyarugenge',8),(3,'Gasabo',8);
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maid`
--

DROP TABLE IF EXISTS `maid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maid` (
  `maid_id` int(11) NOT NULL AUTO_INCREMENT,
  `sex` varchar(60) DEFAULT NULL,
  `village` int(11) DEFAULT NULL,
  `id_number` varchar(60) DEFAULT NULL,
  `experience` varchar(60) DEFAULT NULL,
  `religion` varchar(60) DEFAULT NULL,
  `prefered_job` varchar(60) DEFAULT NULL,
  `available` varchar(60) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `education_level` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`maid_id`),
  KEY `maid_profile_idx` (`profile`),
  KEY `maid_village_idx` (`village`),
  CONSTRAINT `maid_profile` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `maid_village` FOREIGN KEY (`village`) REFERENCES `village` (`village_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maid`
--

LOCK TABLES `maid` WRITE;
/*!40000 ALTER TABLE `maid` DISABLE KEYS */;
INSERT INTO `maid` VALUES (16,'Male',11,'12143','Cooking, cleaning','Catholique','Cooking','no',11,NULL,'available'),(17,'Male',11,'1234112341324','Cooking, cleaning','Catholique','Food preparation','yes',14,'Not finished primary school','available'),(18,'Male',11,'1123849132047','Cleaning','Protestant','Cleaning','yes',15,'Finished only primary school','available'),(19,'Male',11,'1123412423','asdfa','Protestant','House work assistant','yes',19,'Graduated Bachelor degree school','available'),(20,'Female',11,'1104985585748','Baby sitter','Catholique','Baby sitting','yes',20,'Finished A level school','available'),(21,'Male',11,'2423434','Food analysis','Protestant','Food preparation','yes',22,'Finished only primary school','available'),(25,'Male',11,'1193848','Cooking','Catholique','Cleaning','yes',27,'Finished A level school','requested'),(26,'Male',11,'119349594893','Preparing food','Catholique','Food preparation','yes',76,'Finished only primary school','pending');
/*!40000 ALTER TABLE `maid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maid_request`
--

DROP TABLE IF EXISTS `maid_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maid_request` (
  `maid_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  `description` varchar(560) DEFAULT NULL,
  PRIMARY KEY (`maid_request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maid_request`
--

LOCK TABLES `maid_request` WRITE;
/*!40000 ALTER TABLE `maid_request` DISABLE KEYS */;
INSERT INTO `maid_request` VALUES (8,'2018-05-20','14','  asdfaskldfja sdflsjd fas fasjk dfsklf ;askjlf '),(9,'2018-05-20','15','  sadfsdf'),(10,'2018-05-20','16','  asdfasdf'),(11,'2018-05-20','17','  asdfasdf'),(12,'2018-05-20','18','  asdfasdfas'),(13,'2018-05-20','19','  sadsaf'),(14,'2018-05-20','20','  sadsaf'),(15,'2018-05-20','21','asklfjaa  '),(16,'2018-05-20','22','  asdfasf  sadf'),(17,'2018-05-20','23','askjf asdfkj sadfjk  '),(18,'2018-05-20','24','aklj asfaksjlf a  '),(19,'2018-05-20','25','solange good  '),(20,'2018-05-20','26','didier should advise  '),(21,'2018-05-20','27','guru guru  '),(22,'2018-05-20','28','asdkasf fkasfsdf  '),(23,'2018-05-20','29','ASDFJ SDKJF AS;LFJ  '),(24,'2018-05-20','30','juma  '),(25,'2018-05-20','31','  james');
/*!40000 ALTER TABLE `maid_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org` (
  `org_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org`
--

LOCK TABLES `org` WRITE;
/*!40000 ALTER TABLE `org` DISABLE KEYS */;
/*!40000 ALTER TABLE `org` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'2018-04-13','Patrick','','','','','',0),(2,'2018-04-13','Patrick','','','','','',0),(3,'2018-04-13',NULL,'','','','','',0),(4,'2018-04-13','Jean','','','','','',0),(5,'2018-04-13','christian','','','','','',0),(6,'2018-04-13','Thierry','','','','','',0),(7,'2018-04-13','John','','','','','',0),(8,'2018-04-13','Gisele','','','','','',0),(9,'2018-04-13','FRANCOIS BAHIZI','','','','','',0),(10,'2018-04-13','Patrick MUHIRE','','','','','',0),(11,'2018-04-13','FRANCOIS MUHIRE','','','','','',0),(12,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(13,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(14,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(15,'2018-04-13','Olivier','','','','','',0),(16,'2018-04-13','Jack HABIMANA','','','','','',0),(17,'2018-04-13','Jack HABIMANA','','','','','',0),(18,'2018-04-13','Jack HABIMANA','','','','','',0),(19,'2018-04-13','Jack HABIMANA','','','','','',0),(20,'2018-04-15','Florence UWAMBAJE','','','','','',0),(21,'2018-04-15','Philippe','','','','','',0),(22,'2018-04-17','Eric NSANZIMFURA','','','','','',0),(23,'2018-04-17','Asman MUHAMED','','','','','',0),(24,'2018-04-19','asdf','','','','','',0),(25,'2018-04-19','asdf','','','','','',0),(26,'2018-04-19','asdf','','','','','',0),(27,'2018-04-19','Jean de la Croix','','','','','',0),(28,'2018-05-19','test name','','','','','',0),(29,'2018-05-20','adfk','','','','','',0),(30,'2018-05-20','adfk','','','','','',0),(31,'2018-05-20','sdfasdf asdasdf','','','','','',0),(32,'2018-05-20','sdfasdf asdasdf','','','','','',0),(33,'2018-05-20','sdfasdf asdasdf','','','','','',0),(34,'2018-05-20','sdfasdf asdasdf','','','','','',0),(35,'2018-05-20','sdfasdf asdasdf','','','','','',0),(36,'2018-05-20','sdfasdf asdasdf','','','','','',0),(37,'2018-05-20','sdfasdf asdasdf','','','','','',0),(38,'2018-05-20','sdfasdf asdasdf','','','','','',0),(39,'2018-05-20','asdfkjl','','','','','',0),(40,'2018-05-20','asdfkjl','','','','','',0),(41,'2018-05-20','asdkljf','','','','','',0),(42,'2018-05-20','asdf','','','','','',0),(43,'2018-05-20','asdf','','','','','',0),(44,'2018-05-20','zdasf','','','','','',0),(45,'2018-05-20','julia','','','','','',0),(46,'2018-05-20','julia','','','','','',0),(47,'2018-05-20','julia','','','','','',0),(48,'2018-05-20','julia','','','','','',0),(49,'2018-05-20','asdfjakls','','','','','',0),(50,'2018-05-20','asdfjakls','','','','','',0),(51,'2018-05-20','asdfjakls','','','','','',0),(52,'2018-05-20','asdfkjl','','','','','',0),(53,'2018-05-20','asdf','','','','','',0),(54,'2018-05-20','askfj','','','','','',0),(55,'2018-05-20','askfj','','','','','',0),(56,'2018-05-20','asdfkj','','','','','',0),(57,'2018-05-20','asdf','','','','','',0),(58,'2018-05-20','sfaskljf','','','','','',0),(59,'2018-05-20','sfaskljf','','','','','',0),(60,'2018-05-20','akdfjl','','','','','',0),(61,'2018-05-20','askjlf','','','','','',0),(62,'2018-05-20','askjlf','','','','','',0),(63,'2018-05-20','asfj','','','','','',0),(64,'2018-05-20','asdklf','','','','','',0),(65,'2018-05-20','asdklf','','','','','',0),(66,'2018-05-20','asjd','','','','','',0),(67,'2018-05-20','jumma','','','','','',0),(68,'2018-05-20','James','','','','','',0),(69,'2018-05-20','Jeannette','','','','','',0),(70,'2018-05-20','Tino','','','','','',0),(71,'2018-05-20','Vumilia','','','','','',0),(72,'2018-05-20','Juliette','','','','','',0),(73,'2018-05-20','Eric','','','','','',0),(74,'2018-05-20','Eric','','','','','',0),(75,'2018-05-20','Fiacle','','','','','',0),(76,'2018-05-20','Gallo','','','','','',0);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (8,'Kigali'),(9,'North'),(10,'South'),(11,'East'),(12,'West');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruiter`
--

DROP TABLE IF EXISTS `recruiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruiter` (
  `recruiter_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_rep_name` varchar(60) DEFAULT NULL,
  `number_members` int(11) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  PRIMARY KEY (`recruiter_id`),
  KEY `recruiter_acc_idx` (`account`),
  CONSTRAINT `recruiter_acc` FOREIGN KEY (`account`) REFERENCES `account` (`account_id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruiter`
--

LOCK TABLES `recruiter` WRITE;
/*!40000 ALTER TABLE `recruiter` DISABLE KEYS */;
INSERT INTO `recruiter` VALUES (2,'Jean Paul',3,7,6,NULL,NULL),(3,'Fabien MUHIZI',6,9,21,NULL,NULL),(4,'Serukundo',3,7,23,NULL,NULL),(5,'family given',34,8,28,'2018-05-19',NULL),(12,'asjfk',8,5,46,'2018-05-20',20),(13,'askjf',6,7,58,'2018-05-20',24),(14,'alksdj;f',4,6,60,'2018-05-20',25),(15,'kasjf',3,9,61,'2018-05-20',26),(16,'sdfkjl',7,6,63,'2018-05-20',27),(17,'askd',5,8,64,'2018-05-20',28),(18,'ASKJF',4,8,66,'2018-05-20',29),(19,'askjdf',3,5,67,'2018-05-20',30),(20,'james',3,10,68,'2018-05-20',31);
/*!40000 ALTER TABLE `recruiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruitment`
--

DROP TABLE IF EXISTS `recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruitment` (
  `recruitment_id` int(11) NOT NULL AUTO_INCREMENT,
  `recruit_date` date DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `recruiter` int(11) DEFAULT NULL,
  `salary_agreed` int(11) DEFAULT NULL,
  PRIMARY KEY (`recruitment_id`),
  KEY `recrtment_recrt_idx` (`recruiter`),
  KEY `recrtmnt_maid_idx` (`maid`),
  CONSTRAINT `recrtment_recrt` FOREIGN KEY (`recruiter`) REFERENCES `recruiter` (`recruiter_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `recrtmnt_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruitment`
--

LOCK TABLES `recruitment` WRITE;
/*!40000 ALTER TABLE `recruitment` DISABLE KEYS */;
INSERT INTO `recruitment` VALUES (6,'2018-04-13',16,2,65000),(7,'2018-04-15',20,3,60000),(8,'2018-04-17',21,4,67000);
/*!40000 ALTER TABLE `recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returned_maid`
--

DROP TABLE IF EXISTS `returned_maid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returned_maid` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `return_date` date DEFAULT NULL,
  `reason` varchar(60) DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `comment` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  KEY `return_maid_idx` (`maid`),
  CONSTRAINT `return_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returned_maid`
--

LOCK TABLES `returned_maid` WRITE;
/*!40000 ALTER TABLE `returned_maid` DISABLE KEYS */;
INSERT INTO `returned_maid` VALUES (5,'2018-04-13','He is done with job',16,'the boss has terminated the contract because he was shifting to another location'),(6,'2018-04-13','He has looked down on boss',16,'He cant well behave'),(7,'2018-04-15','mishabivior',20,'she made some mistakes. she broke a glass and she is not clean'),(8,'2018-04-17','job is finished',21,'he finished is jib according to period due'),(9,'2018-04-27','he finished required job',17,'the job went very well');
/*!40000 ALTER TABLE `returned_maid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sector` (
  `sector_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  PRIMARY KEY (`sector_id`),
  KEY `sector_district_idx` (`district`),
  CONSTRAINT `sector_district` FOREIGN KEY (`district`) REFERENCES `district` (`district_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
INSERT INTO `sector` VALUES (1,'Nyamirambo',2),(2,'Muhima',2),(3,'Nyamirambo',2),(4,'Gatenga',1),(5,'Kucukiro',1),(6,'Kagarama',1),(7,'Niboye',1),(8,'Gatsata',3),(9,'Karuruma',3),(10,'Remera',3),(11,'Kabuga',3),(12,'Ndera',3),(13,'Gitega',2);
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village`
--

DROP TABLE IF EXISTS `village`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village` (
  `village_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL,
  PRIMARY KEY (`village_id`),
  KEY `village_cell_idx` (`cell`),
  CONSTRAINT `village_cell` FOREIGN KEY (`cell`) REFERENCES `cell` (`cell_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village`
--

LOCK TABLES `village` WRITE;
/*!40000 ALTER TABLE `village` DISABLE KEYS */;
INSERT INTO `village` VALUES (11,'ituze',2);
/*!40000 ALTER TABLE `village` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'maid_recruit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-20 21:12:31
