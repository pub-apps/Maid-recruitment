-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: maid_recruit
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `cat_acc_idx` (`account_category`),
  CONSTRAINT `cat_acc` FOREIGN KEY (`account_category`) REFERENCES `account_category` (`account_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (20,9,'2018-05-20',18,'judis','34561','yes'),(21,8,'2018-05-20',54,'admin','123','yes'),(22,9,'2018-05-20',56,'george','123123','yes'),(35,9,'2018-06-02',125,'manager','123','yes'),(36,9,'2018-06-02',126,'admin','123','yes'),(37,9,'2018-06-02',127,'sdsd','123','yes'),(38,9,'2018-06-02',128,'sdsd','123','yes'),(39,9,'2018-06-02',129,'sdsd','123','yes'),(40,9,'2018-06-02',130,'admin','123','yes'),(41,9,'2018-06-02',131,'admin','123','yes'),(42,9,'2018-06-02',132,'administrator','1234','yes'),(43,9,'2018-06-02',133,'adminrr','123','yes'),(44,9,'2018-06-02',134,'adminrr','123','yes'),(45,9,'2018-06-02',135,'oreste','123454','yes'),(46,9,'2018-06-02',136,'yuli','123456','yes'),(47,9,'2018-06-02',137,'yuli','123456','yes'),(48,9,'2018-06-02',138,'guru','123','yes'),(49,9,'2018-06-02',140,'Samuel','123456','yes'),(50,9,'2018-06-02',141,'Bienvenue','123456','yes'),(51,9,'2018-06-04',147,'hubert','123456','yes'),(52,10,'2018-06-15',0,'Fiacle','123231','no'),(53,10,'2018-06-19',0,'admin','123','no'),(54,9,'2018-07-24',158,'Yves','123','yes'),(55,10,'2018-08-09',0,'','','no'),(56,9,'2018-08-09',165,'rugira','123123','yes'),(57,10,'2018-08-09',0,'','','no'),(58,10,'2018-08-13',0,'','','no'),(59,10,'2018-08-13',0,'','','no'),(60,9,'2018-08-13',175,'george','123','yes'),(61,10,'2018-08-13',0,'','','no'),(62,9,'2018-08-13',177,'elisa','123123','yes'),(63,10,'2018-08-13',0,'','','no'),(64,9,'2018-08-13',180,'rugira','123','yes'),(65,9,'2018-08-13',181,'HUbert','123123','yes'),(66,9,'2018-08-13',182,'issa','123','yes'),(67,9,'2018-08-13',183,'issa','1234','yes');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (8,'admin'),(9,'recruiter'),(10,'maid');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cell`
--

DROP TABLE IF EXISTS `cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cell` (
  `cell_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  PRIMARY KEY (`cell_id`),
  KEY `cell_sectore_idx` (`sector`),
  CONSTRAINT `cell_sectore` FOREIGN KEY (`sector`) REFERENCES `sector` (`sector_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cell`
--

LOCK TABLES `cell` WRITE;
/*!40000 ALTER TABLE `cell` DISABLE KEYS */;
INSERT INTO `cell` VALUES (7,'juru',4),(22,'Cyaruzinge',1),(23,'Agahizi',2),(25,'Imanga',6);
/*!40000 ALTER TABLE `cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `certificates_id` int(11) NOT NULL AUTO_INCREMENT,
  `maid` int(11) DEFAULT NULL,
  `file` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`certificates_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES (8,27,'1'),(9,28,'9'),(10,29,'10'),(11,30,'11'),(12,30,'12'),(13,30,'13'),(14,30,'14'),(15,30,'15'),(16,30,'16'),(17,30,'17'),(18,30,'18'),(19,30,'19'),(20,30,'20'),(21,30,'21'),(22,30,'22'),(23,31,'23'),(24,37,'24'),(25,38,'25'),(26,39,'26'),(27,37,'27'),(28,38,'28'),(29,39,'29'),(30,39,'30'),(31,39,'31'),(32,40,'32'),(33,41,'33'),(34,42,'34'),(35,43,'35'),(36,44,'36'),(37,42,'37'),(38,43,'38'),(39,44,'39'),(40,45,'40'),(41,46,'41'),(42,47,'42'),(43,48,'43'),(44,49,'44'),(45,50,'45'),(46,51,'46'),(47,52,'47'),(48,53,'48'),(49,53,'49'),(50,53,'50'),(51,54,'51'),(52,55,'52'),(53,56,'53'),(54,57,'54'),(55,58,'55'),(56,59,'56'),(57,1,'57'),(58,2,'58'),(59,3,'59'),(60,4,'60'),(61,5,'61'),(62,6,'62'),(63,7,'63'),(64,8,'64'),(65,8,'65'),(66,9,'66'),(67,9,'67'),(68,10,'68'),(69,11,'68'),(70,12,'69'),(71,13,'71'),(72,14,'71'),(73,15,'73');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_us` (
  `contact_us_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) DEFAULT NULL,
  `date_contact` date DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`contact_us_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `province` int(11) DEFAULT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (1,'Kicukiro',8),(2,'Nyarugenge',8),(3,'Gasabo',8);
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maid`
--

DROP TABLE IF EXISTS `maid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maid` (
  `maid_id` int(11) NOT NULL AUTO_INCREMENT,
  `sex` varchar(60) DEFAULT NULL,
  `village` varchar(20) DEFAULT NULL,
  `id_number` varchar(60) DEFAULT NULL,
  `experience` varchar(60) DEFAULT NULL,
  `religion` varchar(60) DEFAULT NULL,
  `prefered_job` varchar(60) DEFAULT NULL,
  `available` varchar(60) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `education_level` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `salary` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`maid_id`),
  KEY `maid_profile_idx` (`profile`),
  CONSTRAINT `maid_profile` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maid`
--

LOCK TABLES `maid` WRITE;
/*!40000 ALTER TABLE `maid` DISABLE KEYS */;
INSERT INTO `maid` VALUES (14,'Male','GAsabo','1198983475858334','Cooking, cleaning','Catholique','Food preparation','yes',178,'Not finished primary school','recruited','0784757575','','','20,000'),(15,'Male','Kicukiro','1198912093847242','Cleaning','Protestant','Food preparation','yes',179,'Finished only primary school','recruited','0782316387','','','30,000');
/*!40000 ALTER TABLE `maid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maid_request`
--

DROP TABLE IF EXISTS `maid_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maid_request` (
  `maid_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  `description` varchar(560) DEFAULT NULL,
  PRIMARY KEY (`maid_request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maid_request`
--

LOCK TABLES `maid_request` WRITE;
/*!40000 ALTER TABLE `maid_request` DISABLE KEYS */;
INSERT INTO `maid_request` VALUES (8,'2018-05-20','14','  asdfaskldfja sdflsjd fas fasjk dfsklf ;askjlf '),(9,'2018-05-20','15','  sadfsdf'),(10,'2018-05-20','16','  asdfasdf'),(11,'2018-05-20','17','  asdfasdf'),(12,'2018-05-20','18','  asdfasdfas'),(13,'2018-05-20','19','  sadsaf'),(14,'2018-05-20','20','  sadsaf'),(15,'2018-05-20','21','asklfjaa  '),(16,'2018-05-20','22','  asdfasf  sadf'),(17,'2018-05-20','23','askjf asdfkj sadfjk  '),(18,'2018-05-20','24','aklj asfaksjlf a  '),(19,'2018-05-20','25','solange good  '),(20,'2018-05-20','26','didier should advise  '),(21,'2018-05-20','27','guru guru  '),(22,'2018-05-20','28','asdkasf fkasfsdf  '),(23,'2018-05-20','29','ASDFJ SDKJF AS;LFJ  '),(24,'2018-05-20','30','juma  '),(25,'2018-05-20','31','  james'),(26,'2018-06-02','49','  I want a house'),(27,'2018-06-02','50','the   '),(28,'2018-07-24','54','o need blalablala  '),(29,'2018-08-09','56','  asd'),(30,'2018-08-13','62','  kajsfhl a'),(31,'2018-08-13','64','rugira  '),(32,'2018-08-13','65','HUbert  '),(33,'2018-08-13','66','umukozi  '),(34,'2018-08-13','67','issa  ');
/*!40000 ALTER TABLE `maid_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org` (
  `org_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org`
--

LOCK TABLES `org` WRITE;
/*!40000 ALTER TABLE `org` DISABLE KEYS */;
/*!40000 ALTER TABLE `org` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'2018-04-13','Patrick','','','','','',0),(2,'2018-04-13','Patrick','','','','','',0),(3,'2018-04-13',NULL,'','','','','',0),(4,'2018-04-13','Jean','','','','','',0),(5,'2018-04-13','christian','','','','','',0),(6,'2018-04-13','Thierry','','','','','',0),(7,'2018-04-13','John','','','','','',0),(8,'2018-04-13','Gisele','','','','','',0),(9,'2018-04-13','FRANCOIS BAHIZI','','','','','',0),(10,'2018-04-13','Patrick MUHIRE','','','','','',0),(11,'2018-04-13','FRANCOIS MUHIRE','','','','','',0),(12,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(13,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(14,'2018-04-13','Baptiste UWAMBAJE','','','','','',0),(15,'2018-04-13','Olivier','','','','','',0),(16,'2018-04-13','Jack HABIMANA','','','','','',0),(17,'2018-04-13','Jack HABIMANA','','','','','',0),(18,'2018-04-13','Jack HABIMANA','','','','','',0),(19,'2018-04-13','Jack HABIMANA','','','','','',0),(20,'2018-04-15','Florence UWAMBAJE','','','','','',0),(21,'2018-04-15','Philippe','','','','','',0),(22,'2018-04-17','Eric NSANZIMFURA','','','','','',0),(23,'2018-04-17','Asman MUHAMED','','','','','',0),(24,'2018-04-19','asdf','','','','','',0),(25,'2018-04-19','asdf','','','','','',0),(26,'2018-04-19','asdf','','','','','',0),(27,'2018-04-19','Jean de la Croix','','','','','',0),(28,'2018-05-19','test name','','','','','',0),(29,'2018-05-20','adfk','','','','','',0),(30,'2018-05-20','adfk','','','','','',0),(31,'2018-05-20','sdfasdf asdasdf','','','','','',0),(32,'2018-05-20','sdfasdf asdasdf','','','','','',0),(33,'2018-05-20','sdfasdf asdasdf','','','','','',0),(34,'2018-05-20','sdfasdf asdasdf','','','','','',0),(35,'2018-05-20','sdfasdf asdasdf','','','','','',0),(36,'2018-05-20','sdfasdf asdasdf','','','','','',0),(37,'2018-05-20','sdfasdf asdasdf','','','','','',0),(38,'2018-05-20','sdfasdf asdasdf','','','','','',0),(39,'2018-05-20','asdfkjl','','','','','',0),(40,'2018-05-20','asdfkjl','','','','','',0),(41,'2018-05-20','asdkljf','','','','','',0),(42,'2018-05-20','asdf','','','','','',0),(43,'2018-05-20','asdf','','','','','',0),(44,'2018-05-20','zdasf','','','','','',0),(45,'2018-05-20','julia','','','','','',0),(46,'2018-05-20','julia','','','','','',0),(47,'2018-05-20','julia','','','','','',0),(48,'2018-05-20','julia','','','','','',0),(49,'2018-05-20','asdfjakls','','','','','',0),(50,'2018-05-20','asdfjakls','','','','','',0),(51,'2018-05-20','asdfjakls','','','','','',0),(52,'2018-05-20','asdfkjl','','','','','',0),(53,'2018-05-20','asdf','','','','','',0),(54,'2018-05-20','askfj','','','','','',0),(55,'2018-05-20','askfj','','','','','',0),(56,'2018-05-20','Germaine','','','','','',0),(57,'2018-05-20','asdf','','','','','',0),(58,'2018-05-20','sfaskljf','','','','','',0),(59,'2018-05-20','sfaskljf','','','','','',0),(60,'2018-05-20','akdfjl','','','','','',0),(61,'2018-05-20','alpha','','','','','',0),(62,'2018-05-20','askjlf','','','','','',0),(63,'2018-05-20','asfj','','','','','',0),(64,'2018-05-20','asdklf','','','','','',0),(65,'2018-05-20','asdklf','','','','','',0),(66,'2018-05-20','asjd','','','','','',0),(67,'2018-05-20','jumma','','','','','',0),(68,'2018-05-20','James','','','','','',0),(69,'2018-05-20','Jeannette','','','','','',0),(70,'2018-05-20','Tino','','','','','',0),(71,'2018-05-20','Vumilia','','','','','',0),(72,'2018-05-20','Juliette','','','','','',0),(73,'2018-05-20','Eric','','','','','',0),(74,'2018-05-20','Eric','','','','','',0),(75,'2018-05-20','Fiacle','','','','','',0),(76,'2018-05-20','Gallo','','','','','',0),(77,'2018-05-21','asdkfj','','','','','',0),(78,'2018-05-21','asdkfj','','','','','',0),(79,'2018-05-21','asdkfj','','','','','',0),(80,'2018-05-21','askdfh','','','','','',0),(81,'2018-05-21','aksdfjl','','','','','',0),(82,'2018-05-21','aksdfjl','','','','','',0),(83,'2018-05-21','adsklf','','','','','',0),(84,'2018-05-21','jumma','','','','','',0),(85,'2018-05-21','jumma','','','','','',0),(86,'2018-05-21','jumma','','','','','',0),(87,'2018-05-21','aklsfd','','','','','',0),(88,'2018-05-21','as','','','','','',0),(89,'2018-05-21','as','','','','','',0),(90,'2018-05-21','as','','','','','',0),(91,'2018-05-21','bool','','','','','',0),(92,'2018-05-23','Bella','','','','','',0),(93,'2018-05-23','mabool','','','','','',0),(94,'2018-05-23','Esther','','','','','',0),(95,'2018-05-23','Esther','','','','','',0),(96,'2018-05-23','Esther','','','','','',0),(97,'2018-05-23','Vumi','','','','','',0),(98,'2018-05-23','Vumi','','','','','',0),(99,'2018-05-23','Vumi','','','','','',0),(100,'2018-05-23','Oreste','','','','','',0),(101,'2018-05-26','FRANCOIS','','','','','',0),(102,'2018-05-26','jules','','','','','',0),(103,'2018-05-26','FRANCOIS MUVUNNYI','','','','','',0),(104,'2018-05-26','Marie','','','','','',0),(105,'2018-05-26','Marie','','','','','',0),(106,'2018-05-26','Yves','','','','','',0),(107,'2018-05-26','Yves','','','','','',0),(108,'2018-05-26','Yves','','','','','',0),(109,'2018-05-26','Jean Luc','','','','','',0),(110,'2018-05-26','Jean Luc','','','','','',0),(111,'2018-05-30','FRANCOIS','','','','','',0),(112,'2018-05-30','Olivier','','','','','',0),(113,'2018-05-30','Olivier','','','','','',0),(114,'2018-05-30','jumma','','','','','',0),(115,'2018-05-30','asdf','','','','','',0),(116,'2018-06-01','Yves.','','','','','',0),(117,'2018-06-01','Yves..','','','','','',0),(118,'2018-06-01','Yves..','','','','','',0),(119,'2018-06-01','Yves..','','','','','',0),(120,'2018-06-01','ss','','','','','',0),(121,'2018-06-01','ss','','','','','',0),(122,'2018-06-01','abc','','','','','',0),(123,'2018-06-01','Yves','','','','','',0),(124,'2018-06-02','ss','','','','','',0),(125,'2018-06-02','s','','','','','',0),(126,'2018-06-02','ss','','','','','',0),(127,'2018-06-02','w','','','','','',0),(128,'2018-06-02','w','','','','','',0),(129,'2018-06-02','w','','','','','',0),(130,'2018-06-02','d','','','','','',0),(131,'2018-06-02','d','','','','','',0),(132,'2018-06-02','d','','','','','',0),(133,'2018-06-02','d','','','','','',0),(134,'2018-06-02','d','','','','','',0),(135,'2018-06-02','iuoe','','','','','',0),(136,'2018-06-02','july','','','','','',0),(137,'2018-06-02','july','','','','','',0),(138,'2018-06-02','s','','','','','',0),(139,'2018-06-02','H','','','','','',0),(140,'2018-06-02','Jumma','','','','','',0),(141,'2018-06-02','HUe','','','','','',0),(142,'2018-06-03','FRANCOIS','','','','','',0),(143,'2018-06-03','FRANCOIS','','','','','',0),(144,'2018-06-03','FRANCOIS','','','','','',0),(145,'2018-06-03','jumma','','','','','',0),(146,'2018-06-03','Bienvenue','','','','','',0),(147,'2018-06-04','asdfkj','','','','','',0),(148,'2018-06-15','asdf','','','','','',0),(149,'2018-06-15','Tino','','','','','',0),(150,'2018-06-15','FRANCOIS','','','','','',0),(151,'2018-06-15','FRANCOIS','','','','','',0),(152,'2018-06-15','FRANCOIS','','','','','',0),(153,'2018-06-15','FRANCOIS','','','','','',0),(154,'2018-06-19','ggg','','','','','',0),(155,'2018-06-19','janviere','','','','','',0),(156,'2018-06-19','Alice','','','','','',0),(157,'2018-06-20','aslidhf','','','','','',0),(158,'2018-07-24','sa,mana','','','','','',0),(159,'2018-08-08','safs','','','','','',0),(160,'2018-08-08','asdf','','','','','',0),(161,'2018-08-09','asdf','','','','','',0),(162,'2018-08-09','sfasf','','','','','',0),(163,'2018-08-09','Jules','','','','','',0),(164,'2018-08-09','asdf','','','','','',0),(165,'2018-08-09','rugiora','','','','','',0),(166,'2018-08-09','asdf','','','','','',0),(167,'2018-08-09','Umugwaneza','','','','','',0),(168,'2018-08-09','asdfasf','','','','','',0),(169,'2018-08-13','askjf','','','','','',0),(170,'2018-08-13','askjf','','','','','',0),(171,'2018-08-13','asdfas','','','','','',0),(172,'2018-08-13','asdfas','','','','','',0),(173,'2018-08-13','asdfas','','','','','',0),(174,'2018-08-13','laksdfj','','','','','',0),(175,'2018-08-13','asdfk','','','','','',0),(176,'2018-08-13','Jamari','','','','','',0),(177,'2018-08-13','Elisa','','','','','',0),(178,'2018-08-13','Janvier','','','','','',0),(179,'2018-08-13','FRANCOIS','','','','','',0),(180,'2018-08-13','Rugira','','','','','',0),(181,'2018-08-13','Hubert','','','','','',0),(182,'2018-08-13','Issa','','','','','',0),(183,'2018-08-13','Issa','','','','','',0);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (8,'Kigali'),(9,'North'),(10,'South'),(11,'East'),(12,'West');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruiter`
--

DROP TABLE IF EXISTS `recruiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruiter` (
  `recruiter_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_rep_name` varchar(60) DEFAULT NULL,
  `number_members` int(11) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`recruiter_id`),
  KEY `recruiter_acc_idx` (`account`),
  CONSTRAINT `recruiter_acc` FOREIGN KEY (`account`) REFERENCES `account` (`account_id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruiter`
--

LOCK TABLES `recruiter` WRITE;
/*!40000 ALTER TABLE `recruiter` DISABLE KEYS */;
INSERT INTO `recruiter` VALUES (12,'Rugo',8,1,1,'2018-05-20',20,NULL),(19,'Patrick',2,6,56,'2018-06-02',35,NULL),(20,'Savien',2,3,127,'2018-06-02',37,NULL),(21,'w',2,3,128,'2018-06-02',38,NULL),(22,'w',2,3,129,'2018-06-02',39,NULL),(23,'d',2,9,130,'2018-06-02',40,NULL),(24,'d',2,9,131,'2018-06-02',41,NULL),(25,'d',4,10,132,'2018-06-02',42,NULL),(26,'erer',3,7,135,'2018-06-02',45,NULL),(27,'tino',4,6,136,'2018-06-02',46,NULL),(28,'tino',4,6,137,'2018-06-02',47,NULL),(29,'s',7,9,138,'2018-06-02',48,NULL),(30,'Peter',4,3,140,'2018-06-02',49,NULL),(31,'sadfj',2,5,141,'2018-06-02',50,NULL),(32,'alks;df',3,5,147,'2018-06-04',51,'49945459'),(33,'askjdf',2,1,158,'2018-07-24',54,'31x31_p08201820187Europe/Berlin'),(34,'Tino',2,4,165,'2018-08-09',56,'31x31_p12201820188Europe/Berlin'),(35,'Fabrice',2,2,177,'2018-08-13',62,'31x31_p07201820188Europe/Berlin'),(36,'Rugira',3,2,180,'2018-08-13',64,'31x31_p08201820188Europe/Berlin'),(37,'Hubert',3,2,181,'2018-08-13',65,'31x31_p08201820188Europe/Berlin'),(38,'Issa',4,5,183,'2018-08-13',67,'31x31_p08201820188Europe/Berlin');
/*!40000 ALTER TABLE `recruiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruitment`
--

DROP TABLE IF EXISTS `recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruitment` (
  `recruitment_id` int(11) NOT NULL AUTO_INCREMENT,
  `recruit_date` date DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `recruiter` int(11) DEFAULT NULL,
  `salary_agreed` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  PRIMARY KEY (`recruitment_id`),
  KEY `recrtment_recrt_idx` (`recruiter`),
  KEY `recrtmnt_maid_idx` (`maid`),
  CONSTRAINT `recrtment_recrt` FOREIGN KEY (`recruiter`) REFERENCES `recruiter` (`recruiter_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `recrtmnt_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruitment`
--

LOCK TABLES `recruitment` WRITE;
/*!40000 ALTER TABLE `recruitment` DISABLE KEYS */;
INSERT INTO `recruitment` VALUES (9,'2018-08-13',14,19,340000,21);
/*!40000 ALTER TABLE `recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returned_maid`
--

DROP TABLE IF EXISTS `returned_maid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returned_maid` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `return_date` date DEFAULT NULL,
  `reason` varchar(60) DEFAULT NULL,
  `maid` int(11) DEFAULT NULL,
  `comment` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  KEY `return_maid_idx` (`maid`),
  CONSTRAINT `return_maid` FOREIGN KEY (`maid`) REFERENCES `maid` (`maid_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returned_maid`
--

LOCK TABLES `returned_maid` WRITE;
/*!40000 ALTER TABLE `returned_maid` DISABLE KEYS */;
INSERT INTO `returned_maid` VALUES (4,'2018-08-13','Job finished',14,'asdf');
/*!40000 ALTER TABLE `returned_maid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sector` (
  `sector_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  PRIMARY KEY (`sector_id`),
  KEY `sector_district_idx` (`district`),
  CONSTRAINT `sector_district` FOREIGN KEY (`district`) REFERENCES `district` (`district_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
INSERT INTO `sector` VALUES (1,'Nyamirambo',2),(2,'Muhima',2),(4,'Gatenga',1),(5,'Kucukiro',1),(6,'Kagarama',1);
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village`
--

DROP TABLE IF EXISTS `village`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village` (
  `village_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL,
  PRIMARY KEY (`village_id`),
  KEY `village_cell_idx` (`cell`),
  CONSTRAINT `village_cell` FOREIGN KEY (`cell`) REFERENCES `cell` (`cell_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village`
--

LOCK TABLES `village` WRITE;
/*!40000 ALTER TABLE `village` DISABLE KEYS */;
INSERT INTO `village` VALUES (13,'Agahinga',7),(17,'Shyira',22),(18,'Shyorongi',23),(21,'Mbari',25);
/*!40000 ALTER TABLE `village` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'maid_recruit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-16 18:50:49
