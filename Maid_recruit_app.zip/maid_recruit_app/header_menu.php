<div class="parts  eighty_centered no_paddin_shade_no_Border ">  
    <div class="parts  no_paddin_shade_no_Border no_paddin_shade_no_Border ">
        <div class="parts margin_free no_paddin_shade_no_Border" style="margin-left: 300px;font-size: 35px;">
            <marquee>  MAID RECRUITMENT MANAGEMENT SYSTEM</marquee>
        </div>    
        <div class="parts menu eighty_centered no_paddin_shade_no_Border">
            <div class="parts no_paddin_shade_no_Border righted_menu" style="float: right;">
                <a href="index.php">Home</a>
                <a href="aboutus.php">About us</a>
                <a href="login.php">Login</a>
            </div>
        </div>
