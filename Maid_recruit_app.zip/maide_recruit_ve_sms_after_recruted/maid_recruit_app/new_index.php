<?php
    session_start();
    if (!isset($_SESSION['cat'])) {
//        header('location:../index.php');
    }
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  
        <style>
            body{
               background-image: url('web_images/background.png');  
                background-size: cover;
                background-position-x: -5px;
                background-position-y: -5px;
                background-attachment: fixed;
            }
            .righted_menu a{
                background-color: #050b36;
                padding: 10px;
                border-radius: 6px;
            }
            .righted_menu{
                padding: 15px;
                border-bottom: 5px solid #69e7c6;
                padding-bottom: 24px;
            }
            .two_f_box{
                float: right;
                width: 70%;
            }
            .fifty_percent{
                width: 48%;
            }
            #pic1{
                background-image: url('web_images/cleaner.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic2{
                background-image: url('web_images/cook2.png');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic3{
                background-image: url('web_images/happy.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic4{
                background-image: url('web_images/babysit.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            .bg_font{
                font-size: 20px;
                margin-top: 50px ;
                margin-bottom: 50px ;

            }
            .lim_h{/*Limited height*/
                max-height: 200px;
                overflow-y: scroll;
            }

            /* width */
            ::-webkit-scrollbar {
                width: 10px;
            }

            /* Track */
            ::-webkit-scrollbar-track {
                background: #3a88a9; 
            }

            /* Handle */
            ::-webkit-scrollbar-thumb {
                background: #cb8b10; 
            }

            /* Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
                background: #555; 
            }
            .bg_pic{
                float: right;  

            }
            .top_l_bg{
                position: fixed;
                top: -7px;
                left: -10px;
                height:380px;
                width: 380px;
                background-size: 100%;
                background-repeat: no-repeat;
               background-image: url('web_images/main2.png');
            }
        </style>
    </head>
    <body>
        <?php include 'header_menu.php'; ?>
        <div class="parts top_l_bg no_shade_noBorder">

        </div>
        <div id="fb-root"></div>

        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>  

        <div class="parts eighty_centered top_off_x heit_free no_paddin_shade_no_Border">
            <div class="parts two_f_box no_paddin_shade_no_Border margin_free">
                <div class="parts fifty_percent link_cursor off no_paddin_shade_no_Border banner reverse_border">
                    <div class="parts fixed_box_64 no_shade_noBorder">

                    </div>
                    <span style="float: left;margin-top: 10px; margin-left: 20px;"><a href="maid_reg.php">Find a job</a> </span>
                </div>
                <div class="parts fifty_percent link_cursor off no_paddin_shade_no_Border banner reverse_border">
                    <div class="parts fixed_box_64 no_shade_noBorder">
                    </div>
                    <span style="float: left;margin-top: 10px;  margin-left: 20px;">
                        <a href="new_find_worker.php">  Find  a Maid</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="parts eighty_centered  heit_free no_paddin_shade_no_Border">

            <div class="parts two_fifty_left bg_pic" id="pic2">  </div>
            <div class="parts two_fifty_left bg_pic" id="pic3">  </div>
            <div class="parts two_fifty_left bg_pic" id="pic4">  </div>
        </div>
        <div class="parts eighty_centered  heit_free no_paddin_shade_no_Border bg_font">
            Find any household assistant
        </div>
    </div>
    <div class="parts eighty_centered x_height_fifty x_height_two_fifty  no_paddin_shade_no_Border relate_height">
        <div class="parts thirty_Per_cent_two_h skin">
            <div class="part full_center_two_h heit_free no_paddin_shade_no_Border"> Why we are best</div>
            <div class="parts full_center_two_h no_shade_noBorder heit_free">
                <div class="parts no_paddin_shade_no_Border bx_5050 contrast"></div>
                Find a maidservant that help you  with your household
            </div>
            <div class="parts full_center_two_h no_shade_noBorder heit_free">
                <div class="parts no_paddin_shade_no_Border bx_5050 contrast"></div>
                Find a maidservant that help cope with your household
            </div>

        </div>
        <div class="parts thirty_Per_cent_two_h skin incenter no_shade_noBorder reverse_border"> 

        </div>
        <div class="parts thirty_Per_cent_two_h skin no_paddin_shade_no_Border" style="float: right;">

            <div class="parts full_center_two_h no_shade_noBorder heit_free lim_h" style="padding-left: 0px;">

                <?php
//                    list_maid_categories();
                    list_maid_categories();
                ?>

            </div>

        </div>
    </div>

    <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
    <div class="parts eighty_centered footer"><marque> Copyrights <?php echo date("Y") ?></marque></div>
</body>
</html>
<?php

    function list_maid_by_cat($category) {
        require_once 'web_db/connection.php';
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name, maid.experience, maid.religion from maid"
                . "  join village on village.village_id=maid.village "
                . " join profile on profile.profile_id=maid.profile"
                . " where maid.prefered_job=:job";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":job" => $category));
        ?>

        <style>
            .dataList_table{
                border-collapse: collapse;
                width: 100%;
            }
            .dataList_table td{
                padding: 5px;
            }
            .dataList_table thead{
                text-transform: capitalize;
                background-color: #0c4561;
                color: #fff;

            }
        </style>
        <table class="dataList_table">
            <thead><tr>
                    <td> name </td>
                    <td> Experience </td>
                    <td> Religion </td>
                </tr></thead>
            <?php while ($row = $stmt->fetch()) { ?>
                <tr> 
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['religion']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_maid_categories() {
        require_once 'web_db/connection.php';
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name, maid.education_level, maid.prefered_job  from maid"
                . "  "
                . " join profile on profile.profile_id=maid.profile"
                . " where maid.available='yes'";
        ?>
        <style>
            .dataList_table{
                border-collapse: collapse;
                margin-top: 10px;
            }
            .dataList_table td{
                padding: 5px;
            }
            .dataList_table thead{
                text-transform: capitalize;
                background-color: #0c4561;
                color: #fff;

            }
            li{
                line-height: 3em;
                font-size: 12px;
                text-decoration: underline;
                text-transform: uppercase;
                color: #054811;
                font-weight: bolder;
            }
        </style>
        <ul>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <li>
                    <?php echo $row['education_level']; ?>
                </li>
                <?php list_maid_by_cat($row['prefered_job']); ?> 

            <?php } ?></ul> 
        <?php
    }
    