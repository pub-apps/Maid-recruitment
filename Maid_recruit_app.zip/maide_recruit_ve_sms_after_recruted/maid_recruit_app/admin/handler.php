<?php

    session_start();

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_province'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_province_id_by_province_name($_POST['cbo_province']);
        return $id;
    }
    if (isset($_POST['cbo_district'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_district_id_by_district_name($_POST['cbo_district']);
        return $id;
    }
    if (isset($_POST['cbo_sector'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_cell'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
        return $id;
    }
    if (isset($_POST['cbo_sector'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_maid'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_maid_id_by_maid_name($_POST['cbo_maid']);
        return $id;
    }
    if (isset($_POST['cbo_recruiter'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_recruiter_id_by_recruiter_name($_POST['cbo_recruiter']);
        return $id;
    }
    if (isset($_POST['cbo_maid'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_maid_id_by_maid_name($_POST['cbo_maid']);
        return $id;
    }
    if (isset($_POST['cbo_village'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_village_id_by_village_name($_POST['cbo_village']);
        return $id;
    }

    if (isset($_POST['table_to_update'])) {
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo $_SESSION['id_upd'];
    }


//The Delete from account
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];

        echo $obj->deleteFrom_account($id);
    }
//The Delete from account_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete from profile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete from image
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete from province
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'province') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_province($id);
    }
//The Delete from district
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'district') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_district($id);
    }
//The Delete from sector
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_sector($id);
    }
//The Delete from cell
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_cell($id);
    }
//The Delete from contact_us
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'contact_us') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_contact_us($id);
    }
//The Delete from village
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'village') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_village($id);
    }
//The Delete from org
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'org') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_org($id);
    }
//The Delete from recruiter
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'recruiter') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_recruiter($id);
    }
//The Delete from recruitment
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'recruitment') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_recruitment($id);
    }
//The Delete from return
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'return') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_return($id);
    }
//The Delete from maid
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'maid') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_maid($id);
    }

// <editor-fold defaultstate="collapsed" desc="-- Locations -----">
// 
    if (isset($_POST['cell_by_sector'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $res = $obj->specl_cells_by_sectors($_POST['cell_by_sector']);
        echo $res;
    }
    if (isset($_POST['village_by_cell'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $res = $obj->specl_village_by_cell($_POST['village_by_cell']);
        echo $res;
    }
// </editor-fold>

    if (isset($_POST['maidid_confirm'])) {
        require_once '../web_db/updates.php';
        $obj = new updates();
        $id = $_POST['maidid_confirm'];
        $res = $obj->update_maid_status('available', $id);
        echo $res;
    }
    if (isset($_POST['approve_req'])) {
        require_once '../web_db/updates.php';
        $obj = new updates();
        $obj->update_maid_status('recruited', $_POST['approve_req']);
//        $obj->update_maid_available('no', $_POST['approve_req']);
    }

    if (filter_has_var(INPUT_POST, 'search_report')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $search_report = filter_input(INPUT_POST, 'search_report');
        echo $obj->get_maid_by_names($search_report);
    }
    if (filter_has_var(INPUT_POST, 'maid_by_gender')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $obj->list_maid_categories(filter_input(INPUT_POST, 'maid_by_gender'));
    }
    if (filter_has_var(INPUT_POST, 'confirm_pending')) {
        require_once '../web_db/multi_values.php';
        require_once '../web_db/new_values.php';
        require_once '../web_db/updates.php';
        $new = new new_values();
        $udp = new updates();
        // $new->new_recruitment($recruit_date, $_POST['confirm_pending'], $recruiter, $salary_agreed, $user);
        $obj = new multi_values();

        $udp->update_maid_status('available', $_POST['confirm_pending']);
    }