<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> account </td>
                    <td> account_category </td><td> date_created </td><td> profile </td><td> username </td><td> password </td><td> is_online </td>
                    <td>Delete</td>
                    <td>Update</td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $row['account_category']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_created']; ?>
                    </td>
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>
                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['is_online']; ?>
                    </td>
                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }

//chosen individual field
    function get_chosen_account_account_category($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    }

    function get_chosen_account_date_created($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_created'];
        echo $field;
    }

    function get_chosen_account_profile($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_account_username($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    }

    function get_chosen_account_password($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    }

    function get_chosen_account_is_online($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['is_online'];
        echo $field;
    }

    function list_account_category() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> account_category </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $row['name']; ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_account_category_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function list_profile() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile where profile.profiledeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> profile </td>
                    <td> dob </td><td> name </td><td> last_name </td><td> gender </td><td> telephone_number </td><td> email </td><td> residence </td><td> image </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $row['dob']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telephone_number']; ?>
                    </td>
                    <td>
                        <?php echo $row['email']; ?>
                    </td>
                    <td>
                        <?php echo $row['residence']; ?>
                    </td>
                    <td>
                        <?php echo $row['image']; ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_profile_dob($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    }

    function get_chosen_profile_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.name from profile
                join maid on profile.profile_id=maid.profile
                where maid.maid_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_profile_educ($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.education_level from profile
                join maid on profile.profile_id=maid.profile
                where maid.maid_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['education_level'];
        echo $field;
    }

    function get_chosen_profile_last_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    }

    function get_chosen_profile_gender($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    }

    function get_chosen_profile_telephone_number($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.phone from maid
                    join profile on profile.profile_id=maid.profile
                    where maid.maid_id=:profile_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['phone'];
        echo $field;
    }

    function get_chosen_profile_email($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    }

    function get_chosen_profile_residence($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    }

    function get_chosen_profile_image($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

    function list_image() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from image where image.imagedeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> image </td>
                    <td> path </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $row['path']; ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_image_path($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

    function list_province() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from province   ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> province </td>
                    <td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['province_id']; ?>
                    </td>
                    <td class="name_id_cols province " title="province" >
                        <?php echo $row['name']; ?>
                    </td>


                    <td>
                        <a href="#" class="province_delete_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="province_update_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_province_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   province.name from province where province_id=:province_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':province_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function list_district() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from district  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> district </td>
                    <td> name </td><td> province </td>
                    <td>Delete</td> </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['district_id']; ?>
                    </td>
                    <td class="name_id_cols district " title="district" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['province']; ?>
                    </td>


                    <td>
                        <a href="#" class="district_delete_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_district_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   district.name from district where district_id=:district_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':district_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_district_province($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   district.province from district where district_id=:district_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':district_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['province'];
        echo $field;
    }

    function list_sector() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from sector ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> sector </td>
                    <td> name </td><td> district </td>
                    <td>Delete</td> </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['sector_id']; ?>
                    </td>
                    <td class="name_id_cols sector " title="sector" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['district']; ?>
                    </td>


                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_sector_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   sector.name from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_sector_district($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   sector.district from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['district'];
        echo $field;
    }

    function list_cell() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from cell ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> cell </td>
                    <td> name </td><td> sector </td>
                    <td>Delete</td> </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['sector']; ?>
                    </td>


                    <td >
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_cell_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   cell.name from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_cell_sector($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   cell.sector from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    }

    function list_contact_us() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from contact_us where contact_us.contact_usdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> contact_us </td>
                    <td> account </td><td> date_contact </td><td> message </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['contact_us_id']; ?>
                    </td>
                    <td class="account_id_cols contact_us " title="contact_us" >
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_contact']; ?>
                    </td>
                    <td>
                        <?php echo $row['message']; ?>
                    </td>


                    <td>
                        <a href="#" class="contact_us_delete_link" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="contact_us_update_link" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_contact_us_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.account from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_contact_us_date_contact($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.date_contact from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_contact'];
        echo $field;
    }

    function get_chosen_contact_us_message($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.message from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['message'];
        echo $field;
    }

    function list_village() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from village ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> village </td>
                    <td> name </td><td> cell </td>
                    <td>Delete</td> </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['village_id']; ?>
                    </td>
                    <td class="name_id_cols village " title="village" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['cell']; ?>
                    </td>


                    <td>
                        <a href="#" class="village_delete_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_village_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   village.name from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_village_cell($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   village.cell from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    }

    function list_org() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from org where org.orgdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> org </td>
                    <td> name </td><td> phone </td><td> address </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['org_id']; ?>
                    </td>
                    <td class="name_id_cols org " title="org" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['address']; ?>
                    </td>


                    <td>
                        <a href="#" class="org_delete_link" style="color: #000080;" value="
                           <?php echo $row['org_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="org_update_link" style="color: #000080;" value="
                           <?php echo $row['org_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_org_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   org.name from org where org_id=:org_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':org_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_org_phone($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   org.phone from org where org_id=:org_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':org_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['phone'];
        echo $field;
    }

    function get_chosen_org_address($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   org.address from org where org_id=:org_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':org_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['address'];
        echo $field;
    }

    function list_recruiter() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "    select recruiter.recruiter_id,recruiter.family_rep_name,recruiter.n_members, "
                . "recruiter.sector,recruiter.phone, profile.name  from recruiter"
                . " join profile on profile.profile_id= recruiter.profile  "
                . "   "
                . " ";
        ?>
        <table class="dataList_table" style="width: 100%;" >
            <thead><tr>
                    <td> recruiter </td>
                    <td> family_rep_name </td>
                    <td> Phone </td>
                    <td> number_members </td>
                    <td> profile </td>
                    <td>Delete</td> 
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['recruiter_id']; ?>
                    </td>
                    <td class="family_rep_name_id_cols recruiter " title="recruiter" >
                        <?php echo $row['family_rep_name']; ?>
                    </td>
                    <td class="" title="recruiter" >
                        <?php echo $row['phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['n_members']; ?>
                    </td>

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <a href="#" class="recruiter_delete_link" style="color: #000080;" value="
                           <?php echo $row['recruiter_id']; ?>">Delete</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_recruiter_family_rep_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.family_rep_name from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['family_rep_name'];
        echo $field;
    }

    function get_chosen_recruiter_number_members($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.number_members from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['number_members'];
        echo $field;
    }

    function get_chosen_recruiter_sector($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.sector from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    }

    function get_chosen_recruiter_profile($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruiter.profile from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function list_recruitment() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select recruitment.recruitment_id,recruitment.recruit_date,recruitment.salary_agreed "
                . " ,profile.name, maid.phone  "
                . " from recruitment "
                . " join maid on maid.maid_id=recruitment.maid"
                . " join profile on profile.profile_id=maid.profile"
                . " join recruiter on recruitment.recruiter=recruiter.recruiter_id "
                . " where maid.status='recruited' "
                . " group by profile.profile_id";
        ?>
        <table class="dataList_table" style="width: 100%;">
            <thead><tr>
                    <td> recruit_date </td>
                    <td> Maid </td>
                    <td> Phone </td>
                    <td> salary_agreed </td>
                    <td>Delete</td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="recruit_date_id_cols recruitment " title="recruitment" >
                        <?php echo $row['recruit_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['phone']; ?>
                    </td>
                    <td>
                        <?php echo $row['salary_agreed']; ?>
                    </td>

                    <td>
                        <a href="#" class="recruitment_delete_link  " style="color: #000080;" value="
                           <?php echo $row['recruitment_id']; ?>">Delete</a>
                    </td>
                    
                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_recruitment_recruit_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruitment.recruit_date from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['recruit_date'];
        echo $field;
    }

    function get_chosen_recruitment_maid($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruitment.maid from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['maid'];
        echo $field;
    }

    function get_chosen_recruitment_recruiter($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruitment.recruiter from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['recruiter'];
        echo $field;
    }

    function get_chosen_recruitment_salary_agreed($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   recruitment.salary_agreed from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['salary_agreed'];
        echo $field;
    }

    function list_return() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select returned_maid.return_id,  returned_maid.return_date,  returned_maid.reason,  returned_maid.maid,  returned_maid.comment,profile.name from returned_maid "
                . " join maid on maid.maid_id= returned_maid.maid"
                . " "
                . "   join profile on profile.profile_id=maid.profile  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> return </td>
                    <td> return_date </td>
                    <td> reason </td>
                    <td> maids </td>
                    <td> comment </td>
                    <td> Delete</td>
                    <td> Update</td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['return_id']; ?>
                    </td>
                    <td class="return_date_id_cols return " title="return" >
                        <?php echo $row['return_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['reason']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['comment']; ?>
                    </td>
                    <td>
                        <a href="#" class="return_delete_link" style="color: #000080;" value="
                           <?php echo $row['return_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="return_update_link" data-bind="return" style="color: #000080;" value="
                           <?php echo $row['return_id']; ?>">Update</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_return_return_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   return.return_date from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['return_date'];
        echo $field;
    }

    function get_chosen_return_reason($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   returned_maid.reason from returned_maid where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['reason'];
        echo $field;
    }

    function get_chosen_return_maid($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   return.maid from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['maid'];
        echo $field;
    }

    function get_chosen_return_comment($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   returned_maid.comment from returned_maid where returned_maid.return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    }

    function list_maid() {

        $database = new dbconnection();
        $db = $database->openconnection();
        $sql = "select maid.maid_id,  maid.maid_id,profile.name as worker  ,maid.id_number,  maid.sex, "
                . " maid.village,maid.salary,  maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status"
                . ", certificates.file from maid  "
                . "   "
                . " join profile on profile.profile_id=maid.profile "
                . " join certificates on certificates.maid= maid.maid_id "
                . " where available='yes'"
                . " group by maid.maid_id";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> Maid </td>
                    <td> sex </td>

                    <td> id_number </td>
                    <td> Education level </td>
                    <td> Salary </td>
                    <td> experience </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Delete</td> 
                    <td> Update</td> </tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['worker']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td> <?php echo $row['salary']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>
                    <td>
                        <a href="#" class="maid_delete_link" style="color: #000080;" value="
                           <?php echo $row['maid_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="maid_update_link" style="color: #000080;" value="
                           <?php echo $row['maid_id']; ?>" data-bind="maid">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_maid_report() {
        $database = new dbconnection();
        $db = $database->openconnection();
        $sql = "select maid.maid_id,maid.salary,  maid.maid_id,profile.name as worker,maid.id_number,  maid.sex "
                . " , maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status"
                . ", certificates.file from maid  "
                . " join profile on profile.profile_id=maid.profile "
                . " join certificates on certificates.maid= maid.maid_id "
                . " where status='available'"
                . "  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> worker </td>
                    <td> sex </td>

                    <td> id_number </td>
                    <td> Education level </td>
                    <td> salary </td>
                    <td> experience </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Certificate</td>
                </tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['worker']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>

                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td> <?php echo $row['salary']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>
                    <td><a href="../web_images/certificates/<?php echo $row['file'] . '.pdf'; ?>" target="blank"> Download</a>  </td>


                </tr>
            <?php } ?></table>
        <?php
    }

    function list_maid_recruited() {

        $database = new dbconnection();
        $db = $database->openconnection();
        $sql = "select maid.maid_id,  maid.maid_id,profile.name as worker ,maid.id_number,  maid.sex, "
                . "   maid.experience,recruiter.family_rep_name,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status"
                . ", certificates.file from maid  "
                . "  join recruitment on recruitment.maid=maid.maid_id"
                . " join recruiter on recruiter.recruiter_id=recruitment.recruiter "
                . " join profile on profile.profile_id=maid.profile "
                . " join certificates on certificates.maid= maid.maid_id "
                . " where maid.status='recruited'"
                . " group by profile.profile_id"
                . "  ";
        ?>
<table class="dataList_table" style="width: 100%;">
            <thead><tr>
                    <td> Maid </td>

                    <td> Family name </td>
                    <td> id_number </td>
                    <td> Education level </td>
                    <td> experience </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Delete</td> 
                </tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['worker']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['family_rep_name']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>
                    
                    <td>
                        <a href="#" class="maid_delete_link" style="color: #000080;" value="
                           <?php echo $row['maid_id']; ?>">Delete</a>
                    </td>
                   
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_lastmaid() {

        $db = new dbconnection();
        $sql = "select   maid.maid_id from maid order by maid.maid_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['maid_id'];
        return $userid;
    }

    function get_last_certificates() {
        $con = new dbconnection();
        $sql = "select certificates.certificates_id from certificates
                    order by certificates.certificates_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['certificates_id'];
        return $first_rec;
    }

    function get_recruiter_prifileid($account) {
        $con = new dbconnection();
        $sql = "
                select recruiter.recruiter_id from recruiter
                    join profile on profile.profile_id=recruiter.profile
                    join account on account.profile= profile.profile_id
                where account.account_id=:account                ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account" => $account));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruiter_id'];
        return $first_rec;
    }

//chosen individual field
    function get_chosen_maid_sex($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.sex from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sex'];
        echo $field;
    }

    function get_chosen_maid_village($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.village from maid
                        join profile on profile.profile_id=maid.profile
                        where maid.maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['village'];
        echo $field;
    }

    function get_chosen_maid_id_number($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.id_number from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['id_number'];
        echo $field;
    }

    function get_chosen_maid_experience($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.experience from maid 
                join profile on profile.profile_id=maid.profile
                        where maid.maid_id=:maid_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['experience'];
        echo $field;
    }

    function get_profileid_by_maid($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select maid.profile from maid where maid.maid_id=:maid_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_maid_religion($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.religion from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['religion'];
        echo $field;
    }

    function get_chosen_maid_prefered_job($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.prefered_job from maid
                join profile on profile.profile_id=maid.profile
                        where maid.maid_id=:maid_id  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['prefered_job'];
        echo $field;
    }

    function get_chosen_maid_available($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   maid.available from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['available'];
        echo $field;
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile required"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="sml_combo cbo_district"><option>-- 
                district ---</option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="sml_combo" required="" name="txt_sector_id" id="sp_combo_sectr">
            <option> </option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select class="sml_combo" id="sp_combo_cell"><option>-- Cell --</option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_recruiter_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name,   recruiter.recruiter_id     from recruiter"
                . " join profile on profile.profile_id=recruiter.profile "
                . " ";
        ?>
        <select class="textbox cbo_recruiter" required=""><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['recruiter_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_maid_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name,  maid.maid_id  from profile join maid on maid.profile=profile.profile_id where maid.status='available' or maid.available='yes'";
        ?>
        <select class="textbox cbo_maid" required=""><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_maid_for_recruiter_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name,  maid.maid_id "
                . " from profile join maid on maid.profile=profile.profile_id "
                . " where maid.status='available' or maid.available='yes' "
                . "  and maid.status<> 'requested'  "
                . "";
        ?>
        <select class="textbox cbo_maid" required=""><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_maid_toreturn_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name,  maid.maid_id  from profile"
                . " join maid on maid.profile=profile.profile_id where maid.status='recruited'";
        ?>
        <select class="textbox cbo_maid" required=""><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_village_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,   village.name from village";
        ?>                            
        <select class="sml_combo" id="sp_combo_village"><option>-- Villages --</option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function specl_cells_by_sectors($sectr) {
        try {
            $database = new dbconnection();
            $db = $database->openconnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select cell.cell_id, cell.name from cell join sector on cell.sector = sector.sector_id   where  sector.sector_id = :name";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":name" => $sectr));
            $data = array();
            while ($row = $stmt->fetch()) {
                $data[] = array(
                    'id' => $row['cell_id'],
                    'name' => $row['name']
                );
            }
            return json_encode($data);
        } catch (PDOException $e) {
            echo $e;
        }
    }

    function specl_village_by_cell($sectr) {
        try {
            $database = new dbconnection();
            $db = $database->openconnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select village.village_id, village.name from village join cell on village.cell=cell.cell_id  where  cell.cell_id = :name";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":name" => $sectr));
            $data = array();
            while ($row = $stmt->fetch()) {
                $data[] = array(
                    'id' => $row['village_id'],
                    'name' => $row['name']
                );
            }
            return json_encode($data);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function get_lastprofile() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile.profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_chosen_recruiter_entry_date($id) {

        $db = new dbconnection();
        $sql = "select   recruiter.entry_date from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    }

    function get_chosen_recruiter_username($id) {

        $db = new dbconnection();
        $sql = "select   recruiter.username from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    }

    function get_chosen_recruiter_password($id) {

        $db = new dbconnection();
        $sql = "select   recruiter.password from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    }

    function list_Pending_maid() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "    select  maid.village,maid.maid_id,maid.salary,  maid.sex,  maid.village,  maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status,  maid.id_number,profile.name as profile,  maid.phone "
                . " from maid join profile on profile.profile_id = maid.profile  "
                . " where maid.status='pending'"
                . " ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> maids </td>
                    <td> sex </td>
                    <td> id_number </td>
                    <td> Education level </td>
                    <td> Salary  </td>
                    <td> Phone </td>
                    <td> experience </td>
                    <td> religion </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Option </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td> <?php echo $row['salary']; ?> </td>
                    <td> <?php echo $row['phone']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['religion']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>    <?php echo $row['available']; ?> </td>
                    <td>    <a href="#" class="confirm_pending" data-bind="<?php echo $row['maid_id']; ?>" >Approve</a> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_requested_maid() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from maid 
                   join profile on profile.profile_id=maid.profile where maid.status='requested' 
             ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> Maids </td>
                    <td> sex </td>
                    <td> id_number </td>
                    <td> Education level </td>
                    <td> Salary </td>
                    <td> experience </td>
                    <td> religion </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Option </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> 
                    </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td> <?php echo $row['salary']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['religion']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>
                    <td>
                        <a href="#" class="approve_req" data-bind="<?php echo $row['maid_id']; ?>"> Approve</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_available_maid() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select maid.village,maid.maid_id, maid.salary, maid.sex,  maid.village,  maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status,  maid.id_number,profile.name as profile,  maid.phone from maid "
                . " join profile on profile.profile_id = maid.profile  "
                . " where status<>'requested' and status<> 'pending' and available='yes' or available='available' or status='available' ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> Maid </td>
                    <td> sex </td>
                    <td> id_number </td>
                    <td> Education level </td>
                    <td> Salary  </td>
                    <td> experience </td>
                    <td> religion </td>
                    <td> preferred_job </td>
                    <td> available </td>
                </tr> </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td> <?php echo $row['salary']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['religion']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_maid_by_user($user) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select recruitment.recruitment_id,recruitment.recruit_date,recruitment.salary_agreed, maid.maid_id "
                . " ,profile.name, profile.name  from recruitment "
                . " join maid on maid.maid_id=recruitment.maid"
                . " join profile on profile.profile_id=maid.profile"
                . " join recruiter on recruitment.recruiter=recruiter.recruiter_id "
                . " join account on account.account_id=recruiter.account"
                . " where recruiter.account=:user";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":user" => $user));
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> hiring </td>
                    <td> recruit_date </td><td> worker </td><td> salary_agreed </td>
                    <td>Delete</td> </tr></thead>

            <?php while ($row = $stmt->fetch()) { ?><tr> 

                    <td>
                        <?php echo $row['recruitment_id']; ?>
                    </td>
                    <td class="recruit_date_id_cols recruitment " title="recruitment" >
                        <?php echo $row['recruit_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['salary_agreed']; ?>
                    </td>

                    <td>
                        <a href="#" class="recruitment_delete_link" style="color: #000080;" value="
                           <?php echo $row['recruitment_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="maid_update_link" style="color: #000080;" value="
                           <?php echo $row['maid_id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function my_profile($user) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name , account.username,account.password from profile "
                . " join account on account.profile=profile.profile_id"
                . " where account.account_id=:user";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":user" => $user));
        ?>
        <table class="dataList_table ful_width">
            <thead><tr>
                    <td> name </td>
                    <td> Username </td><td> Password </td>

                </tr></thead>
            <?php while ($row = $stmt->fetch()) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td class="recruit_date_id_cols recruitment " title="recruitment" >
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <span id="show_any"> </span><span>    <?php echo $row['password']; ?></span>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function my_recruitments($user) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from recruitment
                       join maid on maid.maid_id=recruitment.maid
                       join profile on profile.profile_id=maid.profile
                     where recruitment.user=:user ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":user" => $user));
        ?>
        <table class="dataList_table ful_width">
            <thead><tr>
                    <td> name </td>
                    <td> Recruit Date </td>
                    <td> Salary Agreed </td>

                </tr></thead>
            <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['recruit_date']; ?>
                    </td>
                    <td class="recruit_date_id_cols recruitment " title="recruitment" >
                        <?php echo $row['salary_agreed']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_maid_by_names($names) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $sql = "select maid.maid_id,  maid.maid_id,profile.name as worker ,maid.id_number,  maid.sex, "
                . " maid.village,  maid.experience,  maid.religion,  maid.prefered_job,  maid.available,  maid.profile,  maid.education_level,  maid.status"
                . " from maid  "
                . " join profile on profile.profile_id=maid.profile "
                . " where profile.name=:name"
                . "  ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":name" => $names));
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> worker </td>
                    <td> sex </td>
                    <td> village </td>
                    <td> id_number </td>
                    <td> Education level </td>
                    <td> experience </td>
                    <td> preferred_job </td>
                    <td> available </td>
                    <td> Certificate</td>
            </thead>
            <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>
                        <?php echo $row['worker']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td>
                        <?php echo $row['village']; ?>
                    </td>
                    <td> <?php echo $row['id_number']; ?> </td>
                    <td> <?php echo $row['education_level']; ?> </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['prefered_job']; ?>
                    </td>
                    <td>
                        <?php echo $row['available']; ?>
                    </td>
                    <td><a href="../web_images/certificates/<?php echo $row['file'] . '.pdf'; ?>" target="blank"> Download</a>  </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_user_username_by_user($username) {
        $con = new dbconnection();
        $sql = "select    username  from account   where  account.username =:username";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":username" => $username));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['username'];
        return $userid;
    }

    function get_phone_by_maid_id($maid) {
        $con = new dbconnection();
        $sql = "select    phone  from maid   where  maid.maid_id=:maid";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":maid" => $maid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['phone'];
        return $userid;
    }

    function get_family_phone_by_maid_id($maid) {
        $con = new dbconnection();
        $sql = "select r2.phone from recruitment r 
                join recruiter r2 on r2.recruiter_id =r.recruiter
                join profile p on p.profile_id =r2.profile 
                where r.maid=:maid  group by r2.phone";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":maid" => $maid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['phone'];
        return $userid;
    }

    // <editor-fold defaultstate="collapsed" desc="-----These used by js post and  are the result used from new_find_worker.php file on the home page">
    function list_maid_by_cat($category, $sex) {
        
        
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id, profile.name,maid.sex,maid.maid_id,maid.prefered_job, "
                . "maid.experience, maid.religion , maid.education_level ,"
                . "maid.status from maid"
                . "    "
                . " join profile on profile.profile_id=maid.profile"
                . " where    "
                . "   maid.sex=:sex  ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":sex" => $sex));
        ?>
        <style>
            .dataList_table{
                border-collapse: collapse;
                width: 100%;
            }
            .dataList_table td{
                padding: 5px;
            }
            .dataList_table thead{
                text-transform: capitalize;
                background-color: #0c4561;
                color: #fff;

            }
            .j{

            }
        </style>
        <table class="dataList_table">
            <thead><tr>
                    <td> name </td>
                    <td> sex </td>
                    <td> Experience </td>
                    <td> Religion </td>
                    <td> Education Level </td>
                    <td> Choose </td>
                </tr></thead>
            <?php
           
            while ($row = $stmt->fetch()) {
                    $mark = ($row['status'] == 'recruited' || $row['status'] == 'requested') ? '#c180a5' : 'transparent';
                ?>
                <tr style="background-color: <?php echo $mark; ?>"> 
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td class="sex_id_cols maid " title="maid" >
                        <?php echo $row['sex']; ?>
                    </td>
                    <td>
                        <?php echo $row['experience']; ?>
                    </td>
                    <td>
                        <?php echo $row['religion']; ?>
                    </td>
                    <td>
                        <?php echo $row['education_level']; ?>
                    </td>

                    <td>
                        <?php
                        if ($row['status'] == 'recruited' || $row['status'] == 'requested') {
                            echo '  Choose';
                        } else {
                            ?>
                            <a href="#" class="choose_maid_link" data-bind="<?php echo $row['maid_id']; ?>" style="color: #fff;">Choose</a> 
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_maid_categories($sex) {

//        $database = new dbconnection();
//        $db = $database->openConnection();
//        $sql = " select profile.name, maid.education_level, maid.prefered_job , maid.status from maid"
//                . " join profile on profile.profile_id=maid.profile"
//                . " where maid.available='yes' and maid.sex=:sex";
//        $stmt = $db->prepare($sql);
//        $stmt->execute(array(":sex" => $sex));
        $this->list_maid_by_cat('', $sex)
        ?>
        <script>
            $('.choose_maid_link').click(function () {
                var maid_id = $(this).data('bind');
                $('#txt_chosen_maid').val(maid_id);
                $('.pane_overlay').fadeIn(200);
        //update the maid pending requested
                return false;
            });
            $('.close_pane').click(function () {
                $('.pane_overlay').fadeOut(200);
            });
        </script>
        <style>
            .dataList_table{
                border-collapse: collapse;
                margin-top: 10px;
            }
            .dataList_table td{
                padding: 5px;
            }
            .dataList_table thead{
                text-transform: capitalize;
                background-color: #0c4561;
                color: #fff;

            }
            li{
                line-height: 3em;
                font-size: 12px;
                text-decoration: underline;
                text-transform: uppercase;
                color: #054811;
                font-weight: bolder;
            }
        </style>
        
        <ul>
            <?php 
            // while ($row = $stmt->fetch()) { ?><tr> 
                   <?php // echo $row['education_level']; ?>   
                
                <?php //$this->list_maid_by_cat($row['prefered_job'], $sex); ?> 

            <?php // } ?>
        </ul> 
        <?php
    }

// </editor-fold>
}
