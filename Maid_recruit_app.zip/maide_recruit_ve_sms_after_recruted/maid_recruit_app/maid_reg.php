<?php
//require_once 'web_db/multi_values.php';
    require_once './home_data.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  
        <style>
            body{
                background-image: url('web_images/background.png');  
                background-size: cover;
                background-position-x: -5px;
                background-position-y: -5px;
                background-attachment: fixed;
            }
            .righted_menu a{
                background-color: #050b36;
                padding: 10px;
                border-radius: 6px;
            }
            .righted_menu{
                padding: 15px;
                border-bottom: 5px solid #69e7c6;
                padding-bottom: 24px;
            }
            .two_f_box{
                float: right;
                width: 70%;
            }
            .fifty_percent{
                width: 48%;
            }
            #pic1{
                background-image: url('web_images/cleaner.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic2{
                background-image: url('web_images/cook2.png');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic3{
                background-image: url('web_images/happy.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #pic4{
                background-image: url('web_images/babysit.JPG');
                background-size: 100%;
                background-repeat: no-repeat;
            }
            .bg_font{
                font-size: 20px;
                margin-top: 50px ;
                margin-bottom: 50px ;

            }
            .lim_h{/*Limited height*/
                max-height: 200px;
                overflow-y: scroll;
            }

            /* width */
            ::-webkit-scrollbar {
                width: 10px;
            }

            /* Track */
            ::-webkit-scrollbar-track {
                background: #3a88a9; 
            }

            /* Handle */
            ::-webkit-scrollbar-thumb {
                background: #cb8b10; 
            }

            /* Handle on hover */
            ::-webkit-scrollbar-thumb:hover {
                background: #555; 
            }
            .bg_pic{
                float: right;  

            }
            .top_l_bg{
                position: fixed;
                top: -7px;
                left: -10px;
                height:380px;
                width: 380px;
                background-size: 100%;
                background-repeat: no-repeat;
                background-image: url('web_images/main2.png');
            }
            .new_data_table .textbox{
                width: 200px;
            }
            .new_data_table{
                float: right;
            }
            .new_data_table_box{
                border: 1px solid #fff;
                box-shadow: 0px 0px 10px #fff;
                background-color: #546cb0;
                width:45%;
                margin-left: 35%;
            }

            .new_data_table .textbox, select{
                margin: 0px;
            } select{
                margin: 5px;
                width: 100px;
                float: left;
            }
        </style>
    </head>
    <body>
        <?php
            include 'header_menu.php';
        ?>
        <div class="parts top_l_bg no_shade_noBorder">

        </div>
        <div id="fb-root"></div>
        <script>
            (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts eighty_centered top_off_x heit_free no_paddin_shade_no_Border">
            <div class="parts two_f_box no_paddin_shade_no_Border margin_free">

            </div>
        </div>
        <div class="parts eighty_centered  heit_free no_paddin_shade_no_Border" style="text-align: center;font-size: 30px;">
            House Maids Registration form
        </div>

        <div class="parts seventy_centered  heit_free no_paddin_shade_no_Border bg_font new_data_table_box">

            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <?php
                    if (isset($_POST['send_maid'])) {
                        if (isset($_SESSION['table_to_update'])) {
                            if ($_SESSION['table_to_update'] == 'maid') {
                                require_once '../web_db/updates.php';
                                $upd_obj = new updates();
                                $maid_id = $_SESSION['id_upd'];
                                $sex = $_POST['txt_sex'];
                                $village = $_POST['txt_village_id'];
                                $id_number = $_POST['txt_id_number'];
                                $experience = $_POST['txt_experience'];
                                $religion = $_POST['txt_religion'];
                                $prefered_job = $_POST['txt_prefered_job'];
                                $available = 'yes';
                                $upd_obj->update_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $maid_id);
                                unset($_SESSION['table_to_update']);
                            }
                        } else {
                            $sex = $_POST['txt_sex'];
                            $village = trim($_POST['txt_village_id']);
                            $id_number = $_POST['txt_id_number'];
                            $edu_level = $_POST['txt_edu_level'];
                            $experience = $_POST['txt_experience'];
                            $religion = $_POST['txt_religion'];
                            $prefered_job = $_POST['txt_prefered_job'];
                            $available = 'yes';
                            $obj = new new_values();
//new profile
                            $name = $_POST['txt_name'];
                            $obj->new_profile(date('y-m-d'), $name, '', '', '', '', '', 0);
                            $m = new multi_values();
                            $pers = $m->get_lastprofile();
                            $status = 'pending';
                            $phone = $_POST['txt_phone'];
                            $username = ''; // $_POST['txt_username'];
                            $password = ''; //$_POST['txt_password'];
                            $salary = filter_input(INPUT_POST, 'txt_salary');
                            if (empty($village)) {
                                ?><script>alert('You have to choose the village');</script><?php
                            } else {
                                $obj->new_account(10, date('y-m-d'), 0, $username, $password, 'no');

                                $obj->new_maid($sex, $village, $id_number, $experience, $religion, $prefered_job, $available, $pers, $edu_level, $status, $phone, $username, $password, $salary);
                                $last_maid = $m->get_lastmaid();
                                $next_certif = $m->get_last_certificates() + 1;
                                $obj->new_certificates($last_maid, $next_certif);
//                                savefile_certificate();
                                ?><script>
                                                    alert('Your account was saved successfully!');
                                </script><?php
                            }
                        }
                    }
                ?>

            </div>

            <form action="maid_reg.php" method="post" enctype="multipart/form-data">
                <input type="hidden" id="txt_village_id"   name="txt_village_id"/><table class="new_data_table">
                    <tr>
                        <td>Names</td>
                        <td><input type="text" placeholder="Enter both names" name="txt_name" required="" class="textbox" /></td>
                    </tr>
                    <tr><td>sex :</td><td> 
                            <select class="textbox"  name="txt_sex" required>
                                <option>
                                    Male
                                </option>
                                <option>
                                    Female
                                </option>
                            </select>
                        </td>
                    </tr>
                    <tr><td>District :</td><td> 
                            <select  class="textbox"  name="txt_village_id" >
                                <option>Kicukiro</option>
                                <option>Nyarugenge</option>
                                <option>Gasabo </option>
                                <option>Rulindo </option>
                                <option>Gakenke </option>
                                <option>Musanze </option>
                                <option>Gicumbi </option>
                                <option>Burera </option>
                                <option>Nyabihu </option>
                                <option>Rubavu </option>
                                <option>Karongi </option>
                                <option>Nyagatare </option>
                                <option>Rwamagana </option>
                                <option>Kayonza </option>
                            </select>
                            
                           </td>
                    </tr>
                    <tr><td>id_number :</td><td> <input type="text"   maxlength="16" id="txt_id_number"  name="txt_id_number" required class="textbox only_numbers" value="<?php echo trim(chosen_id_number_upd()); ?>"   />  </td></tr>
                    <tr>
                        <td>Phone Number</td>
                        <td>
                            <input type="text"  required name="txt_phone" maxlength="10" class=" textbox only_numbers" placeholder="(+250)Enter phone number" />

                        </td>
                    </tr>
                    <tr><td>Education Level :</td><td> 
                            <select name="txt_edu_level" required class="textbox only_numbers txt_edu_level">
                                <option></option>
                                <option>Not educated</option>
                                <option> Not finished primary school</option>
                                <option> Finished only primary school</option>
                                <option> Finished O level school</option>
                                <option> Finished A level school</option>
                                <option> Graduated Bachelor degree school</option>
                                <option> Graduated Masters degree school</option>
                            </select>
                    <tr><td>experience :</td><td> <input type="text"     name="txt_experience" required class="textbox" value="<?php echo trim(chosen_experience_upd()); ?>"   />  </td></tr>
                    <tr><td>religion :</td><td> <input type="text"     name="txt_religion" required class="textbox" value="<?php echo trim(chosen_religion_upd()); ?>"   />  </td></tr>
                    <tr><td>preferred_job :</td><td> 
                            <select name="txt_prefered_job" required class="textbox">
                                <option></option>
                                <option>Baby sitting</option>
                                <option>Food preparation</option>
                                <option>Cleaning</option>
                                <option>Gardner</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Salary</td>
                        <td><input type="text" class="textbox" id="txt_salary" placeholder="Salary" name="txt_salary"  /></td>
                    </tr>
                    <tr class="off">
                        <td>Username</td>   <td><input type="text" class="textbox" name="txt_username"  /></td></tr>
                    <tr class="off"><td>Password</td>   <td><input type="password" class="textbox" name="txt_password"  /></td>
                    </tr>
                   
                    <tr><td colspan="2"> 
                            <input type="submit" class="confirm_buttons" name="send_maid" value="Save"/>  </td>
                    </tr>
                </table>
            </form>

        </div>
        <div class="parts bg_font no_shade_noBorder "id="age_display">

        </div>
    </div>
    <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
    <script>

                                    //<editor-fold defaultstate="collapsed" desc="----calculate age">
                                    $('#txt_id_number').keyup(function () {
                                        try {
                                            var age_from_nid = $('#txt_id_number').val();
                                            if (age_from_nid.charAt(4) != '') {
                                                var dob = age_from_nid.charAt(1) + age_from_nid.charAt(2) + age_from_nid.charAt(3) + age_from_nid.charAt(4);
                                                var current_year = new Date().getFullYear();
                                                var age = current_year - dob;
                                                $('#age_display').html(age);
                                                if (age < 18) {
                                                    $('#age_display').css('background-color', "red").append('  Not allowed');
                                                    $('.confirm_buttons').hide();
                                                } else {
                                                    $('#age_display').css('background', "none");
                                                    $('.confirm_buttons').show();
                                                }
                                            }
                                        } catch (err) {
                                            alert(err.message);
                                        }
                                    });
                                    //</editor-fold>




                                    $('.txt_edu_level').change(function () {
                                        try {
                                            var level = $(this, 'option:selected').val();
                                            var salary = '';
                                            if (level == 'Not educated') {
                                                salary = '10,000';
                                            } else if (level == 'Not finished primary school') {
                                                salary = '20,000';
                                            } else if (level == 'Finished only primary school') {
                                                salary = '30,000';
                                            } else if (level == 'Finished O level school') {
                                                salary = '40,000';
                                            } else if (level == 'Finished A level school') {
                                                salary = '170,000';
                                            } else if (level == 'Graduated Bachelor degree school') {
                                                salary = '230,000';
                                            } else if (level == 'Graduated Masters degree school') {
                                                salary = '600,000';
                                            }
                                            $('#txt_salary').val(salary);
                                        } catch (err) {
                                            alert(err.message);
                                        }
                                    });

                                    $('#sp_combo_sectr').change(function () {
                                        try {
                                            var cell_by_sector = $('#sp_combo_sectr option:selected').val().trim();
                                            $('#txt_sector_id').val(cell_by_sector);
                                            $('#sp_combo_cell').empty();
                                            $('#sp_combo_cell').append('<option> -- Cell -- </option>');

                                            $.post('admin/handler.php', {cell_by_sector: cell_by_sector}, function (data) {
                                                var final = $.parseJSON(data.trim());
                                                $.each(final, function (i, option) {
                                                    $('#sp_combo_cell').append($('<option/>').attr("value", option.id).text(option.name));
                                                });
                                            });
                                        } catch (err) {
                                            alert(err.message);
                                        }
                                    });

                                    $('#sp_combo_cell').change(function () {
                                        var village_by_cell = $('#sp_combo_cell option:selected').val().trim();

                                        $('#sp_combo_village').empty();
                                        $('#sp_combo_village').append('<option> -- Village -- </option>');
                                        $('#txt_cell_id').val(village_by_cell);
                                        $.post('handler.php', {village_by_cell: village_by_cell}, function (data) {
                                            var final = $.parseJSON(data.trim());
                                            $.each(final, function (i, option) {
                                                $('#sp_combo_village').append($('<option/>').attr("value", option.id).text(option.name));
                                            });
                                        });
                                    });
                                    $('#sp_combo_village').change(function () {
                                        var village_by_cell = $('#sp_combo_village option:selected').val().trim();
                                        $('#txt_village_id').val(village_by_cell);
                                    });
    </script>
</body>
</html>
<?php

    function get_cells_combo() {
        $obj = new multi_values();
        $obj->get_cell_in_combo();
    }

    function get_district_combo() {
        $obj = new multi_values();
        $obj->get_district_in_combo();
    }

    function get_sector_combo() {
        $obj = new multi_values();
        $obj->get_sector_in_combo();
    }

    function get_village_combo() {

        $obj = new multi_values();
        $obj->get_village_in_combo();
    }

    function chosen_sex_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $sex = new multi_values();
                return $sex->get_chosen_maid_sex($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_village_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $village = new multi_values();
                return $village->get_chosen_maid_village($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_id_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $id_number = new multi_values();
                return $id_number->get_chosen_maid_id_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_experience_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $experience = new multi_values();
                return $experience->get_chosen_maid_experience($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_religion_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $religion = new multi_values();
                return $religion->get_chosen_maid_religion($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_prefered_job_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $prefered_job = new multi_values();
                return $prefered_job->get_chosen_maid_prefered_job($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_available_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'maid') {
                $id = $_SESSION['id_upd'];
                $available = new multi_values();
                return $available->get_chosen_maid_available($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function list_maid_categories() {
        require_once 'web_db/connection.php';
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name, maid.education_level, maid.prefered_job  from maid"
                . "  join village on village.village_id=maid.village "
                . " join profile on profile.profile_id=maid.profile"
                . " where maid.available='yes'";
        ?>
        <style>
            .dataList_table{
                border-collapse: collapse;
                margin-top: 10px;
            }
            .dataList_table td{
                padding: 5px;
            }
            .dataList_table thead{
                text-transform: capitalize;
                background-color: #0c4561;
                color: #fff;

            }
            li{
                line-height: 3em;
                font-size: 12px;
                text-decoration: underline;
                text-transform: uppercase;
                color: #054811;
                font-weight: bolder;
            }
        </style>
        <ul>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <li>
                    <?php echo $row['education_level']; ?>
                </li>
                <?php list_maid_by_cat($row['prefered_job']); ?> 

            <?php } ?></ul> 
        <?php
    }

    function savefile_certificate() {
        //save the data
        //get the last post
        //save image with the last post image name

        $mul_obj = new multi_values();
        $target_dir = "web_images/certificates/";
        $target_file = $target_dir . basename($_FILES["my_cert"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
        $ExtensionWithDot = '.' . $imageFileType;

        $file_with_noExtension = basename($target_file, $ExtensionWithDot);
        //save the image in folder (upload)
        $img = $mul_obj->get_last_certificates() + 1;
        $desiredname = $img;
        $newname = $desiredname . '.' . $imageFileType;
        $new_target_file = $target_dir . $newname;
        $target_file_for_db = $new_target_file;

        //save the image in the db (save path)
        // Check if image file is a actual image or fake image
        if (isset($_POST["send"])) {
            $check = getimagesize($_FILES["my_cert"]["tmp_name"]);
            if ($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }
        // Check file size
        if ($_FILES["my_cert"]["size"] > 3000000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if ($imageFileType != "pdf"  ) {
            $uploadOk = 0;
            echo '<br/>You can only upload Image file <br/>';
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["my_cert"]["tmp_name"], $new_target_file)) {
                // echo "The file " . basename($_FILES["ben_file"]["name"]) . " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }
    