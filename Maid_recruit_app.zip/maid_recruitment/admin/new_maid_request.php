<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_maid_request'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'maid_request'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $maid_request_id=$_SESSION['id_upd'];
                      
$entry_date =date("y-m-d");
$User = $_SESSION['userid'];

$description = $_POST['txt_description'];


$upd_obj->update_maid_request($entry_date, $User, $description,$maid_request_id);
unset($_SESSION['table_to_update']);
}}else{$entry_date =date("y-m-d");
$User = $_SESSION['userid'];
$description = $_POST['txt_description'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_maid_request($entry_date, $User, $description);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
maid_request</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_maid_request.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 maid_request saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  maid_request Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_description">Description </label></td><td> <input type="text"     name="txt_description" required id="txt_description" class="textbox" value="<?php echo trim(chosen_description_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_maid_request" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
            <form action="../web_exports/maid_request.php" method="post">
                <input type="submit" name="maid_request" class="exprt_btn  exprt_btn_maid_request" value="Export to Excel"/>
            </form>
        </div>
<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">maid_request List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_maid_request();
                    $obj->list_maid_request($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid_request') {               $id = $_SESSION['id_upd'];
               $entry_date = new multi_values();
               return $entry_date->get_chosen_maid_request_entry_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid_request') {               $id = $_SESSION['id_upd'];
               $User = new multi_values();
               return $User->get_chosen_maid_request_User($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_description_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid_request') {               $id = $_SESSION['id_upd'];
               $description = new multi_values();
               return $description->get_chosen_maid_request_description($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
