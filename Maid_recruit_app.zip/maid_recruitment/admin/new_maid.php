<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_maid'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'maid'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $maid_id=$_SESSION['id_upd'];
                      
$village =trim( $_POST['txt_village_id']);
$sex = $_POST['txt_sex'];
$village = $_POST['txt_village_id'];

$experience = $_POST['txt_experience'];
$religion = $_POST['txt_religion'];
$prefered_job = $_POST['txt_prefered_job'];
$available = $_POST['txt_available'];
$profile = $_POST['txt_profile_id'];

$education_level = $_POST['txt_education_level'];
$status = $_POST['txt_status'];
$id_number = $_POST['txt_id_number'];
$phone = $_POST['txt_phone'];


$upd_obj->update_maid($village, $sex, $village, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $id_number, $phone,$maid_id);
unset($_SESSION['table_to_update']);
}}else{$village =trim( $_POST['txt_village_id']);
$sex = $_POST['txt_sex'];
$village =trim( $_POST['txt_village_id']);
$experience = $_POST['txt_experience'];
$religion = $_POST['txt_religion'];
$prefered_job = $_POST['txt_prefered_job'];
$available = $_POST['txt_available'];
$profile =trim( $_POST['txt_profile_id']);
$education_level = $_POST['txt_education_level'];
$status = $_POST['txt_status'];
$id_number = $_POST['txt_id_number'];
$phone = $_POST['txt_phone'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_maid($village, $sex, $village, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $id_number, $phone);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
maid</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_maid.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_village_id"   name="txt_village_id"/><input type="hidden" id="txt_village_id"   name="txt_village_id"/><input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 maid saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  maid Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_sex">Sex </label></td><td> <input type="text"     name="txt_sex" required id="txt_sex" class="textbox" value="<?php echo trim(chosen_sex_upd());?>"   />  </td></tr>
 <tr><td class="new_data_tb_frst_cols">Village </td><td> <?php get_village_combo(); ?>  </td></tr><tr><td><label for="txt_experience">Experience </label></td><td> <input type="text"     name="txt_experience" required id="txt_experience" class="textbox" value="<?php echo trim(chosen_experience_upd());?>"   />  </td></tr>
<tr><td><label for="txt_religion">Religion </label></td><td> <input type="text"     name="txt_religion" required id="txt_religion" class="textbox" value="<?php echo trim(chosen_religion_upd());?>"   />  </td></tr>
<tr><td><label for="txt_prefered_job">Prefered Job </label></td><td> <input type="text"     name="txt_prefered_job" required id="txt_prefered_job" class="textbox" value="<?php echo trim(chosen_prefered_job_upd());?>"   />  </td></tr>
<tr><td><label for="txt_available">Available </label></td><td> <input type="text"     name="txt_available" required id="txt_available" class="textbox" value="<?php echo trim(chosen_available_upd());?>"   />  </td></tr>
 <tr><td class="new_data_tb_frst_cols">Profile </td><td> <?php get_profile_combo(); ?>  </td></tr><tr><td><label for="txt_education_level">Education Level </label></td><td> <input type="text"     name="txt_education_level" required id="txt_education_level" class="textbox" value="<?php echo trim(chosen_education_level_upd());?>"   />  </td></tr>
<tr><td><label for="txt_status">Pending </label></td><td> <input type="text"     name="txt_status" required id="txt_status" class="textbox" value="<?php echo trim(chosen_status_upd());?>"   />  </td></tr>
<tr><td><label for="txt_id_number">id_number </label></td><td> <input type="text"     name="txt_id_number" required id="txt_id_number" class="textbox" value="<?php echo trim(chosen_id_number_upd());?>"   />  </td></tr>
<tr><td><label for="txt_phone">Phone </label></td><td> <input type="text"     name="txt_phone" required id="txt_phone" class="textbox" value="<?php echo trim(chosen_phone_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_maid" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
            <form action="../web_exports/maid.php" method="post">
                <input type="submit" name="maid" class="exprt_btn  exprt_btn_maid" value="Export to Excel"/>
            </form>
        </div>
<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">maid List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_maid();
                    $obj->list_maid($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function chosen_village_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $village = new multi_values();
               return $village->get_chosen_maid_village($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_sex_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $sex = new multi_values();
               return $sex->get_chosen_maid_sex($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_village_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $village = new multi_values();
               return $village->get_chosen_maid_village($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_experience_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $experience = new multi_values();
               return $experience->get_chosen_maid_experience($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_religion_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $religion = new multi_values();
               return $religion->get_chosen_maid_religion($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_prefered_job_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $prefered_job = new multi_values();
               return $prefered_job->get_chosen_maid_prefered_job($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_available_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $available = new multi_values();
               return $available->get_chosen_maid_available($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $profile = new multi_values();
               return $profile->get_chosen_maid_profile($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_education_level_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $education_level = new multi_values();
               return $education_level->get_chosen_maid_education_level($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $status = new multi_values();
               return $status->get_chosen_maid_status($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_id_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $id_number = new multi_values();
               return $id_number->get_chosen_maid_id_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_phone_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'maid') {               $id = $_SESSION['id_upd'];
               $phone = new multi_values();
               return $phone->get_chosen_maid_phone($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
