//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_update = '';
var id_delete = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {
get_new_data_hide_show();
show_form_toUpdate();
certificates_del_udpate();
get_pages_moving();
dlog_btn_No_Yes();
hide_select_pane()
show_Y_N_dialog();
hide_Y_N_dialog()

        get_account_category_id_combo();        get_profile_id_combo();        get_image_id_combo();        get_province_id_combo();        get_district_id_combo();        get_sector_id_combo();        get_account_id_combo();        get_cell_id_combo();        get_sector_id_combo();        get_profile_id_combo();        get_account_id_combo();        get_maid_id_combo();        get_recruiter_id_combo();        get_maid_id_combo();        get_village_id_combo();        get_profile_id_combo();        get_maid_id_combo();


});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
                $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
                $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_province_id_combo() {
    try {
        $('.cbo_province').change(function () {
            var cbo_province = $('.cbo_province option:selected').val();
                $('#txt_province_id').val(cbo_province);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').val();
                $('#txt_district_id').val(cbo_district);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_maid_id_combo() {
    try {
        $('.cbo_maid').change(function () {
            var cbo_maid = $('.cbo_maid option:selected').val();
                $('#txt_maid_id').val(cbo_maid);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_recruiter_id_combo() {
    try {
        $('.cbo_recruiter').change(function () {
            var cbo_recruiter = $('.cbo_recruiter option:selected').val();
                $('#txt_recruiter_id').val(cbo_recruiter);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_maid_id_combo() {
    try {
        $('.cbo_maid').change(function () {
            var cbo_maid = $('.cbo_maid option:selected').val();
                $('#txt_maid_id').val(cbo_maid);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_village_id_combo() {
    try {
        $('.cbo_village').change(function () {
            var cbo_village = $('.cbo_village option:selected').val();
                $('#txt_village_id').val(cbo_village);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_maid_id_combo() {
    try {
        $('.cbo_maid').change(function () {
            var cbo_maid = $('.cbo_maid option:selected').val();
                $('#txt_maid_id').val(cbo_maid);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            window.location.reload();
        });
    });
    $('#no_btn, .no_btn').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.menu').show();
    });

}function show_Y_N_dialog() {
    $('.y_n_dialog').fadeIn(200);
}
function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
function validate_numbers_textfields() {
  $('.only_numbers').keydown(function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                        // Allow: Ctrl+A, Command+A
                                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                                // Allow: home, end, left, right, down, up
                                        (e.keyCode >= 35 && e.keyCode <= 40)) {
                            // let it happen, don't do anything
                            return;
                        }
                        // Ensure that it is a number and stop the keypress
                        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                            e.preventDefault();
                        }
                    });   }
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer','pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname=$('#txt_shall_expand_toUpdate').val();
    if (updname!='') {
          $('.new_data_box').delay(200).slideDown();
    }
        
}
function postDisplayData(call_dialog,div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
         alert('Declined!');
    });
}function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from account ...
 
function account_del_udpate(){
$('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
 $('.account_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from account_category ...
 
function account_category_del_udpate(){
$('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
 $('.account_category_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from profile ...
 
function profile_del_udpate(){
$('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
 $('.profile_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from image ...
 
function image_del_udpate(){
$('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
 $('.image_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from province ...
 
function province_del_udpate(){
$('.province_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.province').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprovince.. 
 $('.province_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from district ...
 
function district_del_udpate(){
$('.district_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict.. 
 $('.district_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from contact_us ...
 
function contact_us_del_udpate(){
$('.contact_us_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcontact_us.. 
 $('.contact_us_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from village ...
 
function village_del_udpate(){
$('.village_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage.. 
 $('.village_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from org ...
 
function org_del_udpate(){
$('.org_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.org').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromorg.. 
 $('.org_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from recruiter ...
 
function recruiter_del_udpate(){
$('.recruiter_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.recruiter').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromrecruiter.. 
 $('.recruiter_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from recruitment ...
 
function recruitment_del_udpate(){
$('.recruitment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.recruitment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromrecruitment.. 
 $('.recruitment_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from return ...
 
function return_del_udpate(){
$('.return_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.return').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromreturn.. 
 $('.return_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from maid ...
 
function maid_del_udpate(){
$('.maid_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.maid').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frommaid.. 
 $('.maid_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from maid_request ...
 
function maid_request_del_udpate(){
$('.maid_request_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.maid_request').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frommaid_request.. 
 $('.maid_request_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from certificates ...
 
function certificates_del_udpate(){
$('.certificates_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.certificates').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcertificates.. 
 $('.certificates_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
