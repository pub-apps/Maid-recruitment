<?php
require_once('../web_db/new_values.php');
 
if (isset($_POST['new_account'])) {

$new_account = new new_values();
$account_category = $_POST['account_category'];$date_created = $_POST['date_created'];$profile = $_POST['profile'];$username = $_POST['username'];$password = $_POST['password'];$is_online = $_POST['is_online'];
$new_account->new_account($account_category,$date_created,$profile,$username,$password,$is_online);
 if (isset($res)) {
        $json['success'] = 'account added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'account not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_account_category'])) {

$new_account_category = new new_values();
$name = $_POST['name'];
$new_account_category->new_account_category($name);
 if (isset($res)) {
        $json['success'] = 'account_category added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'account_category not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_profile'])) {

$new_profile = new new_values();
$dob = $_POST['dob'];$name = $_POST['name'];$last_name = $_POST['last_name'];$gender = $_POST['gender'];$telephone_number = $_POST['telephone_number'];$email = $_POST['email'];$residence = $_POST['residence'];$image = $_POST['image'];
$new_profile->new_profile($dob,$name,$last_name,$gender,$telephone_number,$email,$residence,$image);
 if (isset($res)) {
        $json['success'] = 'profile added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'profile not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_image'])) {

$new_image = new new_values();
$path = $_POST['path'];
$new_image->new_image($path);
 if (isset($res)) {
        $json['success'] = 'image added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'image not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_province'])) {

$new_province = new new_values();
$name = $_POST['name'];
$new_province->new_province($name);
 if (isset($res)) {
        $json['success'] = 'province added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'province not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_district'])) {

$new_district = new new_values();
$name = $_POST['name'];$province = $_POST['province'];
$new_district->new_district($name,$province);
 if (isset($res)) {
        $json['success'] = 'district added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'district not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_sector'])) {

$new_sector = new new_values();
$name = $_POST['name'];$district = $_POST['district'];
$new_sector->new_sector($name,$district);
 if (isset($res)) {
        $json['success'] = 'sector added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'sector not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_cell'])) {

$new_cell = new new_values();
$name = $_POST['name'];$sector = $_POST['sector'];
$new_cell->new_cell($name,$sector);
 if (isset($res)) {
        $json['success'] = 'cell added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'cell not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_contact_us'])) {

$new_contact_us = new new_values();
$account = $_POST['account'];$date_contact = $_POST['date_contact'];$message = $_POST['message'];
$new_contact_us->new_contact_us($account,$date_contact,$message);
 if (isset($res)) {
        $json['success'] = 'contact_us added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'contact_us not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_village'])) {

$new_village = new new_values();
$name = $_POST['name'];$cell = $_POST['cell'];
$new_village->new_village($name,$cell);
 if (isset($res)) {
        $json['success'] = 'village added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'village not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_org'])) {

$new_org = new new_values();
$name = $_POST['name'];$phone = $_POST['phone'];$address = $_POST['address'];
$new_org->new_org($name,$phone,$address);
 if (isset($res)) {
        $json['success'] = 'org added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'org not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_recruiter'])) {

$new_recruiter = new new_values();
$family_rep_name = $_POST['family_rep_name'];$number_members = $_POST['number_members'];$sector = $_POST['sector'];$profile = $_POST['profile'];
$new_recruiter->new_recruiter($family_rep_name,$number_members,$sector,$profile);
 if (isset($res)) {
        $json['success'] = 'recruiter added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'recruiter not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_recruitment'])) {

$new_recruitment = new new_values();
$recruit_date = $_POST['recruit_date'];$maid = $_POST['maid'];$recruiter = $_POST['recruiter'];$salary_agreed = $_POST['salary_agreed'];
$new_recruitment->new_recruitment($recruit_date,$maid,$recruiter,$salary_agreed);
 if (isset($res)) {
        $json['success'] = 'recruitment added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'recruitment not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_return'])) {

$new_return = new new_values();
$return_date = $_POST['return_date'];$reason = $_POST['reason'];$maid = $_POST['maid'];$comment = $_POST['comment'];
$new_return->new_return($return_date,$reason,$maid,$comment);
 if (isset($res)) {
        $json['success'] = 'return added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'return not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_maid'])) {

$new_maid = new new_values();
$sex = $_POST['sex'];$village = $_POST['village'];$id_number = $_POST['id_number'];$experience = $_POST['experience'];$religion = $_POST['religion'];$prefered_job = $_POST['prefered_job'];$available = $_POST['available'];
$new_maid->new_maid($sex,$village,$id_number,$experience,$religion,$prefered_job,$available);
 if (isset($res)) {
        $json['success'] = 'maid added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'maid not added : ' ;
        echo json_encode($json);
    }
}
