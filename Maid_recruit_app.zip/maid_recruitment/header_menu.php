<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                HOUSE WORKER MIS
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_image.php">image</a>
<a href="new_province.php">province</a>
<a href="new_district.php">district</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_contact_us.php">contact_us</a>
<a href="new_village.php">village</a>
<a href="new_org.php">org</a>
<a href="new_recruiter.php">recruiter</a>
<a href="new_recruitment.php">recruitment</a>
<a href="new_return.php">return</a>
<a href="new_maid.php">maid</a>
<a href="new_maid_request.php">maid_request</a>
<a href="new_certificates.php">certificates</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
