<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $profile,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, profile= ? WHERE account_id=?");
$stmt->execute(array($account_category, $profile ,$account_id ));

}
 function update_account_category( ,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
 WHERE account_category_id=?");
$stmt->execute(array( ,$account_category_id ));

}
 function update_profile( $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
image= ? WHERE profile_id=?");
$stmt->execute(array($image ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_province( $name,$province_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE province set 
name= ? WHERE province_id=?");
$stmt->execute(array($name ,$province_id ));

}
 function update_district( $province, $name,$district_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE district set 
province= ?, name= ? WHERE district_id=?");
$stmt->execute(array($province, $name ,$district_id ));

}
 function update_sector( $district, $name,$sector_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sector set 
district= ?, name= ? WHERE sector_id=?");
$stmt->execute(array($district, $name ,$sector_id ));

}
 function update_cell( $sector, $name,$cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell set 
sector= ?, name= ? WHERE cell_id=?");
$stmt->execute(array($sector, $name ,$cell_id ));

}
 function update_contact_us( $account,$contact_us_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE contact_us set 
account= ? WHERE contact_us_id=?");
$stmt->execute(array($account ,$contact_us_id ));

}
 function update_village( $cell, $name,$village_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE village set 
cell= ?, name= ? WHERE village_id=?");
$stmt->execute(array($cell, $name ,$village_id ));

}
 function update_org( ,$org_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE org set 
 WHERE org_id=?");
$stmt->execute(array( ,$org_id ));

}
 function update_recruiter( $n_members, $sector, $profile, $family_rep_name, $entry_date, $account,$recruiter_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE recruiter set 
n_members= ?, sector= ?, profile= ?, family_rep_name= ?, entry_date= ?, account= ? WHERE recruiter_id=?");
$stmt->execute(array($n_members, $sector, $profile, $family_rep_name, $entry_date, $account ,$recruiter_id ));

}
 function update_recruitment( $recruit_date, $maid, $recruiter, $salary_agreed,$recruitment_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE recruitment set 
recruit_date= ?, maid= ?, recruiter= ?, salary_agreed= ? WHERE recruitment_id=?");
$stmt->execute(array($recruit_date, $maid, $recruiter, $salary_agreed ,$recruitment_id ));

}
 function update_return( $return_date, $reason, $maid, $comment,$return_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE return set 
return_date= ?, reason= ?, maid= ?, comment= ? WHERE return_id=?");
$stmt->execute(array($return_date, $reason, $maid, $comment ,$return_id ));

}
 function update_maid( $village, $sex, $village, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $id_number, $phone,$maid_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE maid set 
village= ?, sex= ?, village= ?, experience= ?, religion= ?, prefered_job= ?, available= ?, profile= ?, education_level= ?, status= ?, id_number= ?, phone= ? WHERE maid_id=?");
$stmt->execute(array($village, $sex, $village, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $id_number, $phone ,$maid_id ));

}
 function update_maid_request( $entry_date, $User, $description,$maid_request_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE maid_request set 
entry_date= ?, User= ?, description= ? WHERE maid_request_id=?");
$stmt->execute(array($entry_date, $User, $description ,$maid_request_id ));

}
 function update_certificates( $maid, $file,$certificates_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE certificates set 
maid= ?, file= ? WHERE certificates_id=?");
$stmt->execute(array($maid, $file ,$certificates_id ));

}

}

