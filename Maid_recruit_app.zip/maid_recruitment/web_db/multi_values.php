<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td> null </td><td> null </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="account_category_id_cols account " title="account" >
<?php echo  $this->_e($row['account_category']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_account_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    } function get_chosen_account_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_account_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account_category </td>

<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>


<td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field


 function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
 function get_last_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td> null </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="image_id_cols profile " title="profile" >
<?php echo  $this->_e($row['image']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_image($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_image($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from image";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> image </td>
<td> Path </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['image_id']; ?>
</td>
<td class="path_id_cols image " title="image" >
<?php echo  $this->_e($row['path']); ?>
</td>


<td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_image_path($id) {
        
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

 function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
 function get_last_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
function list_province($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from province";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> province </td>
<td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['province_id']; ?>
</td>
<td class="name_id_cols province " title="province" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="province_delete_link" style="color: #000080;" data-id_delete="province_id"  data-table="
                           <?php echo $row['province_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="province_update_link" style="color: #000080;" value="
                           <?php echo $row['province_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_province_name($id) {
        
        $db = new dbconnection();
        $sql = "select   province.name from province where province_id=:province_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':province_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_province() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  province_id   from province";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_province() {
        $con = new dbconnection();
        $sql = "select province.province_id from province
                    order by province.province_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['province_id'];
        return $first_rec;
    }
 function get_last_province() {
        $con = new dbconnection();
        $sql = "select province.province_id from province
                    order by province.province_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['province_id'];
        return $first_rec;
    }
function list_district($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from district";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> district </td>
<td> null </td><td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['district_id']; ?>
</td>
<td class="province_id_cols district " title="district" >
<?php echo  $this->_e($row['province']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="district_delete_link" style="color: #000080;" data-id_delete="district_id"  data-table="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="district_update_link" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_district_province($id) {
        
        $db = new dbconnection();
        $sql = "select   district.province from district where district_id=:district_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':district_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['province'];
        echo $field;
    } function get_chosen_district_name($id) {
        
        $db = new dbconnection();
        $sql = "select   district.name from district where district_id=:district_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':district_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_district() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  district_id   from district";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_district() {
        $con = new dbconnection();
        $sql = "select district.district_id from district
                    order by district.district_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['district_id'];
        return $first_rec;
    }
 function get_last_district() {
        $con = new dbconnection();
        $sql = "select district.district_id from district
                    order by district.district_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['district_id'];
        return $first_rec;
    }
function list_sector($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from sector";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> sector </td>
<td> null </td><td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['sector_id']; ?>
</td>
<td class="district_id_cols sector " title="sector" >
<?php echo  $this->_e($row['district']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" data-id_delete="sector_id"  data-table="
                           <?php echo $row['sector_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['sector_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_sector_district($id) {
        
        $db = new dbconnection();
        $sql = "select   sector.district from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['district'];
        echo $field;
    } function get_chosen_sector_name($id) {
        
        $db = new dbconnection();
        $sql = "select   sector.name from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_sector() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  sector_id   from sector";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_sector() {
        $con = new dbconnection();
        $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['sector_id'];
        return $first_rec;
    }
 function get_last_sector() {
        $con = new dbconnection();
        $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['sector_id'];
        return $first_rec;
    }
function list_cell($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from cell";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> cell </td>
<td> null </td><td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['cell_id']; ?>
</td>
<td class="sector_id_cols cell " title="cell" >
<?php echo  $this->_e($row['sector']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" data-id_delete="cell_id"  data-table="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_cell_sector($id) {
        
        $db = new dbconnection();
        $sql = "select   cell.sector from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    } function get_chosen_cell_name($id) {
        
        $db = new dbconnection();
        $sql = "select   cell.name from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_cell() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  cell_id   from cell";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_cell() {
        $con = new dbconnection();
        $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_id'];
        return $first_rec;
    }
 function get_last_cell() {
        $con = new dbconnection();
        $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_id'];
        return $first_rec;
    }
function list_contact_us($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from contact_us";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> contact_us </td>
<td> null </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['contact_us_id']; ?>
</td>
<td class="account_id_cols contact_us " title="contact_us" >
<?php echo  $this->_e($row['account']); ?>
</td>


<td>
                        <a href="#" class="contact_us_delete_link" style="color: #000080;" data-id_delete="contact_us_id"  data-table="
                           <?php echo $row['contact_us_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="contact_us_update_link" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_contact_us_account($id) {
        
        $db = new dbconnection();
        $sql = "select   contact_us.account from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

 function All_contact_us() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  contact_us_id   from contact_us";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_contact_us() {
        $con = new dbconnection();
        $sql = "select contact_us.contact_us_id from contact_us
                    order by contact_us.contact_us_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['contact_us_id'];
        return $first_rec;
    }
 function get_last_contact_us() {
        $con = new dbconnection();
        $sql = "select contact_us.contact_us_id from contact_us
                    order by contact_us.contact_us_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['contact_us_id'];
        return $first_rec;
    }
function list_village($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from village";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> village </td>
<td> null </td><td> Name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['village_id']; ?>
</td>
<td class="cell_id_cols village " title="village" >
<?php echo  $this->_e($row['cell']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="village_delete_link" style="color: #000080;" data-id_delete="village_id"  data-table="
                           <?php echo $row['village_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="village_update_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_village_cell($id) {
        
        $db = new dbconnection();
        $sql = "select   village.cell from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    } function get_chosen_village_name($id) {
        
        $db = new dbconnection();
        $sql = "select   village.name from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_village() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  village_id   from village";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_village() {
        $con = new dbconnection();
        $sql = "select village.village_id from village
                    order by village.village_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['village_id'];
        return $first_rec;
    }
 function get_last_village() {
        $con = new dbconnection();
        $sql = "select village.village_id from village
                    order by village.village_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['village_id'];
        return $first_rec;
    }
function list_org($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from org";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> org </td>

<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['org_id']; ?>
</td>


<td>
                        <a href="#" class="org_delete_link" style="color: #000080;" data-id_delete="org_id"  data-table="
                           <?php echo $row['org_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="org_update_link" style="color: #000080;" value="
                           <?php echo $row['org_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field


 function All_org() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  org_id   from org";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_org() {
        $con = new dbconnection();
        $sql = "select org.org_id from org
                    order by org.org_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['org_id'];
        return $first_rec;
    }
 function get_last_org() {
        $con = new dbconnection();
        $sql = "select org.org_id from org
                    order by org.org_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['org_id'];
        return $first_rec;
    }
function list_recruiter($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from recruiter";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> recruiter </td>
<td> Number of Members </td><td> Sector </td><td> Profile </td><td> Family representative Name </td><td> Entry Date </td><td> Account </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['recruiter_id']; ?>
</td>
<td class="n_members_id_cols recruiter " title="recruiter" >
<?php echo  $this->_e($row['n_members']); ?>
</td>
<td>
<?php echo  $this->_e($row['sector']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['family_rep_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['account']); ?>
</td>


<td>
                        <a href="#" class="recruiter_delete_link" style="color: #000080;" data-id_delete="recruiter_id"  data-table="
                           <?php echo $row['recruiter_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="recruiter_update_link" style="color: #000080;" value="
                           <?php echo $row['recruiter_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_recruiter_n_members($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.n_members from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['n_members'];
        echo $field;
    } function get_chosen_recruiter_sector($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.sector from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    } function get_chosen_recruiter_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.profile from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_recruiter_family_rep_name($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.family_rep_name from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['family_rep_name'];
        echo $field;
    } function get_chosen_recruiter_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.entry_date from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_recruiter_account($id) {
        
        $db = new dbconnection();
        $sql = "select   recruiter.account from recruiter where recruiter_id=:recruiter_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruiter_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

 function All_recruiter() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  recruiter_id   from recruiter";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_recruiter() {
        $con = new dbconnection();
        $sql = "select recruiter.recruiter_id from recruiter
                    order by recruiter.recruiter_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruiter_id'];
        return $first_rec;
    }
 function get_last_recruiter() {
        $con = new dbconnection();
        $sql = "select recruiter.recruiter_id from recruiter
                    order by recruiter.recruiter_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruiter_id'];
        return $first_rec;
    }
function list_recruitment($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from recruitment";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> recruitment </td>
<td> Recruit Date </td><td> Maid </td><td> Recruiter </td><td> Salary Agreed </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['recruitment_id']; ?>
</td>
<td class="recruit_date_id_cols recruitment " title="recruitment" >
<?php echo  $this->_e($row['recruit_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['maid']); ?>
</td>
<td>
<?php echo  $this->_e($row['recruiter']); ?>
</td>
<td>
<?php echo  $this->_e($row['salary_agreed']); ?>
</td>


<td>
                        <a href="#" class="recruitment_delete_link" style="color: #000080;" data-id_delete="recruitment_id"  data-table="
                           <?php echo $row['recruitment_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="recruitment_update_link" style="color: #000080;" value="
                           <?php echo $row['recruitment_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_recruitment_recruit_date($id) {
        
        $db = new dbconnection();
        $sql = "select   recruitment.recruit_date from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['recruit_date'];
        echo $field;
    } function get_chosen_recruitment_maid($id) {
        
        $db = new dbconnection();
        $sql = "select   recruitment.maid from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['maid'];
        echo $field;
    } function get_chosen_recruitment_recruiter($id) {
        
        $db = new dbconnection();
        $sql = "select   recruitment.recruiter from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['recruiter'];
        echo $field;
    } function get_chosen_recruitment_salary_agreed($id) {
        
        $db = new dbconnection();
        $sql = "select   recruitment.salary_agreed from recruitment where recruitment_id=:recruitment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':recruitment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['salary_agreed'];
        echo $field;
    }

 function All_recruitment() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  recruitment_id   from recruitment";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_recruitment() {
        $con = new dbconnection();
        $sql = "select recruitment.recruitment_id from recruitment
                    order by recruitment.recruitment_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruitment_id'];
        return $first_rec;
    }
 function get_last_recruitment() {
        $con = new dbconnection();
        $sql = "select recruitment.recruitment_id from recruitment
                    order by recruitment.recruitment_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['recruitment_id'];
        return $first_rec;
    }
function list_return($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from return";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> return </td>
<td> Return Date </td><td> Reason </td><td> Maid </td><td> Comment </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['return_id']; ?>
</td>
<td class="return_date_id_cols return " title="return" >
<?php echo  $this->_e($row['return_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['reason']); ?>
</td>
<td>
<?php echo  $this->_e($row['maid']); ?>
</td>
<td>
<?php echo  $this->_e($row['comment']); ?>
</td>


<td>
                        <a href="#" class="return_delete_link" style="color: #000080;" data-id_delete="return_id"  data-table="
                           <?php echo $row['return_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="return_update_link" style="color: #000080;" value="
                           <?php echo $row['return_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_return_return_date($id) {
        
        $db = new dbconnection();
        $sql = "select   return.return_date from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['return_date'];
        echo $field;
    } function get_chosen_return_reason($id) {
        
        $db = new dbconnection();
        $sql = "select   return.reason from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['reason'];
        echo $field;
    } function get_chosen_return_maid($id) {
        
        $db = new dbconnection();
        $sql = "select   return.maid from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['maid'];
        echo $field;
    } function get_chosen_return_comment($id) {
        
        $db = new dbconnection();
        $sql = "select   return.comment from return where return_id=:return_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':return_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    }

 function All_return() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  return_id   from return";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_return() {
        $con = new dbconnection();
        $sql = "select return.return_id from return
                    order by return.return_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['return_id'];
        return $first_rec;
    }
 function get_last_return() {
        $con = new dbconnection();
        $sql = "select return.return_id from return
                    order by return.return_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['return_id'];
        return $first_rec;
    }
function list_maid($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from maid";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> maid </td>
<td> null </td><td> Sex </td><td> Village </td><td> Experience </td><td> Religion </td><td> Prefered Job </td><td> Available </td><td> Profile </td><td> Education Level </td><td> Pending </td><td> id_number </td><td> Phone </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['maid_id']; ?>
</td>
<td class="village_id_cols maid " title="maid" >
<?php echo  $this->_e($row['village']); ?>
</td>
<td>
<?php echo  $this->_e($row['sex']); ?>
</td>
<td>
<?php echo  $this->_e($row['village']); ?>
</td>
<td>
<?php echo  $this->_e($row['experience']); ?>
</td>
<td>
<?php echo  $this->_e($row['religion']); ?>
</td>
<td>
<?php echo  $this->_e($row['prefered_job']); ?>
</td>
<td>
<?php echo  $this->_e($row['available']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['education_level']); ?>
</td>
<td>
<?php echo  $this->_e($row['status']); ?>
</td>
<td>
<?php echo  $this->_e($row['id_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['phone']); ?>
</td>


<td>
                        <a href="#" class="maid_delete_link" style="color: #000080;" data-id_delete="maid_id"  data-table="
                           <?php echo $row['maid_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="maid_update_link" style="color: #000080;" value="
                           <?php echo $row['maid_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_maid_village($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.village from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['village'];
        echo $field;
    } function get_chosen_maid_sex($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.sex from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sex'];
        echo $field;
    } function get_chosen_maid_village($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.village from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['village'];
        echo $field;
    } function get_chosen_maid_experience($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.experience from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['experience'];
        echo $field;
    } function get_chosen_maid_religion($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.religion from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['religion'];
        echo $field;
    } function get_chosen_maid_prefered_job($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.prefered_job from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['prefered_job'];
        echo $field;
    } function get_chosen_maid_available($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.available from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['available'];
        echo $field;
    } function get_chosen_maid_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.profile from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_maid_education_level($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.education_level from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['education_level'];
        echo $field;
    } function get_chosen_maid_status($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.status from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['status'];
        echo $field;
    } function get_chosen_maid_id_number($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.id_number from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['id_number'];
        echo $field;
    } function get_chosen_maid_phone($id) {
        
        $db = new dbconnection();
        $sql = "select   maid.phone from maid where maid_id=:maid_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['phone'];
        echo $field;
    }

 function All_maid() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  maid_id   from maid";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_maid() {
        $con = new dbconnection();
        $sql = "select maid.maid_id from maid
                    order by maid.maid_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['maid_id'];
        return $first_rec;
    }
 function get_last_maid() {
        $con = new dbconnection();
        $sql = "select maid.maid_id from maid
                    order by maid.maid_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['maid_id'];
        return $first_rec;
    }
function list_maid_request($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from maid_request";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> maid_request </td>
<td> Entry Date </td><td> User </td><td> Description </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['maid_request_id']; ?>
</td>
<td class="entry_date_id_cols maid_request " title="maid_request" >
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['description']); ?>
</td>


<td>
                        <a href="#" class="maid_request_delete_link" style="color: #000080;" data-id_delete="maid_request_id"  data-table="
                           <?php echo $row['maid_request_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="maid_request_update_link" style="color: #000080;" value="
                           <?php echo $row['maid_request_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_maid_request_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   maid_request.entry_date from maid_request where maid_request_id=:maid_request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_maid_request_User($id) {
        
        $db = new dbconnection();
        $sql = "select   maid_request.User from maid_request where maid_request_id=:maid_request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_maid_request_description($id) {
        
        $db = new dbconnection();
        $sql = "select   maid_request.description from maid_request where maid_request_id=:maid_request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':maid_request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['description'];
        echo $field;
    }

 function All_maid_request() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  maid_request_id   from maid_request";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_maid_request() {
        $con = new dbconnection();
        $sql = "select maid_request.maid_request_id from maid_request
                    order by maid_request.maid_request_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['maid_request_id'];
        return $first_rec;
    }
 function get_last_maid_request() {
        $con = new dbconnection();
        $sql = "select maid_request.maid_request_id from maid_request
                    order by maid_request.maid_request_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['maid_request_id'];
        return $first_rec;
    }
function list_certificates($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from certificates";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> certificates </td>
<td> Maid </td><td> File </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['certificates_id']; ?>
</td>
<td class="maid_id_cols certificates " title="certificates" >
<?php echo  $this->_e($row['maid']); ?>
</td>
<td>
<?php echo  $this->_e($row['file']); ?>
</td>


<td>
                        <a href="#" class="certificates_delete_link" style="color: #000080;" data-id_delete="certificates_id"  data-table="
                           <?php echo $row['certificates_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="certificates_update_link" style="color: #000080;" value="
                           <?php echo $row['certificates_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_certificates_maid($id) {
        
        $db = new dbconnection();
        $sql = "select   certificates.maid from certificates where certificates_id=:certificates_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':certificates_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['maid'];
        echo $field;
    } function get_chosen_certificates_file($id) {
        
        $db = new dbconnection();
        $sql = "select   certificates.file from certificates where certificates_id=:certificates_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':certificates_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['file'];
        echo $field;
    }

 function All_certificates() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  certificates_id   from certificates";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_certificates() {
        $con = new dbconnection();
        $sql = "select certificates.certificates_id from certificates
                    order by certificates.certificates_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['certificates_id'];
        return $first_rec;
    }
 function get_last_certificates() {
        $con = new dbconnection();
        $sql = "select certificates.certificates_id from certificates
                    order by certificates.certificates_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['certificates_id'];
        return $first_rec;
    }
 function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select class="textbox cbo_cell"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_maid_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select maid.maid_id,   maid.name from maid";
        ?>
        <select class="textbox cbo_maid"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_recruiter_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select recruiter.recruiter_id,   recruiter.name from recruiter";
        ?>
        <select class="textbox cbo_recruiter"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['recruiter_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_maid_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select maid.maid_id,   maid.name from maid";
        ?>
        <select class="textbox cbo_maid"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_village_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,   village.name from village";
        ?>
        <select class="textbox cbo_village"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_village_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,   village.name from village";
        ?>
        <select class="textbox cbo_village"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_maid_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select maid.maid_id,   maid.name from maid";
        ?>
        <select class="textbox cbo_maid"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['maid_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }


 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

