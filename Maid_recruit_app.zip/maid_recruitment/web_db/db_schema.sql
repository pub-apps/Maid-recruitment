
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
, `profile`     int(11)   

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`province_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id`     int(11) NOT NULL AUTO_INCREMENT 
, `province`     int(11)   
,`name`     VARCHAR(60) 

,PRIMARY KEY (`district_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id`     int(11) NOT NULL AUTO_INCREMENT 
, `district`     int(11)   
,`name`     VARCHAR(60) 

,PRIMARY KEY (`sector_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
, `sector`     int(11)   
,`name`     VARCHAR(60) 

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `village`
--

CREATE TABLE IF NOT EXISTS `village` (
`village_id`     int(11) NOT NULL AUTO_INCREMENT 
, `cell`     int(11)   
,`name`     VARCHAR(60) 

,PRIMARY KEY (`village_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`contact_us_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   

,PRIMARY KEY (`contact_us_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `org`
--

CREATE TABLE IF NOT EXISTS `org` (
`org_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`org_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `recruiter`
--

CREATE TABLE IF NOT EXISTS `recruiter` (
`recruiter_id`     int(11) NOT NULL AUTO_INCREMENT 
,`n_members`     VARCHAR(60) 
, `sector`     int(11)   
, `profile`     int(11)   
,`family_rep_name`     VARCHAR(60) 
,`entry_date`     Date 
, `account`     int(11)   

,PRIMARY KEY (`recruiter_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `recruitment`
--

CREATE TABLE IF NOT EXISTS `recruitment` (
`recruitment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`recruit_date`     Date 
, `maid`     int(11)   
, `recruiter`     int(11)   
,`salary_agreed`     VARCHAR(60) 

,PRIMARY KEY (`recruitment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `return`
--

CREATE TABLE IF NOT EXISTS `return` (
`return_id`     int(11) NOT NULL AUTO_INCREMENT 
,`return_date`     Date 
,`reason`     VARCHAR(60) 
, `maid`     int(11)   
,`comment`     VARCHAR(60) 

,PRIMARY KEY (`return_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `maid`
--

CREATE TABLE IF NOT EXISTS `maid` (
`maid_id`     int(11) NOT NULL AUTO_INCREMENT 
, `village`     int(11)   
,`sex`     VARCHAR(60) 
, `village`     int(11)   
,`experience`     VARCHAR(60) 
,`religion`     VARCHAR(60) 
,`prefered_job`     VARCHAR(60) 
,`available`     VARCHAR(60) 
, `profile`     int(11)   
,`education_level`     VARCHAR(60) 
,`status`     VARCHAR(60) 
,`id_number`     VARCHAR(60) 
,`phone`     VARCHAR(60) 

,PRIMARY KEY (`maid_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `maid_request`
--

CREATE TABLE IF NOT EXISTS `maid_request` (
`maid_request_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`description`     VARCHAR(60) 

,PRIMARY KEY (`maid_request_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `certificates`
--

CREATE TABLE IF NOT EXISTS `certificates` (
`certificates_id`     int(11) NOT NULL AUTO_INCREMENT 
, `maid`     int(11)   
,`file`     VARCHAR(60) 

,PRIMARY KEY (`certificates_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

