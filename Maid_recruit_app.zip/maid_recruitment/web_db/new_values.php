<?php 
class new_values{

 function new_account(  $account_category, $profile){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :profile)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':profile'=>$profile
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  ){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id,)");$stm->execute(array(':account_category_id'=>0,
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :image)");$stm->execute(array(':profile_id'=>0,':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_image(  $path){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into image values(:image_id, :path)");$stm->execute(array(':image_id'=>0,':path'=>$path
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_province(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into province values(:province_id, :name)");$stm->execute(array(':province_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_district(  $province, $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into district values(:district_id, :province,  :name)");$stm->execute(array(':district_id'=>0,':province'=>$province, ':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_sector(  $district, $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into sector values(:sector_id, :district,  :name)");$stm->execute(array(':sector_id'=>0,':district'=>$district, ':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_cell(  $sector, $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into cell values(:cell_id, :sector,  :name)");$stm->execute(array(':cell_id'=>0,':sector'=>$sector, ':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_contact_us(  $account){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into contact_us values(:contact_us_id, :account)");$stm->execute(array(':contact_us_id'=>0,':account'=>$account
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_village(  $cell, $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into village values(:village_id, :cell,  :name)");$stm->execute(array(':village_id'=>0,':cell'=>$cell, ':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_org(  ){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into org values(:org_id,)");$stm->execute(array(':org_id'=>0,
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_recruiter(  $n_members, $sector, $profile, $family_rep_name, $entry_date, $account){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into recruiter values(:recruiter_id, :n_members,  :sector,  :profile,  :family_rep_name,  :entry_date,  :account)");$stm->execute(array(':recruiter_id'=>0,':n_members'=>$n_members, ':sector'=>$sector, ':profile'=>$profile, ':family_rep_name'=>$family_rep_name, ':entry_date'=>$entry_date, ':account'=>$account
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_recruitment(  $recruit_date, $maid, $recruiter, $salary_agreed){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into recruitment values(:recruitment_id, :recruit_date,  :maid,  :recruiter,  :salary_agreed)");$stm->execute(array(':recruitment_id'=>0,':recruit_date'=>$recruit_date, ':maid'=>$maid, ':recruiter'=>$recruiter, ':salary_agreed'=>$salary_agreed
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_return(  $return_date, $reason, $maid, $comment){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into return values(:return_id, :return_date,  :reason,  :maid,  :comment)");$stm->execute(array(':return_id'=>0,':return_date'=>$return_date, ':reason'=>$reason, ':maid'=>$maid, ':comment'=>$comment
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_maid(  $village, $sex, $village, $experience, $religion, $prefered_job, $available, $profile, $education_level, $status, $id_number, $phone){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into maid values(:maid_id, :village,  :sex,  :village,  :experience,  :religion,  :prefered_job,  :available,  :profile,  :education_level,  :status,  :id_number,  :phone)");$stm->execute(array(':maid_id'=>0,':village'=>$village, ':sex'=>$sex, ':village'=>$village, ':experience'=>$experience, ':religion'=>$religion, ':prefered_job'=>$prefered_job, ':available'=>$available, ':profile'=>$profile, ':education_level'=>$education_level, ':status'=>$status, ':id_number'=>$id_number, ':phone'=>$phone
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_maid_request(  $entry_date, $User, $description){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into maid_request values(:maid_request_id, :entry_date,  :User,  :description)");$stm->execute(array(':maid_request_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':description'=>$description
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_certificates(  $maid, $file){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into certificates values(:certificates_id, :maid,  :file)");$stm->execute(array(':certificates_id'=>0,':maid'=>$maid, ':file'=>$file
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
